"""GameSession: the harness state for one game and the observe -> decide -> act cycle.

Two granularities:
- every engine step: `observe()` runs deterministic perception on the new frame, the tracker,
  the delta, the comparison against the saved prediction, and appends one ledger Record; on the
  first violated claim the rest of the committed batch is dropped;
- every model turn (queue empty or halted): the graph in nodes.py runs the roles for the mode,
  validates every output, applies the memory patch and queues the next batch.

The model client is any object with `call_json(...)` (client.ModelClient or fakemodel.FakeModel).
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Optional

from arcengine import GameAction, GameState

from . import control as control_mod
from . import diffing, dsl_facts, facts, goals, perception, planner, predict, prompts, render, rules, schemas, symbols
from .critic import follow_up
from .ledger import Ledger
from .memory import GameStore, Memory
from .nodes import TurnState, build_graph
from .repl import Repl
from .tracker import ObjectTracker
from .types import Claim, Confidences, Mode, Prediction, Record, colour_letter
from .vendor.tycho.agent import ActionChoice

DOOM_THRESHOLD = 3
# How many classes of each kind (same / new / gone / changed) get a hypothesis at a level boundary.
HYPOTHESES_PER_KIND = 3
# Mispredicted steps a batch may survive. One was too few: predictions are violated on more than
# half of all steps, so halting on the first capped every batch at about two actions.
MISSES_BEFORE_HALT = 2
# How many turns in a row may be spent on the same goal solved into the same steps before the
# harness stops believing the answer. Counted in turns, so 3 fires on the third identical one:
# two can be a legitimate retry after a halt, three is a loop.
PLAN_REPEAT_LIMIT = 3
# Actions a model turn must buy to be worth its latency. Below this the harness takes the next
# turn itself, for free, because it can usually commit more than that from certified facts alone.
STARVING_FLOOR = 4
# Steps to commit when the body's own size is still moving between frames.
UNSETTLED_BODY_BATCH = 3
DEFAULT_STORE = Path(__file__).resolve().parents[2] / "runs" / "v9_game_memory.json"


def _flag(config: Any, name: str, default: Any = False) -> Any:
    if config is None:
        return default
    if isinstance(config, dict):
        return config.get(name, default)
    return getattr(config, name, default)


class GameSession:
    def __init__(self, *, model: Any, config: Any, out_dir: Path, tag: str) -> None:
        self.model = model
        self.config = config
        self.out_dir = Path(out_dir)
        self.tag = tag
        self.graph = build_graph()
        if hasattr(model, "bind"):
            model.bind(self)
        store_path = Path(_flag(config, "game_store", None) or DEFAULT_STORE)
        self.store = GameStore(store_path).load()
        self.use_repl = not _flag(config, "no_repl", False)
        self.repl: Optional[Repl] = None
        self._reset_state("", [])

    # -- state -------------------------------------------------------------------------------------

    def _reset_state(self, game_id: str, actions: list[GameAction]) -> None:
        self.game_id = game_id
        self.available: list[str] = [a.name for a in actions]
        self.pstate = perception.PerceptionState()
        self.tracker = ObjectTracker()
        self.ledger = Ledger()
        self.rules = rules.RuleStore()
        self.control = control_mod.ControlMap()
        self.memory = Memory()
        self.passability = facts.Passability()
        self.consumption = facts.Consumption()
        self.miner = facts.PreconditionMiner()
        self.percept: Optional[Any] = None
        self.prev_percept: Optional[Any] = None
        self.level = 1
        self.n_levels = 0
        self.level_actions = 0
        self.step = 0
        self.turn_index = 0
        self.queue: list[tuple[dict[str, Any], Optional[Prediction]]] = []
        self.pending: Optional[tuple[dict[str, Any], Optional[Prediction], dict[str, int], str, dict[str, Any]]] = None
        self.last_comparison = None
        self.last_outcome_line = "no action yet"
        self.last_violated = False
        self.last_violation_informative = False
        self.last_unexpected = False
        self.consecutive_recover = 0
        self.current_mode: Optional[Mode] = None
        self.confidences = Confidences()
        self.model_confidence: dict[str, float] = {}
        self.new_level_pending = True
        self.oriented_level = 0
        self.doom_ring: list[tuple[str, str]] = []
        self.batch_sig = ""
        self.batch_requested = 0
        self.batch_executed = 0
        self.batch_level_before = 1
        self.halted_reason = ""
        self.batch_misses = 0              # mispredicted steps within the batch now running
        self.done_reason: Optional[str] = None
        self.failed_calls = 0
        self.unreachable_calls = 0        # consecutive request errors, which is a different thing
        self.hyp_tests: dict[str, dict[str, Any]] = {}
        self.current_vocab = schemas.Vocab()
        self.generated_tokens = 0
        self.probe_done = False
        self._prev_self_tid: Optional[str] = None   # to notice the step a rename happened on
        # Survives reset: run.py sets it once from the engine's baselines, before run_env calls
        # agent.reset(), and a new level does not change what the level budgets are.
        self.action_budget: Optional[list[int]] = getattr(self, "action_budget", None)
        self.touched_tids: set[str] = set()
        # The same reach, recorded by where the thing was rather than by what it was called. The
        # tracker renames objects, and a goal written over a class resolves to whatever ids are
        # live right now, so a reach filed under a retired id silently stops counting.
        self.touched_marks: set[frozenset] = set()
        self.stood_on: set[tuple[int, int]] = set()   # squares the body has occupied, for coverage
        self.moved_tids: set[str] = set()             # everything ever seen to move: the pieces
        self.recent_batches: list[int] = []           # how many actions the last few turns bought
        self.family = ""
        self.priors_loaded = False
        self.last_plan = planner.PlanResult(status="no_goal")
        self.symbolic_goal: Optional[dict[str, Any]] = None
        self.plan_promise = False          # did the last committed plan claim to reach the goal?
        self.plan_sig = ""
        self.plan_broken = 0               # consecutive plans that ran clean and missed the goal
        self.plan_repeat = 0               # consecutive turns solved into the identical steps
        self.unreachable = 0               # consecutive turns the solver could not reach the goal
        self.unreachable_goal = ""
        self._unreachable_turn = -1       # so one turn's repeated solves count once
        self.plan_sim_end: Optional[tuple[int, int]] = None   # where the simulation expects to end
        self.plan_body_rel: frozenset = frozenset()           # the shape the search planned with
        self.plan_note = ""
        self.level_diff: dict[str, Any] = {}   # what this level shares with the one before it
        self._level_census: dict[str, int] = {}  # the last reading of the board on this level
        self.retired_goals: set[str] = set()   # goals this level solved cleanly and still missed
        self.goal_fallback: Optional[dict[str, Any]] = None

    def reset(self, game_id: str, available_actions: list[GameAction]) -> None:
        self._reset_state(game_id, available_actions)
        self._t_start = time.monotonic()
        seed = _flag(self.config, "memory_from", None)
        if seed:
            self.seed_from_dump(Path(seed))

    def seed_from_dump(self, path: Path) -> None:
        """Seed theory from an earlier run's <tag>.memory.json: labels, goals, questions,
        hypotheses, slots, level log, rules (re-scored against this run's ledger before they can
        be used) and the control map with halved confidence. Facts are never seeded."""
        d = json.loads(Path(path).read_text())
        if d.get("game_id") and d["game_id"].split("-")[0] != self.game_id.split("-")[0]:
            raise RuntimeError(f"memory dump is for {d['game_id']}, not {self.game_id}")
        self.memory.from_json(d.get("memory", {}))
        if d.get("rules") and hasattr(rules.RuleStore, "from_json"):
            store = rules.RuleStore.from_json(d["rules"])
            for r in store.top(200):
                r.source = "seed"
                r.status = "proposed"
                self.rules.adopt(r)
        if d.get("control"):
            prev = control_mod.ControlMap.from_json(d["control"])
            self.control.inherit(prev, factor=0.5)
        self.new_level_pending = True
        self._log_row({"kind": "seeded", "turn": 0, "from": str(path), "labels": len(self.memory.labels),
                       "goals": len(self.memory.goals), "rules": len(self.rules.top(200)), "level_log": len(self.memory.level_log)})
        if self.use_repl:
            self.repl = Repl()

    def close(self) -> None:
        if self.repl is not None:
            self.repl.close()
        try:
            self.store.note_game(self.game_id, self.family, {"levels": self.level - 1, "turns": self.turn_index,
                                                            "ledger": len(self.ledger)})
            self.store.save()
        except Exception:  # noqa: BLE001
            pass
        self._write_memory_dump()

    def config_flag(self, name: str, default: Any = False) -> Any:
        return _flag(self.config, name, default)

    # -- engine-step cycle -------------------------------------------------------------------------

    def choose_action(self, frames, latest_frame, available_actions) -> ActionChoice:
        self.available = [a.name for a in available_actions]
        self.observe(latest_frame)
        if not self.queue:
            self.run_turn()
        action, prediction = self.queue.pop(0)
        self.batch_executed += 1
        scalars_before = self.scalars()
        self.pending = (action, prediction, scalars_before, self.percept.fingerprint, self._snapshot())
        self.step += 1
        ga = GameAction[action["action"]]
        reasoning = {"src": "v9", "turn": self.turn_index, "mode": self.current_mode.value if self.current_mode else "",
                     "prediction_id": prediction.pid if prediction else None}
        if ga == GameAction.ACTION6:
            return ActionChoice(action=ga, x=int(action["x"]), y=int(action["y"]), reasoning=reasoning)
        return ActionChoice(action=ga, reasoning=reasoning)

    def is_done(self, *_: Any) -> bool:
        return self.done_reason is not None

    def note_final_observation(self, frame, available_actions) -> None:
        try:
            self.observe(frame, final=True)
        except Exception:  # noqa: BLE001
            pass

    def note_external_reset(self) -> None:
        self.queue.clear()
        self.pending = None
        self.last_outcome_line = "GAME_OVER: the engine reset the level; the committed plan was dropped."

    def observe(self, frame, *, final: bool = False) -> None:
        """Perceive the frame; if an action is pending, grade it and append the ledger record."""
        layers = [[[int(v) for v in row] for row in grid] for grid in (frame.frame or [])]
        if not layers:
            # The engine refuses to advance after GAME_OVER and returns no frame. There is
            # nothing to observe, and inventing a board would put a fiction in the ledger.
            self.done_reason = self.done_reason or "empty_frame"
            return
        levels_completed = int(frame.levels_completed)
        self.n_levels = int(getattr(frame, "win_levels", 0) or self.n_levels)
        acted = self.pending is not None
        action_name = self.pending[0]["action"] if acted else None
        new_level = levels_completed + 1 > self.level
        percept = perception.perceive(layers, step=self.step, level=levels_completed + 1, action=action_name,
                                      prev=None if new_level else self.percept, state=self.pstate)
        # Hand the tracker the displacements this action has already produced, so a large jump
        # it has seen before does not look like a new object appearing somewhere else.
        shifts = []
        if action_name:
            try:
                shifts = ([tuple(sh) for sh, _count in self.control.move_signatures(action_name)]
                          if hasattr(self.control, "move_signatures") else [])
                shift = self.control.expected_shift(action_name)
                if shift is not None and tuple(shift) not in shifts:
                    shifts.append(tuple(shift))
            except Exception:  # noqa: BLE001
                shifts = []
        events = self.tracker.update(percept, step=self.step, acted=acted, expected_shifts=shifts)
        if self.percept is not None and acted:
            action, prediction, scalars_before, before_fp, before_snap = self.pending
            delta = diffing.compute_delta(self.percept, percept, events, self.tracker, action=action_name, acted=True)
            # Before the scalars are read, not after them: `consumed[X]`/`remaining[X]` are part
            # of `scalars_after`, and folding this step's consumptions in afterwards made the
            # before and after readings identical on every step -- so a correct claim that an
            # action consumes a Y graded VIOLATED, and `unchanged` always graded MATCHED.
            after_snap = None
            try:
                after_snap = self._snapshot(percept)
                self.consumption.observe_delta(delta, before_snap, self.step)
                if after_snap is not None:
                    self.consumption.census(after_snap)
            except Exception:  # noqa: BLE001
                pass
            scalars_after = self.scalars(percept)
            outcome = {"levels_completed": levels_completed, "level_completed": new_level,
                       "game_over": frame.state == GameState.GAME_OVER, "win": frame.state == GameState.WIN,
                       "state": str(frame.state)}
            if new_level:
                delta.tags.append("level_up")
            if outcome["game_over"]:
                delta.tags.append("game_over")
            comparison = None
            if prediction is not None:
                comparison = predict.compare(prediction, delta, scalars_before, scalars_after,
                                             veiled_vars=self._comover_vars(delta))
            now_self = self.tracker.self_tid
            renamed = bool(now_self and self._prev_self_tid and now_self != self._prev_self_tid)
            if renamed:
                self._log_row({"kind": "self_renamed", "turn": self.turn_index, "step": self.step,
                               "was": self._prev_self_tid, "now": now_self, "action": action_name})
            self.control.observe(action_name, delta, now_self, self_renamed=renamed,
                                 context=self.body_state(before_snap))
            self._prev_self_tid = now_self or self._prev_self_tid
            try:
                self.tracker.note_body()
            except Exception:  # noqa: BLE001
                pass
            self._observe_passability(action_name, before_snap, delta)
            rec = Record(idx=len(self.ledger), step=self.step, level=self.level, action=action_name,
                         action_data={k: v for k, v in action.items() if k in ("x", "y") and v is not None},
                         before_fp=before_fp, after_fp=percept.fingerprint, delta=delta, prediction=prediction,
                         comparison=comparison, outcome=outcome, turn=self.turn_index,
                         mode=self.current_mode.value if self.current_mode else "")
            try:
                rec.before_snap = before_snap  # type: ignore[attr-defined]
                rec.after_snap = after_snap if after_snap is not None else self._snapshot(percept)
            except Exception:  # noqa: BLE001
                pass
            self.ledger.append(rec)
            self.level_actions += 1
            self._resolve_hypotheses(rec, delta, scalars_before, scalars_after)
            self._note_touched(rec, delta)
            # A thing we can DRIVE moves the way a button moves things. Anything else that moved
            # is scenery or an autonomous body, and counting it as a piece is how the harness
            # talked itself into an arrangement goal on a traversal game three runs running --
            # each one retired two turns later as unreachable. Until a shift is known, record
            # everything: the discrimination only becomes possible once the controls are read.
            known_shifts = {tuple(self.control.expected_shift(a))
                            for a in self.available
                            if a != "RESET" and self.control.expected_shift(a)}
            for tid, shift in delta.objects.moved:
                if tuple(shift) == (0, 0):
                    continue
                if not known_shifts or tuple(shift) in known_shifts:
                    self.moved_tids.add(tid)
            try:
                self._mine_contacts(rec, delta)
            except Exception:  # noqa: BLE001
                pass
            # (The consumption tallies were folded in above, before `scalars_after` was read.
            # No klass_of: facts.Consumption reads the colour letter off the step's own before
            # snapshot. Passing the model's role labels used to leak `consumed[?]` and
            # `consumed[unknown]` into the scalar registry, i.e. into claimable variables.)
            self._after_record(rec, comparison, delta)
            self.pending = None
        self.prev_percept = self.percept
        self.percept = percept
        if new_level:
            self._on_level_change(levels_completed + 1)
        else:
            # The last reading of the board this level, kept so the next boundary has something
            # to compare against. Not updated on the boundary step itself: by then the tracker
            # has already been advanced onto the new board.
            self._level_census = self.level_census()
        if self.repl is not None and not final:
            try:
                self.repl.snapshot(self._repl_payload())
            except Exception:  # noqa: BLE001
                pass

    TRUSTED_P = 0.75  # a violated claim below this was a guess, not a trusted prediction (spec: RECOVER = a trusted prediction failed)

    def _after_record(self, rec: Record, comparison, delta) -> None:
        violated = bool(comparison and comparison.violated)
        # A prediction is trusted only when the model had grounds for it: a confident claim AND
        # a control map that has already seen this action at least twice. A confident guess on a
        # first press is a lesson for the ledger, not a reason to burn a RECOVER turn or to drop
        # the rest of a probe batch (seen live: every first batch ended in RECOVER).
        try:
            seen = int(self.control.signature(rec.action).get("total", 0))
        except Exception:  # noqa: BLE001
            seen = 0
        trusted_violation = bool(comparison and seen >= 2
                                 and any(c.p >= self.TRUSTED_P for c, _obs in comparison.violated))
        unexpected = bool(comparison and comparison.unexpected and not comparison.matched)
        self.last_violated = trusted_violation
        # Was this a surprise, or just a board we do not understand yet? A miss on an action whose
        # effect the control map had settled contradicts something we believed, and that is worth
        # three model calls. A miss on an action nobody has pinned down teaches nothing an EXPLORE
        # turn would not, and EXPLORE costs two calls and plays more actions. Measured offline,
        # RECOVER took 78 of 118 model calls -- two thirds of the time in a run -- on a board where
        # predictions are violated on more than half of all steps as a matter of course.
        try:
            # rec.action, not action_name: there is no such local here, so this raised NameError
            # every time and fell through to the fallback below, which made the signal identical
            # to trusted_violation and quietly useless.
            self.last_violation_informative = bool(trusted_violation
                                                   and self.control.known(rec.action))
        except Exception:  # noqa: BLE001
            self.last_violation_informative = bool(trusted_violation)
        self.last_unexpected = unexpected and trusted_violation
        self.last_comparison = comparison
        stop = ""
        if trusted_violation:
            self.batch_misses += 1
        if trusted_violation and self.batch_misses >= MISSES_BEFORE_HALT:
            dropped = len(self.queue)
            self.queue.clear()
            stop = (f"the world model MISPREDICTED {self.batch_misses} steps of this batch (see "
                    f"NOTE); {dropped} remaining action(s) dropped")
            self.halted_reason = stop
        elif trusted_violation:
            # One miss no longer throws the batch away. Predictions are violated on more than half
            # of all steps -- 27 of 50 turns in a real ls20 run, 38 of 67 in an offline one -- so a
            # halt on the first miss capped a batch at about two actions however many were
            # committed, which is exactly what the runs show: 2.36 actions a turn while the level
            # allows 110. Most of those misses are harmless, a step that moved the body somewhere
            # other than predicted rather than a plan that has become nonsense, and the next step's
            # prediction is checked just as strictly. Two misses in one batch is a model that has
            # lost the thread, and that still stops it.
            stop = (f"a claim was wrong on this step (see NOTE); the batch continues, and a second "
                    f"miss will drop it")
        elif violated and not self.queue:
            stop = "batch complete (a claim was wrong, but the action had not been seen before: recorded, not halted)"
        elif rec.outcome["level_completed"]:
            self.queue.clear()
            stop = "level completed; re-ground on the new level"
        elif rec.outcome["game_over"]:
            self.queue.clear()
            stop = "GAME_OVER"
        elif not self.queue:
            stop = "batch complete"
        if stop:
            self.last_outcome_line = predict.outcome_line(
                rec.prediction, comparison, rec.action, self.batch_executed, self.batch_requested,
                self.batch_level_before, rec.level + (1 if rec.outcome["level_completed"] else 0),
                batch=self.batch_sig.split(" ") if self.batch_sig else None, reason=stop)
        if not self.queue and self.batch_sig:
            self.doom_ring.append((self.batch_sig, rec.after_fp))
            self.doom_ring = self.doom_ring[-2 * DOOM_THRESHOLD:]
            if "noop" in delta.tags:
                self.memory.note_tried(f"{self.batch_sig} changed nothing", rec.idx, rec.level)

    def _resolve_hypotheses(self, rec: Record, delta, scalars_before: dict[str, int],
                            scalars_after: dict[str, int]) -> None:
        """A hypothesis whose discriminating test has now been run is settled by the harness.

        The model proposes competing explanations and the single observation that separates
        them; when that action is executed the harness grades the prediction the same way it
        grades any other claim, marks the hypothesis supported or refuted, and closes the test.
        Without this the pair keeps disagreeing forever and every turn is a VERIFY turn (seen in
        a 126-step run: 40 of 65 turns).
        """
        for hid, test in list(self.hyp_tests.items()):
            if test.get("test_action") != rec.action:
                continue
            claim = Claim(var=test["predicted_var"], op=test["predicted_op"],
                          value=schemas._parse_value(test["predicted_op"], test["predicted_value"]),
                          p=0.6, hypothesis=hid)
            probe = Prediction(pid=f"hyp.{hid}", step=1, action=rec.action, claims=[claim])
            try:
                result = predict.compare(probe, delta, scalars_before, scalars_after,
                                         veiled_vars=self._comover_vars(delta))
            except Exception:  # noqa: BLE001 - a malformed test settles nothing, it just closes
                self.hyp_tests.pop(hid, None)
                continue
            hyp = self.memory.hypotheses.get(hid)
            verdict = "untestable"
            if result.matched:
                verdict = "supported"
            elif result.violated:
                verdict = "refuted"
            if hyp is not None and verdict != "untestable":
                hyp.status = verdict
                hyp.evidence.append(rec.idx)
            self.hyp_tests.pop(hid, None)
            self._log_row({"kind": "hypothesis_settled", "turn": self.turn_index, "hid": hid,
                           "verdict": verdict, "claim": (hyp.claim[:120] if hyp else ""), "step": rec.idx})

    def body_state(self, snap: Any = None) -> str:
        """A short name for the state the body was in, for keying what a button does.

        Its shape, colour-blind, across every part that moves with it. A body that turns changes
        shape, and a button that means "forward" then means different directions at different
        times. Pooled, that action is unlearnable: every press contradicts the last. This is the
        cheapest state worth splitting on and it costs nothing to compute.
        """
        tracks = getattr(snap, "tracks", None) if snap is not None else None
        forms = []
        for tid in (self.tracker.self_group() or []):
            t = (tracks or {}).get(tid) if tracks else self.tracker.tracks.get(tid)
            form = getattr(t, "form_hash", None)
            if form:
                forms.append(str(form))
        return ("+".join(sorted(forms)))[:24]

    def _note_touched(self, rec: Record, delta) -> None:
        """Remember which objects the body has actually reached.

        The planner searches over a `touched` set, and starting every turn with that set empty
        made a collection goal unsolvable in practice: standing next to the first target, the
        solver kept returning the same one-step plan to touch it, turn after turn, because it had
        no memory that the step had already been taken. Reached objects are a fact, so the harness
        keeps them, not the search.
        """
        after = rec.after_snap
        if after is None or not after.self_tid:
            return
        # The whole body, not just the track carrying its name: a sprite that welds and unwelds
        # leaves self_tid on one part, and reaching something with an arm still reaches it.
        group = set(self.tracker.self_group()) or {after.self_tid}
        mine: set = set()
        for tid in group:
            t = after.tracks.get(tid)
            if t is not None and getattr(t, "cells", None):
                mine |= set(t.cells)
        if not mine:
            # The group is read from the tracker as it is now, and this snapshot is from a step
            # that may predate a rename. Falling through here would record no reach at all, which
            # is how a whole run ended up holding one reach mark.
            me = after.tracks.get(after.self_tid)
            mine = set(me.cells) if me is not None and getattr(me, "cells", None) else set()
            group = {after.self_tid}
        if not mine:
            return
        # Strict overlap, matching the solver's own `transition`: anything looser would let the
        # harness call a goal met that the planner would still be searching for, and the two must
        # agree about what "reached" means or the promise check grades the wrong claim.
        footprint = mine
        if mine:
            self.stood_on.add((min(r for r, _c in mine), min(c for _r, c in mine)))
        for tid, track in after.tracks.items():
            if tid in group or not track.cells:
                continue
            if footprint & set(track.cells):
                self.touched_tids.add(tid)
                self.touched_marks.add(frozenset(track.cells))
        for tid in list(delta.objects.consumed) + list(delta.objects.vanished):
            self.touched_tids.add(tid)
            gone = after.tracks.get(tid) or (rec.before_snap.tracks.get(tid)
                                             if rec.before_snap is not None else None)
            if gone is not None and getattr(gone, "cells", None):
                self.touched_marks.add(frozenset(gone.cells))

    def reached(self, cells_of: dict) -> set:
        """Which of these objects the body has reached, matching by id or by where they are.

        `cells_of` maps the ids a goal is written over to their cells right now. An id that was
        reached under an older name still counts, because what was reached is a place on the
        board, not a row in the tracker's book.
        """
        out = set()
        for tid, cells in cells_of.items():
            if tid in self.touched_tids or frozenset(cells) in self.touched_marks:
                out.add(tid)
        return out

    def _mine_contacts(self, rec: Record, delta) -> None:
        """Feed the precondition miner one row per object the controlled body touched.

        The generic shape of an elimination game: touching a thing sometimes consumes it and
        sometimes does nothing, and what separates the two cases is the precondition. The harness
        cannot guess the precondition, but it can tabulate the boolean state at every contact and
        score each single feature as "succeeds iff f", which turns "why did that one refuse?"
        into a fact line the model only has to name.
        """
        before, after = rec.before_snap, rec.after_snap
        if before is None or not before.self_tid:
            return
        me = before.tracks.get(before.self_tid)
        if me is None or not me.cells:
            return
        touched: dict[str, bool] = {}
        neighbourhood = {(r + dr, c + dc) for r, c in me.cells
                         for dr, dc in ((0, 0), (-1, 0), (1, 0), (0, -1), (0, 1))}
        gone = set(delta.objects.vanished) | set(delta.objects.consumed)
        changed = {tid for tid, _f, _t in delta.objects.recoloured}
        for tid, track in before.tracks.items():
            if tid == before.self_tid or not track.cells or track.state != "LIVE":
                continue
            if neighbourhood & set(track.cells):
                touched[tid] = tid in gone or tid in changed
        if not touched:
            return
        base = {f"consumed[{k[9:-1]}]>0": v > 0 for k, v in before.scalars.items()
                if k.startswith("consumed[")}
        base.update({f"none_left[{k[10:-1]}]": v == 0 for k, v in before.scalars.items()
                     if k.startswith("remaining[")})
        base[f"self_is_{me.letter}"] = True
        for tid, success in touched.items():
            track = before.tracks[tid]
            features = dict(base)
            features[f"target_is_{track.letter}"] = True
            features[f"action_{rec.action[-1]}"] = True
            try:
                self.miner.record_contact(features, success)
            except Exception:  # noqa: BLE001 - a fact line must never break the run
                return

    def _comover_vars(self, delta) -> set[str]:
        """pos[] names of tracks that moved exactly like self this step (a rigid body's other
        parts) and of hud-region tracks: their changes are not surprises about the world."""
        self_tid = self.tracker.self_tid
        veiled: set[str] = set()
        shift = None
        for tid, d in delta.objects.moved:
            if tid == self_tid:
                shift = tuple(d)
        for tid, d in delta.objects.moved:
            if tid != self_tid and (shift is not None and tuple(d) == shift):
                veiled |= {f"pos[{tid}].r", f"pos[{tid}].c"}
        for t in self.tracker.live():
            if t.klass == "hud":
                veiled |= {f"pos[{t.tid}].r", f"pos[{t.tid}].c"}
        veiled |= {k for k in self.scalars() if k.startswith("hud[")}
        return veiled

    def _observe_passability(self, action: str, before_snap: Any, delta) -> None:
        """What colour was one step beyond the body, on the frame the action was taken in?

        Both halves have to come from BEFORE the action. This runs inside `observe`, where the
        tracker has already been advanced onto the new frame and `prev_percept` has not yet been
        rolled forward -- so `tracker.tracks[...]` is where the body ENDED UP and `prev_percept`
        is two frames back. Reading those, every observation asked what lies one shift beyond the
        body's new position on a stale board, which is how a passability map ends up inverted.
        `self.percept` is still the acted-in frame at this point, and `before_snap` is the body
        as it was; those are the two sources this uses.
        """
        self_tid = self.tracker.self_tid
        if not self_tid or self.percept is None:
            return
        shift = self.control.expected_shift(action)
        tr = self.tracker.tracks.get(self_tid)
        if tr is None or shift is None:
            return
        moved = any(t == self_tid for t, _ in delta.objects.moved)
        snap = getattr(before_snap, "tracks", {}).get(self_tid) if before_snap is not None else None
        own = getattr(snap, "cells", None)
        bbox = getattr(snap, "bbox", None)
        if own is None:
            own = tr.blob.cells if tr.blob is not None else frozenset()
            bbox = tr.last_bbox
        dr, dc = shift
        grid = self.percept.grid
        targets: list[int] = []
        for (r, c) in own:
            rr, cc = r + dr, c + dc
            if (rr, cc) in own or not (0 <= rr < len(grid) and 0 <= cc < len(grid[0])):
                continue
            targets.append(int(grid[rr][cc]))
        try:
            self.passability.observe(action, bbox or tr.last_bbox, moved, targets)
        except Exception:  # noqa: BLE001
            pass

    def _win_facts(self) -> str:
        """What was true one step before the win (v8_memory's win signature, harness-computed)."""
        rec = self.ledger.last()
        if rec is None or rec.before_snap is None:
            return ""
        sc = rec.before_snap.scalars
        keep = [f"{k}={v}" for k, v in sorted(sc.items())
                if k.startswith(("consumed[", "remaining[", "objs[")) and not k.startswith("objs[B")]
        self_tid = rec.before_snap.self_tid
        if self_tid and f"pos[{self_tid}].r" in sc:
            keep.append(f"self at ({sc[f'pos[{self_tid}].r']},{sc[f'pos[{self_tid}].c']})")
        keep.append(f"winning action {rec.action}")
        return "; ".join(keep)[:300]

    def level_comparison(self, previous: int, *, was: Optional[dict[str, int]] = None,
                         now: Optional[dict[str, int]] = None) -> dict[str, Any]:
        """What is the same as the level just left, and what is different.

        Both halves are hypotheses, and the same half is the one that is easy to skip. A class
        that looks identical is not known to behave identically: the board is new and last level's
        law is a claim about a different board until this one supports it. So the harness writes a
        hypothesis for what carried over as well as for what did not, each one naming what it
        expects and the memory it came from, and the ledger settles them as actions arrive.
        """
        old_tracks = (self.tracker.archived.get(previous) or {}) if hasattr(self.tracker, "archived") else {}
        from .symbols import shape_name

        def census(tracks) -> dict[str, int]:
            out: dict[str, int] = {}
            for t in (tracks.values() if isinstance(tracks, dict) else tracks):
                blob = getattr(t, "blob", None)
                if blob is None:
                    continue
                key = f"{colour_letter(t.colour)} {shape_name(blob.cells, t.last_bbox)}"
                out[key] = out.get(key, 0) + 1
            return out

        # Both censuses are taken by the caller at the boundary, because neither is readable
        # from here afterwards: `archive_level` empties the live table, and what it archives
        # under the old level's key is the NEW board (the tracker is advanced before the level
        # change is noticed), so the archive is not the old level either. Read from here, every
        # comparison came out as "everything from the last level is gone".
        if was is None:
            was = census(old_tracks)
        if now is None:
            now = census(self.tracker.live())
        same = {k: now[k] for k in sorted(set(was) & set(now)) if was[k] == now[k]}
        changed = {k: (was[k], now[k]) for k in sorted(set(was) & set(now)) if was[k] != now[k]}
        gone = {k: was[k] for k in sorted(set(was) - set(now))}
        fresh = {k: now[k] for k in sorted(set(now) - set(was))}
        return {"same": same, "changed": changed, "gone": gone, "new": fresh,
                "was_total": sum(was.values()), "now_total": sum(now.values())}

    def level_census(self) -> dict[str, int]:
        """How many live things of each colour-and-shape class are on the board right now."""
        from .symbols import shape_name
        out: dict[str, int] = {}
        for t in self.tracker.live():
            blob = getattr(t, "blob", None)
            if blob is None:
                continue
            key = f"{colour_letter(t.colour)} {shape_name(blob.cells, t.last_bbox)}"
            out[key] = out.get(key, 0) + 1
        return out

    def seed_level_hypotheses(self, previous: int, *, was: Optional[dict[str, int]] = None,
                              now: Optional[dict[str, int]] = None) -> int:
        """Open a hypothesis for everything the new board carried over AND everything it did not.

        A thing that looks the same is the easiest thing to assume about and the easiest to be
        wrong about, so it gets a hypothesis too, phrased against the memory that suggests it.
        """
        cmp = self.level_comparison(previous, was=was, now=now)
        self.level_diff = cmp
        opened = 0
        for kind, items in (("same", cmp["same"]), ("new", cmp["new"]),
                            ("gone", cmp["gone"]), ("changed", cmp["changed"])):
            for key in list(items)[:HYPOTHESES_PER_KIND]:
                if kind == "same":
                    claim = (f"{key} behaves on this level as it did on level {previous}: "
                             f"same colour and shape, so assume the same law until a step says not")
                elif kind == "new":
                    claim = f"{key} is new on this level and its law is unknown"
                elif kind == "gone":
                    claim = f"{key} was on level {previous} and is not here; what it did may not apply"
                else:
                    was, now_n = items[key]
                    claim = f"there were {was} {key} on level {previous} and {now_n} here; the count is part of the level"
                self.memory.add_hypothesis(claim, f"act next to a {key} and watch what changes", self.turn_index)
                opened += 1
        self._log_row({"kind": "level_hypotheses", "turn": self.turn_index, "level": self.level,
                       "opened": opened, "same": list(cmp["same"])[:6], "new": list(cmp["new"])[:6],
                       "gone": list(cmp["gone"])[:6], "changed": list(cmp["changed"])[:6]})
        return opened

    def _on_level_change(self, level: int) -> None:
        previous_level = self.level          # captured before it is reassigned below
        win = self._win_facts()
        summary = {"summary": f"cleared with {self.level_actions} actions; self={self.tracker.self_tid}; "
                              f"controls: {self.control.render()[:120]}; one step before the win: {win}",
                   "self_tid": self.tracker.self_tid, "actions": self.level_actions, "win_facts": win}
        self.memory.on_level_clear(self.level, self.turn_index, summary)
        # Both halves of the comparison, read while they still exist: the new board is live now
        # and `archive_level` is about to empty it, and the old board is only in the census kept
        # step by step while that level was being played.
        was_census = dict(self._level_census)
        now_census = self.level_census()
        self.tracker.archive_level(self.level)
        fresh = control_mod.ControlMap()
        fresh.inherit(self.control, factor=0.5)
        self.control = fresh
        self.passability = facts.Passability()
        self.consumption = facts.Consumption()
        self.level = level
        self.level_actions = 0
        self.new_level_pending = True
        self.symbolic_goal = None          # a new level is a new goal; the old one is level_log now
        self.touched_tids = set()          # and a new board: nothing on it has been reached yet
        self.touched_marks = set()
        self.stood_on = set()
        self.moved_tids = set()
        self.retired_goals = set()         # a goal that failed here says nothing about the next level
        # A promise about the old board cannot be graded against the new one, and the counters
        # that decide "twice is a loop" are about this level's plans.
        self.plan_promise = False
        self.plan_broken = 0
        self.plan_repeat = 0
        self.plan_sig = ""
        self.unreachable = 0
        self.unreachable_goal = ""
        self.hyp_tests = {}                # tests written for a board that is gone
        self.doom_ring = []
        self.recent_batches = []
        self.consecutive_recover = 0
        try:
            self.seed_level_hypotheses(previous_level, was=was_census, now=now_census)
        except Exception as exc:  # noqa: BLE001
            self._log_row({"kind": "level_hypotheses_failed", "turn": self.turn_index,
                           "error": repr(exc)[:160]})
        self.last_plan = planner.PlanResult(status="no_goal")
        self.queue.clear()
        self.rules.rescore_all(self.ledger)

    # -- scalars and snapshots ---------------------------------------------------------------------

    def scalars(self, percept: Any = None) -> dict[str, int]:
        p = percept or self.percept
        out: dict[str, int] = {}
        if p is not None:
            out.update(p.scalars)
        out.update(self.tracker.positions())
        try:
            out.update(self.consumption.scalars())
        except Exception:  # noqa: BLE001
            pass
        out["step"] = self.step
        out["level"] = self.level
        return out

    def _snapshot(self, percept: Any = None) -> Any:
        try:
            return rules.Snapshot.from_tracker(self.tracker, self.scalars(percept), step=self.step, level=self.level)
        except Exception:  # noqa: BLE001
            return None

    def _repl_payload(self) -> dict[str, Any]:
        return {
            "objects": [self._track_row(t) for t in self.tracker.live()],
            "ledger": [self._record_row(r) for r in self.ledger.records[-200:]],
            "rules": [asdict(r) for r in self.rules.top(20)],
            "frame": self.percept.grid if self.percept else None,
            "control": self.control.render(),
            "scalars": self.scalars(),
            "questions": [asdict(q) for q in self.memory.open_questions()],
        }

    @staticmethod
    def _track_row(t) -> dict[str, Any]:
        return {"tid": t.tid, "colour": t.colour, "bbox": list(t.last_bbox), "state": t.state.value,
                "klass": t.klass, "label": t.label, "flags": dict(t.flags), "events": len(t.events)}

    @staticmethod
    def _record_row(r: Record) -> dict[str, Any]:
        return {"idx": r.idx, "step": r.step, "level": r.level, "action": r.action, "tags": list(r.delta.tags),
                "cells": r.delta.cells.n, "moved": [(t, list(d)) for t, d in r.delta.objects.moved],
                "vanished": list(r.delta.objects.vanished), "scalars": {k: list(v) for k, v in r.delta.scalars.items()},
                "matched": len(r.comparison.matched) if r.comparison else None,
                "violated": len(r.comparison.violated) if r.comparison else None,
                "level_completed": r.outcome.get("level_completed")}

    # -- the model turn ----------------------------------------------------------------------------

    def run_turn(self) -> None:
        # Before the first model request of a game: spend the cheap actions the harness can
        # choose itself, so the first prompt carries a measured control map instead of nothing.
        if not self.ledger.records and not self.probe_done and not self.config_flag("no_opening_probe"):
            self.probe_done = True
            if self.queue_opening_probe():
                self.current_mode = Mode.ORIENT
                self.last_outcome_line = ("The harness pressed each available action once to see what it does; "
                                          "the MAP block below is what it measured.")
                return
        # The batch that just ended may have been a plan that promised to reach the goal. Grade
        # that promise before choosing a mode, so a plan that ran clean and missed is not simply
        # re-solved into the identical answer.
        self.check_plan_promise()
        self.turn_index += 1
        st = TurnState(session=self, turn=self.turn_index)
        st = self.graph.run(st)
        self.current_mode = st.mode
        if st.mode == Mode.RECOVER:
            self.consecutive_recover += 1
        else:
            self.consecutive_recover = 0
        if st.mode == Mode.ORIENT and not (st.harness_measures or st.harness_explores):
            # A turn the harness took for itself is not an orientation. `mode()` drops every role
            # when it decides to measure or explore, and marking the level oriented anyway spent
            # the level's only ORIENT turn on a probe: `orient` is the sole producer of entity
            # labels, the memory plan and the goal hypotheses, and (novelty aside) ORIENT does not
            # come back. ACTION6 is never in the opening probe, so on any game that offers it the
            # very first turn took this branch.
            self.oriented_level = self.level
            self.new_level_pending = False

    def build_vocab(self) -> schemas.Vocab:
        v = schemas.Vocab(
            tids={t.tid for t in self.tracker.live()},
            actions=set(self.available) | {"RESET"},
            scalars=set(self.scalars().keys()),
            rule_ids={r.rid for r in self.rules.top(50)},
            hypothesis_ids={h.hid for h in self.memory.open_hypotheses()},
            question_ids={q.qid for q in self.memory.open_questions()},
            slot_names=set(self.memory.slots),
            known_games=self.store.known_games(),
            ledger_len=len(self.ledger),
        )
        self.current_vocab = v
        return v

    def state_blocks(self, mode: Mode, reason: str) -> prompts.StateBlocks:
        b = prompts.StateBlocks()
        b.job = (f"game {self.game_id.split('-')[0]} level {self.level}/{self.n_levels or '?'} turn {self.turn_index} "
                 f"step {self.step} mode {mode.value} ({reason}). {self._budget_line()}")
        b.grid, b.delta = self._board_blocks()
        b.sym = self._symbol_block()
        b.obj = diffing.render_object_table(self.tracker, self.percept, max_rows=14, self_tid=self.tracker.self_tid)
        labels = "; ".join(f"{tid}={lab}/{role}" for tid, (lab, role, _p) in list(self.memory.labels.items())[:10])
        if labels:
            b.obj += f"\n     labels: {labels}"
        b.last = self.last_outcome_line
        if self.percept is not None and self.prev_percept is not None and self.ledger.records:
            b.last += "\n     " + diffing.render_diff(self.ledger.records[-1].delta)
        b.vars = self._vars_line()
        b.rules = self._rules_block() or "no rules yet"
        # Conclusions first, tallies after: the block is clipped from the end, so a validated
        # plan and the separating feature must never be the part that falls off.
        map_parts = []
        if self.last_plan.status == "found":
            map_parts.append(planner.render_plan(self.last_plan))
        separators = self.miner.render() if hasattr(self.miner, "render") else ""
        if separators:
            map_parts.append(separators)
        diff = self.level_diff_text()
        if diff:
            map_parts.append(diff)
        arr = self.arrangement_facts()
        if arr:
            map_parts.append(arr)
        map_parts.append(self.control.render())
        # Only when splitting by body state actually rescues an action the pooled reading cannot
        # settle. Otherwise this is noise in a block with a hard character budget.
        try:
            ctx_line = self.control.render_contexts()
        except Exception:  # noqa: BLE001
            ctx_line = ""
        if ctx_line:
            map_parts.append("the same buttons, split by what shape the body was in at the time "
                             "(this is why they looked inconsistent): " + ctx_line)
        map_parts.append(self.passability.render())
        if self.last_plan.status != "found":
            map_parts.append(planner.render_plan(self.last_plan))
        b.map = " | ".join(p for p in map_parts if p)
        mem = [f"goals: {self.memory.render_goals()}", f"hypotheses: {self.memory.render_hypotheses()}",
               f"questions: {self.memory.render_questions()}"]
        settled = self.memory.render_settled()
        if settled:
            mem.append(f"settled: {settled}")
        lvl = self.memory.render_level_log(self.level)
        if lvl:
            mem.append(lvl)
        tried = self.memory.render_tried(self.level)
        if tried:
            mem.append(f"tried and failed: {tried}")
        slots = self.memory.render_slots()
        if slots:
            mem.append(f"your slots: {slots}")
        if self.memory.priors:
            mem.append("priors from earlier games (hypotheses, not facts): " + "; ".join(
                f"{p['pattern']} (p={p['confidence']:.2f})" for p in self.memory.priors[:3]))
        cons = self.consumption.render() if hasattr(self.consumption, "render") else ""
        if cons:
            mem.append(cons)
        b.mem = " | ".join(mem)
        b.ask = ""  # the ASK text is part of the user prompt, not the state
        return b

    def _rules_block(self, k: int = 6) -> str:
        rows = []
        seen = set()
        ordered = list(self.rules.usable()) + [r for r in self.rules.top(50) if r not in self.rules.usable()]
        for r in ordered:
            text = rules.describe_rule(r) if hasattr(rules, "describe_rule") else r.text
            if text in seen:
                continue
            seen.add(text)
            sc = r.score
            rows.append(f"{r.rid} {r.type} {text} {sc.support}/{sc.contradict} conf {sc.conf:.2f} {sc.status}"
                        f"{' STALE' if sc.stale else ''}{' (usable)' if r in self.rules.usable() else ''}")
            if len(rows) >= k:
                break
        return "\n".join(rows)

    def _symbol_block(self) -> str:
        """The board as named symbols with the arithmetic between them already done."""
        if self.percept is None:
            return ""
        live = self.tracker.live()
        self_tid = self.tracker.self_tid
        parts = [dsl_facts.board_facts(self.percept.grid),
                 symbols.symbol_table(live, self_tid=self_tid, max_rows=12)]
        me = self.tracker.tracks.get(self_tid) if self_tid else None
        if me is not None:
            rel = dsl_facts.relations_text(me, live, max_rows=8)
            if rel:
                parts.append("from the body you control:\n" + rel)
        if self.symbolic_goal:
            parts.append(f"goal you set: {goals.describe(self.symbolic_goal)}")
        return "\n".join(p for p in parts if p)

    def _board_blocks(self) -> tuple[str, str]:
        """The board as characters, and what the last action changed, in both asked-for forms."""
        if self.percept is None:
            return "", ""
        bg = self.percept.background
        grid = (f"legend: {render.legend(self.percept.grid, bg)}\n"
                + render.grid_text(self.percept.grid, bg))
        rec = self.ledger.last()
        if rec is None or self.prev_percept is None:
            return grid, ""
        before, after = self.prev_percept.grid, self.percept.grid
        effect = ""
        try:
            shift = self.control.expected_shift(rec.action)
            if shift is not None:
                effect = f"has moved the controlled body {tuple(shift)} before"
        except Exception:  # noqa: BLE001
            effect = ""
        deltas = render.cell_deltas(before, after, step=rec.idx, action=rec.action, effect=effect)
        changed = render.change_text(before, after, bg, indices=True)
        # Only rows that changed are drawn; the row numbers keep them aligned with GRID.
        changed_rows = render.grid_text(
            after, bg, indices=True,
            only={(r, c) for r, c, _o, _n in render.changed_cells(before, after)}, blank_rows=True)
        return grid, f"{deltas}\nchanged cells only (rows unchanged everywhere are omitted):\n{changed_rows or changed}"

    def _budget_line(self) -> str:
        cap = float(_flag(self.config, "cap_minutes", 0) or 0)
        line = f"{self.level_actions} actions this level."
        if not cap or self.turn_index <= 1 or not hasattr(self, "_t_start"):
            return line
        elapsed = time.monotonic() - self._t_start
        per_turn = elapsed / max(1, self.turn_index - 1)
        left = max(0, int((cap * 60 - elapsed) / max(1.0, per_turn)))
        return line + f" About {left} turns left in this run."

    def _vars_line(self) -> str:
        """Exact registry names, because a claim's `var` must be one of them (grammar-enforced)."""
        sc = self.scalars()
        parts = []
        objs = sorted((k, v) for k, v in sc.items() if k.startswith("objs[") and v)
        parts.append(" ".join(f"{k}={v}" for k, v in objs[:10]))
        cells = sorted((k, v) for k, v in sc.items() if k.startswith("cells[") and v)
        parts.append(" ".join(f"{k}={v}" for k, v in cells[:8]))
        hud = [f"{k}={v}" for k, v in sc.items() if k.startswith("hud[")]
        if hud:
            parts.append(" ".join(hud[:4]))
        cons = [f"{k}={v}" for k, v in sc.items() if k.startswith(("consumed[", "remaining["))]
        if cons:
            parts.append(" ".join(cons[:6]))
        if self.tracker.self_tid:
            t = self.tracker.self_tid
            parts.append(f"self={t} pos[{t}].r={sc.get(f'pos[{t}].r', '?')} pos[{t}].c={sc.get(f'pos[{t}].c', '?')} "
                         f"(claim its move as obj:{t}.pos delta (dr,dc))")
        return " | ".join(p for p in parts if p)

    def call_role(self, role: str, mode: Mode, max_tokens: int) -> Optional[dict[str, Any]]:
        # First, before a prompt is even rendered: a paid endpoint has a ceiling, and the point of
        # a ceiling is that nothing is spent past it. The harness keeps playing on its own plans
        # and probes; the run ends through done_reason rather than through a failure.
        if getattr(self.model, "over_budget", lambda: False)():
            spent = float(getattr(self.model, "total_cost", 0.0) or 0.0)
            limit = float(getattr(self.model, "cost_limit", 0.0) or 0.0)
            self.done_reason = f"cost_limit (${spent:.4f} of ${limit:.2f})"
            self._log_row({"kind": "cost_limit", "turn": self.turn_index, "spent": round(spent, 4),
                           "limit": limit, "calls": int(getattr(self.model, "calls", 0) or 0)})
            return None
        vocab = self.build_vocab()
        blocks = self.state_blocks(mode, getattr(self, "_mode_reason", ""))
        # (set in nodes.mode() as soon as the mode is chosen; it used to be assigned only at the
        # end of the turn, so every prompt stated this turn's mode beside last turn's reason.)
        state_text = prompts.render_state(blocks)
        extra = ""
        if role == "goal" and self.plan_note:
            extra = self.plan_note + " Set a different goal: a different object, a whole class, or a position."
        elif role == "goal" and self.last_plan.status not in ("found", "no_goal"):
            extra = (f"Your last goal \"{self.last_plan.goal_text}\" could not be solved: "
                     f"{self.last_plan.status} ({self.last_plan.note}). Set one the solver can reach.")
        if role in ("decide", "decide_lean") and self.hyp_tests:
            extra = "Open hypothesis tests: " + "; ".join(
                f"{hid}: {t['test_action']} -> {t['predicted_var']} {t['predicted_op']} {t['predicted_value']}"
                for hid, t in list(self.hyp_tests.items())[-3:])
        if role == "goal":
            self.plan_note = ""
        user = prompts.user_prompt(role, mode, state_text, available=sorted(self.available), extra=extra)
        system = prompts.SYSTEM[role] + " " + prompts.effort_sentence(mode)
        validator = schemas.VALIDATORS[role]
        thinking = bool(_flag(self.config, "thinking", False)) if role in ("decide", "decide_lean", "hypothesis", "critic") else False
        started = time.monotonic()
        schema = schemas.SCHEMAS[role]

        def _check(o: Any, _v=vocab, _f=validator, _s=schema):
            # Shape first: a reply missing a field every schema marks required is not something to
            # read, and a gateway does not guarantee the grammar it was asked for.
            problem = schemas.validate_shape(o, _s)
            if problem:
                return problem
            try:
                return _f(o, _v)
            except Exception as exc:  # noqa: BLE001
                # `validate_shape` only fills in required fields one level deep, so a malformed
                # entry inside `step_predictions[].expect[]` or `memory_patch.new_rules[]` still
                # reaches the validator and raises. Nothing above this catches it: it would come
                # out through the graph and end the whole game, which is the exact failure the
                # shape check was added to stop. A bad reply is worth one repair round, not a run.
                self._log_row({"kind": "validator_raised", "turn": self.turn_index, "role": role,
                               "error": repr(exc)[:200]})
                return (f"the reply could not be read ({type(exc).__name__}); "
                        "send the fields the schema requires")

        result = self.model.call_json(role=role, system=system, user=user, schema=schema,
                                      max_tokens=max_tokens, thinking=thinking,
                                      validate=_check,
                                      on_attempt=lambda a: self._log_call(role, mode, a, user))
        self.generated_tokens += int(result.usage.get("out", 0))
        if result.obj is None:
            # Two different failures, two different counters. `failed_calls` was incremented for
            # a schema rejection as well as a dropped connection, and the verdict it gates is
            # "the model is unreachable" -- so five bounced answers followed by one transient
            # network error ended the run with the wrong reason and a live endpoint.
            self.failed_calls += 1
            unreachable = bool(result.error and result.error.startswith("request_error"))
            self.unreachable_calls = (self.unreachable_calls + 1) if unreachable else 0
            self._log_row({"kind": "role_failed", "turn": self.turn_index, "role": role, "error": result.error,
                           "latency_s": round(result.latency_s, 1)})
            if self.unreachable_calls >= 6:
                self.done_reason = "model_unreachable"
            return None
        self.failed_calls = 0
        self.unreachable_calls = 0
        return result.obj

    def apply_role_output(self, role: str, out: dict[str, Any], st: TurnState) -> None:
        turn = self.turn_index
        if role == "interpret":
            for lab in out["labels"]:
                self.memory.set_label(lab["tid"], lab["label"], lab["role"], lab["p"])
                self._label_track(lab["tid"], lab["label"])
            for tid in out["salient"]:
                self.memory.plan_move(tid, "watch")
            for q in out["new_questions"]:
                self.memory.add_question(q, turn)
        elif role == "orient":
            for lab in out["entities"]:
                self.memory.set_label(lab["tid"], lab["label"], lab["role"], lab["p"])
                self._label_track(lab["tid"], lab["label"])
            for key in ("track", "watch", "ignore"):
                for tid in out["memory_plan"][key]:
                    self.memory.plan_move(tid, key)
            for q in out["questions"]:
                self.memory.add_question(q, turn)
            for g in out["goal_hypotheses"]:
                self.memory.add_goal(g["text"], g["p"])
            self.memory.level_log.append({"level": self.level, "turn": turn, "orientation": out["summary"][:300],
                                          "control_claims": out["control_model"]})
        elif role == "critic":
            self._apply_critic(out)
        elif role == "goal":
            self._apply_goal(out)
        elif role == "hypothesis":
            for h in out["hypotheses"]:
                hyp = self.memory.add_hypothesis(h["claim"], h["discriminator"], turn)
                self.hyp_tests[hyp.hid] = {k: h[k] for k in ("test_action", "predicted_var", "predicted_op", "predicted_value")}
        elif role in ("decide", "decide_lean"):
            self.model_confidence = dict(out["confidence"])
            self._apply_memory_patch(out["memory_patch"], st)

    def _apply_goal(self, out: dict[str, Any]) -> None:
        """Assemble the goal term from the filled-in form and keep it if it compiles."""
        js = schemas.goal_term(out)
        world = planner.goal_world(self)
        if world is not None:
            compiled = goals.compile_goal(js, world)
            if isinstance(compiled, goals.GoalReject):
                self._log_row({"kind": "goal_rejected", "turn": self.turn_index, "form": out,
                               "term": js, "reason": str(compiled)})
                return
        chosen = js
        self.symbolic_goal = chosen
        self.memory.add_goal(goals.describe(chosen), float(out.get("p", 0.5)))
        self._log_row({"kind": "goal_set", "turn": self.turn_index, "goal": chosen,
                       "text": goals.describe(chosen), "why": str(out.get("why", ""))[:200],
                       "p": out.get("p")})

    def _label_track(self, tid: str, label: str) -> None:
        t = self.tracker.tracks.get(tid)
        if t is not None:
            t.label = label[:24]

    def _apply_critic(self, out: dict[str, Any]) -> None:
        fix = follow_up(out["kind"], out.get("fix", "none"))
        self._log_row({"kind": "critic", "turn": self.turn_index, "verdict": out["kind"], "fix": fix,
                       "explanation": out["explanation"]})
        # Four of the eight critic kinds routed to `retrack` or `demote_control`, and neither
        # method existed anywhere in the package -- so RECOVER spent a 700-token call on a verdict
        # that, half the time, did nothing at all. Both are implemented now, and a `replan` is a
        # real follow-up too: it drops the standing plan so the next turn solves again rather than
        # re-committing the one that just failed.
        if fix == "retrack":
            self._log_row({"kind": "retrack", "turn": self.turn_index,
                           "max_shift": self.tracker.widen()})
        elif fix == "demote_control" and self.ledger.records:
            act = self.ledger.records[-1].action
            self.control.demote(act)
            self._log_row({"kind": "demote_control", "turn": self.turn_index, "action": act})
        elif fix == "replan":
            self.last_plan = planner.PlanResult(status="no_goal", note="re-plan after a failure")
            self.plan_sig = ""
            self.plan_repeat = 0
        elif fix == "open_question":
            self.memory.add_question(f"({out['kind']}) {out['explanation']}", self.turn_index)
        elif fix == "regoal":
            for g in self.memory.top_goals(1):
                g.p *= 0.5

    def _apply_disputes(self, disputes: list[dict[str, Any]], turn: int) -> int:
        """Act on the model arguing with what the harness holds.

        A dispute is not a deletion: the harness owns memory and the ledger decides. What it does
        is send the thing back to being a claim that has to earn its place again -- a rule returns
        to proposed and is re-scored against every row, a settled question or hypothesis reopens,
        a label loses its confidence -- and records who objected and why. Without this the model
        can only ever add, and a memory nobody is allowed to be wrong in keeps every wrong entry
        until the level ends.
        """
        acted = 0
        for d in disputes[:3]:
            target, why = str(d.get("target") or ""), str(d.get("why") or "")[:160]
            if not target:
                continue
            rule = getattr(self.rules, "rules", {}).get(target)
            if rule is not None:
                rule.status = "proposed"
                self.rules.rescore_all(self.ledger, level=self.level)
            elif target in self.memory.questions:
                self.memory.questions[target].status = "open"
            elif target in self.memory.hypotheses:
                self.memory.hypotheses[target].status = "open"
            elif target in self.memory.labels:
                # A label is a (text, role, p) tuple, not an object: `.p` raised AttributeError,
                # which nodes.py swallows, so one disputed track threw away the whole memory
                # patch it arrived with -- rules, questions and all.
                lab, lrole, lp = self.memory.labels[target]
                self.memory.labels[target] = (lab, lrole, min(lp, 0.3))
            else:
                continue
            acted += 1
            self.memory.add_question(f"disputed {target}: {why}"[:160], turn)
            self._log_row({"kind": "dispute", "turn": turn, "target": target, "why": why[:120]})
        return acted

    def _apply_memory_patch(self, mp: dict[str, Any], st: TurnState) -> None:
        # Arguing with memory comes before adding to it: a claim the record no longer supports
        # should not still be sitting there when the next one is written beside it.
        self._apply_disputes(mp.get("disputes") or [], self.turn_index)
        turn = self.turn_index
        vocab = self.current_vocab
        for tid in mp.get("promote", []):
            if tid in vocab.tids:
                self.memory.plan_move(tid, "track")
        for tid in mp.get("demote", []):
            if tid in vocab.tids:
                self.memory.plan_move(tid, "ignore")
            elif tid in vocab.rule_ids:
                self.rules.retire(tid)
        rule_vocab = self._rule_vocab()
        for r in mp.get("new_rules", []):
            js = {"type": r["type"], "when": schemas.parse_jsonish(r["when"]),
                  "then": schemas.parse_jsonish(r["then"]),
                  "because": [int(i) for i in r["because"]], "text": r.get("text", "")}
            res = self.rules.propose(js, rule_vocab, self.ledger, turn)
            self._log_row({"kind": "rule_proposal", "turn": turn, "rule": js,
                           "result": res.rid if hasattr(res, "rid") else str(res)})
        for h in mp.get("new_hypotheses", []):
            self.memory.add_hypothesis(h["claim"], h["discriminator"], turn)
        for q in mp.get("answered", []):
            self.memory.answer_question(q, turn)
        for q in mp.get("new_questions", []):
            self.memory.add_question(q, turn)
        for lab in mp.get("labels", []):
            self.memory.set_label(lab["tid"], lab["label"], lab["role"], lab["p"])
            self._label_track(lab["tid"], lab["label"])
        for g in mp.get("goals", []):
            self.memory.add_goal(g["text"], g["p"])
        for slot in mp.get("new_slots", []):
            problem = self.memory.create_slot(slot, turn)
            self._log_row({"kind": "slot", "turn": turn, "slot": slot, "result": problem or "created"})
        for e in mp.get("entries", []):
            problem = self.memory.add_entry(e["slot"], schemas.parse_jsonish(e["values"]), turn=turn, level=self.level,
                                            ledger_len=len(self.ledger), pin=bool(e.get("pin")), tids=vocab.tids)
            if problem:
                self._log_row({"kind": "slot_entry_rejected", "turn": turn, "entry": e, "reason": problem})
        for pat in mp.get("new_patterns", []):
            problem = self.store.add_pattern(pat["pattern"], pat["evidence_games"], pat["confidence"], family=self.family)
            self._log_row({"kind": "pattern", "turn": turn, "pattern": pat, "result": problem or "stored"})

    def _rule_vocab(self) -> Any:
        snap = self._snapshot()
        if snap is None:
            return rules.Vocabulary.permissive()
        return rules.Vocabulary.from_snapshot(snap, actions=set(self.available) | {"RESET"})

    # -- queueing ------------------------------------------------------------------------------------

    TOPUP_FLOOR = 4        # below this, a turn is worth more than the model asked of it

    def click_targets(self, k: int = 8) -> list[tuple[int, int]]:
        """Where to click, for a game whose only control is a click.

        Five of the twenty-four public games offer ACTION6 and nothing else (ft09, lp85, s5i5,
        su15, vc33), and the harness had no answer for them at all: ACTION6 is excluded from the
        opening probe, nothing moves when no key exists to press, so no self is ever identified,
        no control is read, no plan is built -- and the fallback probe clicked the fixed point
        (32,32) for the whole run. Measured with `harness_only`: `self=None`, `rules=0`, zero
        levels, on every one of them.

        A click game is explored by clicking THINGS. This returns the centres of distinct tracked
        objects, least-clicked first, so every press lands on something the tracker can attribute
        a change to -- which is what turns a click into evidence the control map can read.
        """
        counts = getattr(self, "_click_counts", None)
        if counts is None:
            counts = self._click_counts = {}
        rows: list[tuple[int, int, tuple[int, int]]] = []
        for t in self.tracker.live():
            blob = getattr(t, "blob", None)
            if blob is None or getattr(t, "klass", "") == "hud":
                continue
            r0, c0, r1, c1 = t.last_bbox
            spot = ((r0 + r1) // 2, (c0 + c1) // 2)
            rows.append((counts.get(spot, 0), len(blob.cells), spot))
        if not rows:
            return [(32, 32)]
        # Least-clicked first, then the bigger thing: a large untried object is the likeliest to
        # be the board's own control surface.
        rows.sort(key=lambda x: (x[0], -x[1], x[2]))
        out = [spot for _n, _px, spot in rows[:k]]
        for spot in out:
            counts[spot] = counts.get(spot, 0) + 1
        return out

    def _click_entry(self, spot: tuple[int, int]) -> dict[str, Any]:
        """ACTION6 takes x = column, y = row."""
        return {"action": "ACTION6", "x": int(spot[1]), "y": int(spot[0])}

    def explore_tail(self, room: int, start_step: int) -> list[tuple[dict[str, Any], Any]]:
        """Harness-planned steps to run AFTER the model's, onto ground nobody has stood on.

        Free: the route comes from the same certified model the planner uses, and no request is
        sent. Safe: every step carries the shift the search used, so the batch still halts on the
        first divergence -- and these steps only ever run if the model's own steps came true, so
        a wrong tail costs nothing the model had already earned.

        This exists because of what a short batch costs. Measured on the GB10, a turn is four to
        six minutes and an action is free; run `n` spent consecutive RECOVER turns on ONE action.
        And with no model at all the harness clears levels by exploring (m0r0, ar25), so the tail
        is not filler -- it is the behaviour that has actually won.
        """
        if room <= 0 or not self.tracker.self_tid:
            return []
        try:
            result = planner.explore(self, visited=frozenset(self.stood_on), max_steps=room)
        except Exception:  # noqa: BLE001
            return []
        if result.status != "explore" or not result.actions:
            return []
        out: list[tuple[dict[str, Any], Any]] = []
        for i, name in enumerate(result.actions[:room]):
            step = result.step_shifts[i] if i < len(result.step_shifts) else None
            if step is None or tuple(step) == (0, 0):
                step = self._plan_shift(name)
            if step is None or tuple(step) == (0, 0):
                break
            n = start_step + len(out)
            claims = [Claim(var="pos[self].r", op="delta", value=int(step[0]), p=0.9, hypothesis="explore"),
                      Claim(var="pos[self].c", op="delta", value=int(step[1]), p=0.9, hypothesis="explore")]
            out.append(({"action": name, "x": None, "y": None},
                        Prediction(pid=f"x{self.turn_index}.{n}", step=n, action=name, claims=claims,
                                   summary=f"harness tail: self moves {tuple(step)} onto new ground")))
        return out

    def queue_batch(self, decide: dict[str, Any], mode: Mode) -> None:
        batch, cut = schemas.truncate_batch(decide["batch"])
        preds: dict[int, dict[str, Any]] = {int(sp["step"]): sp for sp in decide["step_predictions"]}
        hyp = decide.get("hypothesis_tested") or "none"
        self.queue = []
        batch = [a if a["action"] == "ACTION6" else {"action": a["action"], "x": None, "y": None} for a in batch]
        for i, a in enumerate(batch, start=1):  # coordinates only mean something for a click
            sp = preds.get(i)
            prediction = None
            if sp is not None:
                claims = [Claim(var=c["var"], op=c["op"], value=schemas._parse_value(c["op"], c["value"]),
                                p=float(c["p"]), hypothesis=hyp) for c in sp["expect"]]
                prediction = Prediction(pid=f"p{self.turn_index}.{i}", step=i, action=a["action"], claims=claims,
                                        summary=sp.get("summary", "")[:100])
            self.queue.append((a, prediction))
        # The model asked for less than the turn is worth: fill the rest with the harness's own
        # route. Its steps go after the model's and are graded the same way, so they run only if
        # the model was right about everything before them.
        if len(self.queue) < self.TOPUP_FLOOR and mode != Mode.EXECUTE:
            tail = self.explore_tail(schemas.MAX_BATCH - len(self.queue), len(self.queue) + 1)
            if tail:
                self.queue.extend(tail)
                batch = batch + [a for a, _p in tail]
                self._log_row({"kind": "batch_topped_up", "turn": self.turn_index,
                               "model": len(batch) - len(tail), "tail": len(tail)})
        self.batch_sig = " ".join(a["action"] + (f"({a['x']},{a['y']})" if a.get("x") is not None else "") for a in batch)
        # The model's own batch is the population `starving()` is about -- "the model bought less
        # than the harness could have got for free" -- and it was the one batch never recorded
        # here. Left out, a run where the model committed one action a turn never read as
        # starving, so the harness never took the turn; and two small harness batches in a row
        # latched it true instead.
        self.recent_batches = (self.recent_batches + [len(batch)])[-4:]
        self.batch_requested = len(batch)
        self.batch_executed = 0
        self.batch_level_before = self.level
        self.halted_reason = ""
        self.batch_misses = 0
        if cut:
            self._log_row({"kind": "batch_truncated", "turn": self.turn_index, "requested": len(decide["batch"])})

    def queue_opening_probe(self) -> str:
        """Press each available action once, harness-side, before the first model turn.

        The plan's rule: action names are never assumed. With an empty ledger the model has
        nothing to reason from and its first batch is a guess that costs 2 requests; the same
        actions pressed by the harness cost zero and hand the first ORIENT a real control map.
        Predictions are the harness's own ("something changes", p=0.5), so a miss is evidence
        rather than a RECOVER.
        """
        # Two rounds, not one. An action's effect counts as known only after two readable
        # observations agree, so a single round leaves every control unknown, the planner without
        # its two certified shifts, and the agent in a recovery loop spending whole turns on single
        # probes. Measured on ls20 level 2: the pass that reached two observations per action was
        # executing four-action plans while the two that did not were still pressing one key a turn.
        once = [a for a in self.available if a not in ("RESET", "ACTION6")]
        actions = (once * 2)[: schemas.MAX_BATCH]
        # A game whose only control is a click gets clicked, on things rather than on a fixed
        # point. Without this the opening probe was empty for five of the twenty-four public
        # games and the harness started them knowing nothing and with no way to learn.
        clicks: list[tuple[int, int]] = []
        if "ACTION6" in self.available:
            room = max(0, schemas.MAX_BATCH - len(actions))
            clicks = self.click_targets(room if once else schemas.MAX_BATCH)[:room or schemas.MAX_BATCH]
        if not actions and not clicks:
            return ""
        self.queue = []
        entries = [{"action": name, "x": None, "y": None} for name in actions] + \
                  [self._click_entry(spot) for spot in clicks]
        for i, entry in enumerate(entries, start=1):
            name = entry["action"]
            claims = [Claim(var="cells", op="changed", value=None, p=0.5, hypothesis="opening_probe")]
            where = f" at ({entry['y']},{entry['x']})" if entry.get("x") is not None else ""
            self.queue.append((entry,
                               Prediction(pid=f"probe.{i}", step=i, action=name, claims=claims,
                                          summary=f"opening probe {name}{where}")))
        actions = [e["action"] for e in entries]
        self.batch_sig = " ".join(actions)
        self.recent_batches = (self.recent_batches + [len(actions)])[-4:]
        self.batch_requested = len(actions)
        self.batch_executed = 0
        self.batch_level_before = self.level
        self.halted_reason = ""
        self.batch_misses = 0
        self._log_row({"kind": "opening_probe", "turn": self.turn_index, "actions": actions,
                       "rounds": 2})
        return " ".join(actions)

    def queue_plan(self) -> None:
        """Commit the validated harness plan with harness-written predictions (zero requests):
        each step claims the self body's certified shift at p=0.9, so the first divergence halts."""
        plan = self.last_plan
        cap = self._plan_batch_cap()
        # An arrangement plan is about the pieces, not the body, so it does not go through any of
        # the body bookkeeping below.
        if getattr(plan, "piece_claims", None):
            return self._queue_arrangement(plan, cap)
        self_tid = self.tracker.self_tid
        # Predict with the shift the SEARCH used, never a second lookup. A step the harness cannot
        # state a claim for is dropped rather than committed: an empty prediction cannot be
        # violated, so committing one turns the batch halt off and lets a wrong plan run forever.
        actions, shifts = [], []
        for i, name in enumerate(plan.actions[:cap]):
            # Prefer what the simulation said this particular step would do: for a slide the
            # distance depends on where the body is standing, so no per-action number states it.
            step = plan.step_shifts[i] if i < len(plan.step_shifts) else None
            if step is None or tuple(step) == (0, 0):
                step = self._plan_shift(name)
            if not self_tid or step is None or tuple(step) == (0, 0):
                break
            actions.append(name)
            shifts.append(tuple(step))
        if not actions:
            self.queue_fallback_probe("the plan's steps carry no shift the harness can check")
            return
        self.queue = []
        for i, name in enumerate(actions, start=1):
            shift = shifts[i - 1]
            # Claimed against `pos[self]`, not against a track id. A claim naming a track that
            # has since been renamed cannot be evaluated, so it ABSTAINS, and an abstention is
            # not a violation: the batch halt stays silent. On ls20 a four-step plan put the body
            # 21 rows and 18 columns from where it said it would be and nothing halted, because
            # every claim named an id that was no longer there. `pos[self]` is the top-left of
            # the whole body's bounding box, whatever the tracker is calling its parts this frame,
            # so the claim survives exactly the event that used to silence it.
            claims = [Claim(var="pos[self].r", op="delta", value=int(shift[0]), p=0.9,
                            hypothesis="plan"),
                      Claim(var="pos[self].c", op="delta", value=int(shift[1]), p=0.9,
                            hypothesis="plan")]
            self.queue.append(({"action": name, "x": None, "y": None},
                               Prediction(pid=f"p{self.turn_index}.{i}", step=i, action=name, claims=claims,
                                          summary=f"harness plan step: self moves {tuple(shift)}")))
        self.plan_promise = (plan.status == "found" and len(actions) == len(plan.actions))
        self.plan_batch_shifts = list(shifts)
        # Where the simulation says the body will be standing when this batch is done, so a miss
        # can be blamed on the right thing: if the body ends up there, the dynamics were right and
        # the targets were wrong; if it does not, the dynamics were wrong.
        body = set(self.tracker.body_cells()) if hasattr(self.tracker, "body_cells") else set()
        if body:
            r0, c0 = min(r for r, _c in body), min(c for _r, c in body)
            self.plan_sim_end = (r0 + sum(s[0] for s in shifts), c0 + sum(s[1] for s in shifts))
            # The shape the search planned with, so a miss can say whether the body changed shape
            # between being planned for and arriving.
            self.plan_body_rel = frozenset((r - r0, c - c0) for r, c in body)
        else:
            self.plan_sim_end = None
            self.plan_body_rel = frozenset()
        sig = (goals.describe(self.symbolic_goal) if self.symbolic_goal else "") + "|" + " ".join(actions)
        self.plan_repeat = self.plan_repeat + 1 if sig == self.plan_sig else 0
        self.plan_sig = sig
        if self.plan_repeat + 1 >= PLAN_REPEAT_LIMIT:
            # Independent of how the promise is graded: the same goal solved into the same steps,
            # turn after turn, is a loop whatever the reason. Retiring the goal is the one move
            # that cannot leave it running. The batch just queued still gets played; what changes
            # is that the next turn will not be handed the same answer.
            self._retire_goal(f"the solver answered {' '.join(actions)!r} for this goal "
                              f"{self.plan_repeat + 1} turns running and the goal is no nearer")
        self.batch_sig = " ".join(actions)
        self.recent_batches = (self.recent_batches + [len(actions)])[-4:]
        self.batch_requested = len(actions)
        self.batch_executed = 0
        self.batch_level_before = self.level
        self.halted_reason = ""
        self.batch_misses = 0
        self._log_row({"kind": "plan_committed", "turn": self.turn_index, "steps": len(actions),
                       "total": len(plan.actions), "expanded": plan.expanded})

    def _queue_arrangement(self, plan: Any, cap: int) -> None:
        """Commit a plan that moves pieces rather than the body.

        Each step names the piece the search expects to move and by how much, so the batch is
        checked as strictly as a walking one: a step that only changes which piece is driven claims
        that nothing on the board moves, which is just as falsifiable and is what a selector press
        should look like.
        """
        actions = plan.actions[:cap]
        claims_per_step = list(plan.piece_claims)[:cap]
        self.queue = []
        for i, name in enumerate(actions, start=1):
            spec = claims_per_step[i - 1] if i - 1 < len(claims_per_step) else None
            if spec is None:
                claims = [Claim(var="cells", op="unchanged", value=0, p=0.7, hypothesis="plan")]
                summary = "harness plan step: changes which piece the controls drive"
            else:
                tid, shift = spec
                claims = [Claim(var=f"pos[{tid}].r", op="delta", value=int(shift[0]), p=0.9,
                                hypothesis="plan"),
                          Claim(var=f"pos[{tid}].c", op="delta", value=int(shift[1]), p=0.9,
                                hypothesis="plan")]
                summary = f"harness plan step: {tid} moves {tuple(shift)}"
            self.queue.append(({"action": name, "x": None, "y": None},
                               Prediction(pid=f"a{self.turn_index}.{i}", step=i, action=name,
                                          claims=claims, summary=summary)))
        self.batch_sig = " ".join(actions)
        self.recent_batches = (self.recent_batches + [len(actions)])[-4:]
        self.batch_requested = len(actions)
        self.batch_executed = 0
        self.batch_level_before = self.level
        self.halted_reason = ""
        self.batch_misses = 0
        # A partial arrangement places some of the pieces and says so; it never promised the goal
        # would hold at the end, so grading it against the goal would retire a goal for a promise
        # it did not make.
        self.plan_promise = (len(actions) == len(plan.actions)
                             and getattr(plan, "status", "found") == "found")
        self.plan_sim_end = None
        self.plan_body_rel = frozenset()
        sig = (goals.describe(self.symbolic_goal) if self.symbolic_goal else "") + "|" + " ".join(actions)
        self.plan_repeat = self.plan_repeat + 1 if sig == self.plan_sig else 0
        self.plan_sig = sig
        if self.plan_repeat + 1 >= PLAN_REPEAT_LIMIT:
            self._retire_goal(f"the solver answered {' '.join(actions)!r} for this goal "
                              f"{self.plan_repeat + 1} turns running and the goal is no nearer")
        self._log_row({"kind": "arrangement_committed", "turn": self.turn_index,
                       "steps": len(actions), "total": len(plan.actions),
                       "expanded": plan.expanded})

    def _plan_batch_cap(self) -> int:
        """How many steps of a validated plan may go in one batch.

        Never more than half of what is left of the level's action budget: a plan is trusted, but
        a trusted plan that is wrong about the last thing it does should not be able to spend the
        level on one turn.
        """
        cap = schemas.MAX_PLAN_BATCH
        # A plan is a statement about where a particular body will be. While the body itself is
        # changing, that statement gets less true with every step, so commit few and look again.
        try:
            if not self.tracker.body_is_settled():
                cap = min(cap, UNSETTLED_BODY_BATCH)
        except Exception:  # noqa: BLE001
            pass
        left = self.remaining_actions()
        return cap if left is None else max(1, min(cap, left // 2))

    def remaining_actions(self) -> Optional[int]:
        """Actions left on this level under the official 5x-baseline cutoff, or None when the
        run was started with --no-budget and there is no cutoff to respect."""
        budget = getattr(self, "action_budget", None)
        if not budget:
            return None
        i = max(0, min(len(budget) - 1, self.level - 1))
        return max(0, int(budget[i]) * 5 - self.level_actions)

    def _plan_shift(self, action: str) -> Optional[tuple[int, int]]:
        """The shift the last plan's search assumed for this action, else the control map's."""
        shift = (self.last_plan.shifts or {}).get(action)
        if shift is None:
            shift = self.control.expected_shift(action)
        return tuple(shift) if shift is not None else None

    def harness_goal(self) -> Optional[dict[str, Any]]:
        """A goal the ledger supports on its own, costing no model request.

        Once contact has made members of a class disappear and more of that class are still on
        the board, "reach all of them" is not an interpretation; it is the board's own behaviour
        read back. The model still sets the first goal, because until something has been consumed
        there is nothing here to read.
        """
        cons = self.consumption
        best: Optional[tuple[tuple[int, int], str]] = None
        for key, tids in cons.consumed_tids.items():
            remaining = int(cons.live_counts.get(key, 0))
            if not tids or remaining < 1:
                continue
            if goals.describe({"all_touched": f"class:{key}"}) in self.retired_goals:
                continue   # already solved cleanly on this level and the level did not end
            rank = (len(tids), remaining)
            if best is None or rank > best[0]:
                best = (rank, key)
        if best:
            return {"all_touched": f"class:{best[1]}"}
        return self.prospective_goal()

    # How a collectable looks before anything has been collected: several of them, small, and
    # not the floor. Ranges rather than constants because a board can be 16x16 or 64x64.
    COLLECTABLE_MIN = 2
    COLLECTABLE_MAX = 24
    COLLECTABLE_CELLS = 16

    def prospective_goal(self) -> Optional[dict[str, Any]]:
        """A goal to try before the board has taught anyone anything.

        `harness_goal` reads consumption back off the ledger, which is honest and arrives too
        late: nothing can be consumed until the body has already reached one, so on a fresh level
        there is no goal at all. Measured with `harness_only` across the 24 public games, fifteen
        of them ended with `plan=no_goal` -- no goal, therefore no plan, therefore a turn spent on
        probes. The chicken has to be allowed to come first.

        So this reads the board instead of the ledger: several small things of one kind, none of
        them the body, none of them a colour the passability map calls a wall. That is what a
        collectable looks like from outside before anyone has touched one. It is a hypothesis and
        nothing more -- `check_plan_promise` grades whether reaching them ended the level, and
        `_retire_goal` drops it after two failures -- which is exactly the treatment a guess
        should get, and is cheaper than not guessing.
        """
        from .symbols import shape_name
        tracker = self.tracker
        if not getattr(tracker, "self_tid", None) or not hasattr(tracker, "live"):
            return None
        body = set(tracker.self_group()) | {tracker.self_tid} if hasattr(tracker, "self_group") \
            else {tracker.self_tid}
        walls: set[str] = set()
        try:
            walls = {colour_letter(c) for c in self.passability.colours()
                     if self.passability.verdict(c) == "WALL"}
        except Exception:  # noqa: BLE001
            walls = set()
        groups: dict[str, list[int]] = {}
        for t in tracker.live():
            blob = getattr(t, "blob", None)
            if blob is None or t.tid in body or getattr(t, "klass", "") == "hud":
                continue
            letter = colour_letter(t.colour)
            if letter in walls:
                continue
            groups.setdefault(f"{letter} {shape_name(blob.cells, t.last_bbox)}", []).append(len(blob.cells))
        best: Optional[tuple[tuple[int, int], str]] = None
        for key, sizes in groups.items():
            n = len(sizes)
            if not (self.COLLECTABLE_MIN <= n <= self.COLLECTABLE_MAX):
                continue
            typical = sorted(sizes)[len(sizes) // 2]
            if typical > self.COLLECTABLE_CELLS:
                continue
            if goals.describe({"all_touched": f"class:{key}"}) in self.retired_goals:
                continue
            rank = (n, -typical)
            if best is None or rank > best[0]:
                best = (rank, key)
        if best is None:
            return None
        self._log_row({"kind": "prospective_goal", "turn": self.turn_index, "class": best[1],
                       "n": best[0][0], "cells": -best[0][1]})
        return {"all_touched": f"class:{best[1]}"}

    def level_diff_text(self) -> str:
        """What this board shares with the last one and what it does not, in one line.

        The same half is the half worth saying out loud. A class that looks identical is not known
        to behave identically, and the easiest way to lose a level is to carry a law across a
        boundary without noticing it was a law about a different board.
        """
        d = getattr(self, "level_diff", None)
        if not d:
            return ""
        bits = []
        if d.get("same"):
            bits.append("same as the last level: " + ", ".join(f"{n} x {k}" for k, n in list(d["same"].items())[:4]))
        if d.get("new"):
            bits.append("new here: " + ", ".join(f"{n} x {k}" for k, n in list(d["new"].items())[:4]))
        if d.get("gone"):
            bits.append("gone: " + ", ".join(f"{k}" for k in list(d["gone"])[:4]))
        if d.get("changed"):
            bits.append("different count: " + ", ".join(f"{k} {a}->{b}" for k, (a, b) in list(d["changed"].items())[:3]))
        if not bits:
            return ""
        return (" | ".join(bits) + " -- the things that look the same are the ones you are most "
                "likely to be wrong about; there is an open hypothesis for each")

    def arrangement_facts(self) -> str:
        """Which classes move and which never do, so the model can choose rather than guess.

        The harness's own guess at an arrangement goal is crude: the commonest class that moves,
        onto the tightest-fitting class that does not. On re86 it picked "every w hline onto a
        p hline", solved it, ran it exactly as planned and missed, twice. Choosing which things go
        where is a reading of the board, which is the model's job; the counts are the harness's.
        """
        tr = self.tracker
        live = [t for t in tr.live() if t.blob is not None]
        if not live:
            return ""
        body = set(tr.self_group() or [])
        from .symbols import shape_name
        moved: dict[str, int] = {}
        still: dict[str, int] = {}
        for t in live:
            if t.tid in body:
                continue
            key = f"{colour_letter(t.colour)} {shape_name(t.blob.cells, t.last_bbox)}"
            bucket = moved if t.tid in self.moved_tids else still
            bucket[key] = bucket.get(key, 0) + 1
        if not moved or not still:
            return ""
        def render(d: dict[str, int]) -> str:
            return ", ".join(f"{n} x {k}" for k, n in sorted(d.items(), key=lambda kv: (-kv[1], kv[0]))[:4])
        return ("things that have moved: " + render(moved) + " | things that never move: "
                + render(still) + " | if this level ends when the movers are ARRANGED onto the "
                "still ones rather than when you reach them, set a `covered` goal naming both")

    def arrangement_goal(self) -> Optional[dict[str, Any]]:
        """A goal of the shape this benchmark is actually made of, proposed from the board.

        Reading what guards a level advance in all 24 public games: eight need every piece of a
        kind to end up somewhere particular, and not one ends on "how many of a kind are left",
        which is what `all_touched` says. The model reaches for what it knows, and what it knows
        is walking, so it keeps setting goals about where its body should stand. The evidence for
        the other shape is on the board: more than one thing moves, and there is a class of things
        that never move and are at least as numerous.
        """
        tr = self.tracker
        live = {t.tid: t for t in tr.live() if t.blob is not None}
        body = set(tr.self_group() or [])
        movers = {t for t in self.moved_tids if t in live}
        if len(movers - body) < 2:
            return None
        def klass(tid: str) -> str:
            from .symbols import shape_name
            t = live[tid]
            return f"{colour_letter(t.colour)} {shape_name(t.blob.cells, t.last_bbox)}"
        piece_kinds: dict[str, int] = {}
        for tid in movers - body:
            piece_kinds[klass(tid)] = piece_kinds.get(klass(tid), 0) + 1
        if not piece_kinds:
            return None
        piece_class = max(piece_kinds, key=lambda k: (piece_kinds[k], k))
        need = piece_kinds[piece_class]
        still: dict[str, int] = {}
        for tid in live:
            if tid in movers or tid in body:
                continue
            still[klass(tid)] = still.get(klass(tid), 0) + 1
        options = [k for k, n in still.items() if n >= need and k != piece_class]
        if not options:
            return None
        onto = min(options, key=lambda k: (still[k], k))   # the tightest fit is the likeliest
        return {"covered": [f"class:{piece_class}", f"class:{onto}"]}

    def adopt_harness_goal(self, why: str) -> bool:
        """Install the ledger-backed goal if there is one and it is not already the goal."""
        alt = self.harness_goal()
        if alt is None or goals.describe(alt) in self.retired_goals:
            # Nothing consumed, or that has been tried: the other shape of goal is the one this
            # benchmark is mostly made of, so it is worth proposing on its own evidence.
            arr = self.arrangement_goal()
            if arr is not None and goals.describe(arr) not in self.retired_goals:
                alt = arr
        if not alt or alt == self.symbolic_goal:
            return False
        self.symbolic_goal = alt
        self.goal_fallback = alt
        self.memory.add_goal(goals.describe(alt), 0.6)
        self._log_row({"kind": "harness_goal", "turn": self.turn_index,
                       "goal": goals.describe(alt), "why": why})
        return True

    def check_plan_promise(self) -> None:
        """A plan whose status was `found` promised the goal. Did it deliver?

        This is the harness checking its own claim, the same way it checks the model's. Eight
        EXECUTE turns on ls20 level 2 each committed one action toward "touch t43", the body moved
        exactly as predicted, the goal was not reached, and the solver returned the identical
        one-step plan again -- because nothing ever compared the promise to the outcome.
        """
        if not getattr(self, "plan_promise", False):
            return
        self.plan_promise = False
        if self.batch_executed < self.batch_requested:
            # Steps were dropped, so the plan never finished and never promised anything about
            # where the body would end up. A halt ON THE LAST step is a different thing: every
            # action ran, the plan is over, and the goal is still not met. Skipping those cost
            # fifteen consecutive turns on ls20 level 2, each committing the identical one-step
            # plan, because a one-step plan that mispredicts is halted and finished at once.
            return
        world = planner.goal_world(self)
        if world is None or not self.symbolic_goal:
            # There is nothing to grade the promise against, and "ungradable" is not "broken".
            # The three ways to get here are all plans that did not fail: the last action cleared
            # the level (so `_on_level_change` already nulled the goal), the goal was retired
            # inside `queue_plan` itself, or the body is not identified on this one frame.
            # Counting them as broken retired correct goals and, on a level-clearing plan, told
            # the next `goal` role that the plan which had just won "ran exactly as predicted,
            # yet the goal is still not met".
            self._log_row({"kind": "plan_promise_ungradable", "turn": self.turn_index,
                           "why": "no goal" if not self.symbolic_goal else "no body"})
            return
        met = False
        if world is not None and self.symbolic_goal:
            compiled = goals.compile_goal(self.symbolic_goal, world)
            if not isinstance(compiled, goals.GoalReject):
                # The same origin the planner searched from and `goal_world` wrote its
                # `self_cells` against: the whole body's top-left, not the one fragment that
                # carries the body's name.
                pos = planner.body_origin(self.tracker)
                met = pos is not None and bool(compiled(pos, frozenset(self.reached(world.cells))))
        if met:
            self.plan_broken = 0
            return
        self.plan_broken = getattr(self, "plan_broken", 0) + 1
        # Say which link broke. "The plan ran and the goal is not met" has at least four causes
        # and they need different fixes: the body is not where the simulation said (a dynamics
        # error), it is there and the targets are not (a perception or identity error), the
        # targets were reached and the goal still reads unmet (a bookkeeping error), or the goal
        # was never what ends the level. Only the telemetry can tell them apart, and on a blind
        # game it is the only thing that may be read.
        diag: dict[str, Any] = {}
        try:
            members = world.members_of_goal(self.symbolic_goal) if hasattr(world, "members_of_goal") else []
        except Exception:  # noqa: BLE001
            members = []
        if world is not None:
            cells_of = {tid: world.cells.get(tid, frozenset()) for tid in (members or world.cells)}
            got = self.reached(cells_of)
            body = set(self.tracker.body_cells()) if hasattr(self.tracker, "body_cells") else set()
            real_end = (min(r for r, _c in body), min(c for _r, c in body)) if body else None
            want: set = set()
            for cells in cells_of.values():
                want |= set(cells)
            _ = want
            gap = min((max(abs(r - tr), abs(c - tc)) for r, c in body for tr, tc in want),
                      default=None) if body and want else None
            # Would the shape the search planned with, placed where the search said it would end,
            # be touching the goal? If yes while the real body is not, the body changed shape
            # between planning and arriving, and no amount of correct movement would have helped.
            model_hit = None
            if self.plan_sim_end and self.plan_body_rel:
                placed = {(self.plan_sim_end[0] + r, self.plan_sim_end[1] + c)
                          for r, c in self.plan_body_rel}
                model_hit = bool(placed & want)
            diag = {"members": len(cells_of), "reached": len(got), "model_hit": model_hit,
                    "plan_body": len(self.plan_body_rel),
                    "marks": len(self.touched_marks), "tids": len(self.touched_tids),
                    "halted": bool(self.halted_reason),
                    "sim_end": list(self.plan_sim_end) if self.plan_sim_end else None,
                    "real_end": list(real_end) if real_end else None,
                    "body_cells": len(body), "gap": gap,
                    "last": (self.last_outcome_line or "")[:80]}
        self._log_row({"kind": "plan_broken_promise", "turn": self.turn_index,
                       "sig": getattr(self, "plan_sig", "")[:120], "count": self.plan_broken,
                       **diag})
        self.plan_note = ("the harness solved that goal and the solved plan ran exactly as "
                          "predicted, yet the goal is still not met: the map the solver plans "
                          "over is wrong somewhere, so this goal is being retired")
        if self.plan_broken >= 2:
            # Twice is a loop, not a coincidence.
            self._retire_goal("the harness solved that goal twice, the plans ran as predicted, "
                              "and the goal is still not met")

    def _retire_goal(self, why: str) -> None:
        """Drop the current goal and stop the solver being asked for the same answer again."""
        if not self.symbolic_goal:
            return
        self.retired_goals.add(goals.describe(self.symbolic_goal))
        self._log_row({"kind": "goal_retired", "turn": self.turn_index,
                       "goal": goals.describe(self.symbolic_goal), "why": why[:200]})
        self.plan_note = why + ", so it is being retired: the map the solver plans over is wrong " \
                               "somewhere, or the goal was never what ends this level"
        self.symbolic_goal = None
        self.last_plan = planner.PlanResult(status="no_goal", note=self.plan_note)
        self.confidences.plan = 0.0
        self.plan_broken = 0
        self.plan_repeat = 0
        self.plan_sig = ""
        self.unreachable = 0
        self.unreachable_goal = ""
        self.memory.add_question(
            "the solver reaches its goal on the map but not on the board: which action's "
            "measured effect is wrong?", self.turn_index)
        # If the ledger already supports a goal, take it now rather than spending a request asking
        # for one.
        self.adopt_harness_goal(why)

    def starving(self, *, window: int = 2, floor: int = STARVING_FLOOR) -> bool:
        """Have the last few turns been buying almost nothing *for what they cost*?

        A model turn on the shared GB10 costs 200 to 400 seconds and every second of a turn's wall
        clock is model latency: measured over a live ls20 run, 1525 seconds across five turns and
        1520 of them waiting on the model. A harness turn -- a plan, a probe, a walk over ground
        nobody has stood on -- costs none of that and still plays actions.

        So the bar is not "the model bought nothing", it is "the model bought less than the
        harness could have got for free". Across a whole offline run the harness played 1.1 actions
        per model call, which at five minutes a call is nine hours to spend one level's action
        budget. Four is the floor because the harness's own explore plan routinely commits more
        than that.
        """
        recent = self.recent_batches[-window:]
        return len(recent) >= window and all(n <= floor for n in recent)

    def queue_measurement(self, reason: str) -> bool:
        """Press the buttons nobody has measured, until they can be read. Zero model requests.

        This is the opening probe finished rather than started: the probe presses each action
        twice, but a press the map could not read teaches nothing, so actions can stay unknown for
        a whole run while the model spends its turns on the two that already work. A control the
        harness cannot read is a direction the planner does not have.
        """
        wanted = [a for a in self.control.unmeasured(self.available) if not self.pointless_now(a)]
        if not wanted:
            return False
        batch: list[str] = []
        while len(batch) < min(schemas.MAX_BATCH, 3 * len(wanted)):
            before = len(batch)
            for action in wanted:
                if len(batch) < schemas.MAX_BATCH:
                    batch.append(action)
            if len(batch) == before:
                break
        self.queue = []
        for i, name in enumerate(batch, start=1):
            entry: dict[str, Any] = {"action": name, "x": None, "y": None}
            if name == "ACTION6":
                entry.update({"x": 32, "y": 32})
            # No claim: there is nothing to predict about a button nobody has read, and an empty
            # prediction lets the whole batch run, which is the point of a measurement.
            self.queue.append((entry, None))
        self.batch_sig = " ".join(batch)
        self.recent_batches = (self.recent_batches + [len(batch)])[-4:]
        self.batch_requested = len(batch)
        self.batch_executed = 0
        self.batch_level_before = self.level
        self.halted_reason = ""
        self.batch_misses = 0
        self.plan_promise = False
        self._log_row({"kind": "measure", "turn": self.turn_index, "actions": " ".join(batch),
                       "unmeasured": wanted, "why": reason[:120]})
        return True

    def queue_explore(self, reason: str) -> bool:
        """Spend the turn gathering evidence on ground the body has not stood on. Zero requests.

        Better than a single probe by an order of magnitude: the same turn, a batch instead of one
        action, every step predicted, and the batch still halts itself the moment the world model
        is wrong -- which on unfamiliar ground is the point rather than a risk.
        """
        try:
            result = planner.explore(self, visited=frozenset(self.stood_on),
                                     max_steps=self._plan_batch_cap())
        except Exception as exc:  # noqa: BLE001
            self._log_row({"kind": "explore_failed", "turn": self.turn_index, "error": repr(exc)[:120]})
            return False
        if result.status != "explore" or not result.actions:
            return False
        self.last_plan = result
        keep_sig, keep_repeat = self.plan_sig, self.plan_repeat
        self.queue_plan()
        self.plan_promise = False       # it promised evidence, not a goal
        # And it does not belong in the goal plan's loop-detection channel either. `queue_plan`
        # writes plan_sig/plan_repeat keyed on the CURRENT goal's text, so an explore route
        # repeated three turns running retired a goal the explore turns were not about, and a
        # single explore turn between two identical goal plans reset the counter the guard exists
        # to accumulate.
        self.plan_sig, self.plan_repeat = keep_sig, keep_repeat
        self._log_row({"kind": "explore_plan", "turn": self.turn_index, "steps": len(result.actions),
                       "gain": result.note[:60], "why": reason[:120]})
        return True

    def pointless_now(self, action: str) -> bool:
        """Would this press do nothing, on the map the harness already has?

        The planner refuses to walk into a wall, and probes did not: measured on ls20, ACTION1 was
        pressed into one five times, each producing no frame change at all, while the passability
        map and the grid both knew. Spending a turn's action on a press the harness can predict is
        a no-op is the cheapest waste in the loop and the easiest to stop.
        """
        try:
            shift = self.control.expected_shift(action)
            if shift is None or tuple(shift) == (0, 0):
                return False                      # nothing known: pressing it is how we find out
            body = self.tracker.body_cells()
            if not body:
                return False
            grid = self.percept.grid
            h, w = len(grid), len(grid[0])
            letters = self.rules.wall_colours() if hasattr(self.rules, "wall_colours") else set()
            walls = {i for i in range(16) if colour_letter(i) in letters}
            walls |= {c for c in self.passability.colours() if self.passability.verdict(c) == "WALL"}
            if not walls:
                return False
            for r, c in body:
                nr, nc = r + shift[0], c + shift[1]
                if not (0 <= nr < h and 0 <= nc < w) or grid[nr][nc] in walls:
                    return True
            return False
        except Exception:  # noqa: BLE001
            return False

    def queue_fallback_probe(self, reason: str) -> None:
        """No valid decision: probe with the least-observed actions that can do something.

        A BATCH of them, not one. This is the last resort, and it fires on exactly the games where
        nothing else can: measured with no model at all across ten dev games, four of them
        (sc25, sb26, tn36, bp35) ran 150 turns for 180 actions -- 1.2 actions a turn -- because
        the planner needs two known directional shifts to build a model and a click-driven game
        never gives it one, so `queue_explore` has nothing to offer and every turn fell to a
        single press. A turn on the GB10 costs six minutes and an action costs nothing; spending
        a whole turn on one press is the most expensive thing the harness can do.

        The order is still deterministic -- least-observed first, skipping presses the map says
        are pointless from where the body stands -- so this is the same probe, repeated, and each
        press is evidence the control map can read.
        """
        options = [a for a in self.available if a not in ("RESET", "ACTION6")] or [a for a in self.available if a != "RESET"] or ["RESET"]
        useful = [a for a in options if not self.pointless_now(a)]
        options = useful or options               # all blocked: press anyway, and learn that
        counts = {a: self.control.signature(a).get("total", 0) if hasattr(self.control, "signature") else 0 for a in options}
        order = sorted(options, key=lambda a: (counts[a], a))
        rounds = max(1, min(3, schemas.MAX_BATCH // max(1, len(order))))
        batch = (order * rounds)[: schemas.MAX_BATCH]
        self.queue = []
        # One click target per ACTION6 in the batch, each a different thing. Clicking the same
        # pixel repeatedly is the one press guaranteed to teach nothing.
        spots = self.click_targets(sum(1 for n in batch if n == "ACTION6")) if "ACTION6" in batch else []
        for name in batch:
            if name == "ACTION6":
                entry: dict[str, Any] = self._click_entry(spots.pop(0) if spots else (32, 32))
            else:
                entry = {"action": name, "x": None, "y": None}
            # No claim: the point is to find out, and an empty prediction lets the whole batch run.
            self.queue.append((entry, None))
        action = batch[0]
        self.batch_sig = " ".join(
            e["action"] + (f"({e['x']},{e['y']})" if e.get("x") is not None else "") for e, _p in self.queue)
        self.batch_requested = len(self.queue)
        self.batch_executed = 0
        self.batch_misses = 0
        self.batch_level_before = self.level
        # Every other queue path clears this; this one did not, so check_plan_promise's telemetry
        # reported a halt from a batch two batches ago.
        self.halted_reason = ""
        self.plan_promise = False
        self.recent_batches = (self.recent_batches + [len(self.queue)])[-4:]
        self._log_row({"kind": "fallback_probe", "turn": self.turn_index, "action": action,
                       "actions": self.batch_sig, "reason": reason[:300]})

    # -- harness-side theory upkeep ------------------------------------------------------------------

    def refresh_rules(self) -> None:
        """Induce every harness rule family from the ledger, then rescore the whole store.

        `sync` keys a rule on its guard and effect, so a law keeps its number across turns
        instead of the store minting a fresh one every time induction runs.
        """
        try:
            induced = rules.induce_harness_rules(
                self.ledger, control_map=self.control, passability=self.passability,
                consumption=self.consumption, miner=self.miner, vocab=self._rule_vocab(),
                level=self.level)
            self.rules.sync(induced)
            self.rules.rescore_all(self.ledger)
        except Exception as exc:  # noqa: BLE001
            self._log_row({"kind": "rules_error", "turn": self.turn_index, "error": repr(exc)[:300]})
        self._recompute_confidences()

    def _recompute_confidences(self) -> None:
        live = self.tracker.live()
        amb = sum(1 for t in live if t.ambiguity_group is not None)
        veil = (self.percept.scalars.get("veil_frac", 0) / 1000.0) if self.percept else 0.0
        perception_c = max(0.0, 1.0 - (amb / max(1, len(live))) - veil)
        control_c = self.control.known_fraction(self.available)
        # A rule count cannot buy confidence on its own: this weighs how often the last few
        # predictions survived, how much of each frame they actually claimed, and how many of the
        # available actions carry a usable law.
        wm_c = rules.world_model_confidence(self.ledger, self.rules, self.available,
                                            control=self.control)
        self.wm_parts = dict(getattr(rules.world_model_confidence, "last_parts", {}) or {})
        # The channel has to be about the goal the SOLVER has, not a sentence in memory. A goal
        # hypothesis is free text the model wrote; `symbolic_goal` is a term the search can be
        # given. Measured live: the gate reported goal 0.9 and "plan is the blocking channel" for
        # turn after turn while `last_plan.status` was `no_goal` -- every channel passing, and
        # nothing for the solver to solve. A written goal with no symbolic form is worth
        # something, because the model is thinking about the right thing, but it is not worth the
        # gate.
        written = self.memory.top_goals(1)
        written_p = written[0].p if written else 0.0
        goal_c = round(written_p, 2) if self.symbolic_goal else round(0.5 * written_p, 2)
        self.confidences = Confidences(perception=round(perception_c, 2), control=round(control_c, 2),
                                       world_model=round(wm_c, 2), goal=round(goal_c, 2), plan=0.0)

    def plan_ready(self) -> bool:
        """A validated harness plan exists for a deterministic goal; also stored for the prompt."""
        try:
            self.last_plan = planner.plan(self)
        except Exception as exc:  # noqa: BLE001
            self.last_plan = planner.PlanResult(status="error", note=repr(exc)[:120])
        # A goal the solver cannot reach is not self-correcting. The repeat guard keys on the
        # signature of a COMMITTED plan, and a search that exhausts never commits one, so an
        # unreachable goal sits there being re-solved for the rest of the level: measured on ls20,
        # "put every class:b rect on a class:B rect" came back `no_plan_exhausted` with one piece
        # on the board. Exhaustion is deterministic given the same facts, so repeating it is
        # guaranteed waste; two turns of it is enough to say so.
        dead = self.last_plan.status in ("no_plan_exhausted", "no_plan_within_budget",
                                         "no_plan_incremental", "unsolvable_here", "bad_goal")
        # At most once a turn. `plan_ready` is a predicate by name but runs the search and
        # mutates state, and nodes.py calls it up to three times in one turn (world, after
        # adopting a harness goal, after the model's goal role). Counting each call let "the
        # solver could not reach it twice" fire inside a single turn, on a goal that had just
        # been set -- two calls of one turn are one piece of evidence, not two.
        if dead and self.symbolic_goal and self._unreachable_turn != self.turn_index:
            self._unreachable_turn = self.turn_index
            sig = goals.describe(self.symbolic_goal)
            self.unreachable = self.unreachable + 1 if sig == self.unreachable_goal else 1
            self.unreachable_goal = sig
            if self.unreachable >= 2:
                self._retire_goal(f"the solver could not reach it twice ({self.last_plan.status})")
                self.unreachable = 0
        elif self.last_plan.status == "found":
            self.unreachable = 0
        ok = self.last_plan.status == "found"
        # A partial plan is worth committing but is not proof the world model is good enough to
        # stop exploring, so it raises the plan channel without opening the gate.
        self.confidences.plan = 0.9 if ok else (0.4 if self.last_plan.status == "partial" else 0.0)
        return ok

    def refresh_goal_facts(self) -> None:
        return None

    def hypotheses_disagree(self) -> bool:
        """Only open, still-testable pairs count: a test whose action is unavailable, or whose
        hypothesis has been settled, is not a reason to spend a VERIFY turn."""
        self.hyp_tests = {h: t for h, t in self.hyp_tests.items()
                          if self.memory.hypotheses.get(h) is None or self.memory.hypotheses[h].status == "open"}
        tests = list(self.hyp_tests.values())
        for i in range(len(tests)):
            for j in range(i + 1, len(tests)):
                a, b = tests[i], tests[j]
                if a["test_action"] == b["test_action"] and a["test_action"] in self.available and (
                        a["predicted_op"], a["predicted_value"]) != (b["predicted_op"], b["predicted_value"]):
                    return True
        return False

    def doom_detected(self) -> bool:
        if len(self.doom_ring) < DOOM_THRESHOLD:
            return False
        tail = self.doom_ring[-DOOM_THRESHOLD:]
        return len(set(tail)) == 1

    def novelty_score(self) -> float:
        if self.new_level_pending and self.oriented_level != self.level:
            return 1.0
        live = self.tracker.live()
        if not live or not hasattr(self.tracker, "archived"):
            return 0.0
        # `archived` maps level -> {tid: Track}, so iterate the values; iterating the mapping
        # itself yields track ids, and asking a string for its form_hash ends the game.
        seen = {t.form_hash for level_tracks in self.tracker.archived.values()
                for t in level_tracks.values()}
        new = sum(1 for t in live if t.form_hash not in seen)
        return new / len(live) if self.level > 1 else 0.0

    def load_priors(self) -> None:
        self.family = self._family_key()
        self.memory.priors = self.store.priors_for(self.family)
        self.priors_loaded = True

    def _family_key(self) -> str:
        return "actions:" + ",".join(sorted(a for a in self.available if a != "RESET"))

    # -- logging -------------------------------------------------------------------------------------

    def _log_row(self, row: dict[str, Any]) -> None:
        path = self.out_dir / f"{self.tag}.turns.jsonl"
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"t": round(time.time(), 1), **row}, default=str) + "\n")

    def _log_call(self, role: str, mode: Mode, attempt: dict[str, Any], user: str) -> None:
        path = self.out_dir / f"{self.tag}.calls.jsonl"
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"turn": self.turn_index, "step": self.step, "role": role, "mode": mode.value,
                                 "prompt_chars": len(user), **attempt}, default=str) + "\n")
        with open(self.out_dir / f"{self.tag}.prompts.txt", "a", encoding="utf-8") as fh:
            fh.write(f"\n=== turn {self.turn_index} step {self.step} {mode.value} {role} attempt {attempt.get('attempt')} "
                     f"({attempt.get('latency_s', 0):.0f}s, out {attempt.get('usage', {}).get('out')}) ===\n"
                     f"{user}\n--- reply ---\n{attempt.get('text', '')}\n--- error: {attempt.get('error')}\n")

    def log_turn(self, st: TurnState) -> None:
        self._mode_reason = st.mode_reason
        # Why the solver did or did not answer. "plan is the blocking channel" means every
        # confidence passed and the search still produced nothing, and there are half a dozen very
        # different reasons for that; without the status they are indistinguishable from outside,
        # which on a blind game means indistinguishable full stop.
        self._log_row({"kind": "turn", "wm_parts": dict(getattr(self, "wm_parts", {})),
                       "plan_status": self.last_plan.status,
                       "plan_note": (self.last_plan.note or "")[:90],
                       "plan_len": len(self.last_plan.actions),
                       "turn": st.turn, "step": self.step, "level": self.level, "mode": st.mode.value,
                       "reason": st.mode_reason, "roles": [r for r, _ in st.roles], "errors": st.errors,
                       "batch": self.batch_sig, "queued": len(self.queue), "graph": st.trace,
                       "confidences": self.confidences.as_dict(), "model_confidence": self.model_confidence,
                       "ledger": len(self.ledger), "rules": len(self.rules.top(50)), "self": self.tracker.self_tid})

    def _write_memory_dump(self) -> None:
        try:
            (self.out_dir / f"{self.tag}.memory.json").write_text(json.dumps({
                "game_id": self.game_id, "level": self.level, "turns": self.turn_index,
                "memory": self.memory.to_json(), "rules": self.rules.to_json() if hasattr(self.rules, "to_json") else None,
                "control": self.control.to_json(), "control_line": self.control.render(),
                "passability": self.passability.render(),
                "tracks": [self._track_row(t) for t in self.tracker.tracks.values()],
            }, indent=1, default=str))
            self.ledger.to_jsonl(self.out_dir / f"{self.tag}.ledger.jsonl")
        except Exception:  # noqa: BLE001
            pass
