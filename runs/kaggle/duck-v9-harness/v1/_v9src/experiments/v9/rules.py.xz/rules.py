"""The closed rule DSL: model-proposed statements compiled by the harness and scored only
against the ledger. No model-written code ever runs; a rule is JSON over a fixed vocabulary
of terms, predicates, effects and combinators, and its confidence is a Laplace count the
harness computes from replaying every applicable record.

Terms      $self | obj:<tid> | class:<letter> | class:<form_hash> | cell:(r,c) | var:<name> | literal
Predicates (evaluated on the BEFORE snapshot + the record's action):
  action_is(a)  colour_is(term, colour)  shape_is(term, form_hash)  at(term, cell)
  adjacent(a, b, dir)  overlaps(a, b)  inside(a, b)  distance(a, b, op, k)
  count_of(term, op, k)  exists(term)  gone(term)  changed(var)  delta(var, op, k)
  flag(obj, name)  since_last(event, op, k)  blocked(action)  always
Effects (checked on the AFTER snapshot against the BEFORE one):
  move(term, (dr,dc))  recolour(term, colour)  vanish(term)  set(var, value)
  delta(var, k)  nochange  level_complete
Combinators and/or/not, nesting depth <= 2.

Rule JSON: {"type": <RULE_TYPES>, "when": <guard>, "then": [<effect>...], "scope": "level"|"game",
            "because": [ledger idx...], "confidence": 0..1 (optional), "text": str (optional)}
A guard is one predicate dict {"name": args} or a combinator dict; args are a list, or a bare
value for unary predicates. `{"always": true}` / `{}` is the always-true guard.

Stdlib only.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Optional

from v9.types import COLOUR_CHARS, Record, Rule, RuleScore, RULE_TYPES, TrackState, colour_letter

__all__ = [
    "Snapshot", "SnapTrack", "Vocabulary", "RejectReason", "CompiledRule", "EvalContext",
    "compile_rule", "score_rule", "rule_usable", "promote_if_intervened", "RuleStore",
    "induce_control_rules", "induce_passability_rules", "induce_contact_rules", "induce_harness_rules",
    "ledger_action_shifts", "letters_in",
    "describe_rule", "contexts_for", "status_for", "guard_from_feature", "world_model_confidence",
    "REFUTE_MIN_GRADED",
]

SUPPORT, CONTRADICT, ABSTAIN = "SUPPORT", "CONTRADICT", "ABSTAIN"
MAX_DEPTH = 2
# A rule whose contradictions outnumber its supports has a Laplace confidence below 0.5 --
# (s+1)/(s+c+2) < 0.5 is exactly s < c -- so "worse than a coin flip" needs no extra constant.
# It needs a sample size, though: 0/1 is not a refutation. Six graded records is the point at
# which a real majority of contradictions cannot be a run of bad luck on a deterministic game.
REFUTE_MIN_GRADED = 6
COMBINATORS = ("and", "or", "not")
PREDICATES = {
    # name: arity (tuple of accepted arities)
    "always": (0, 1), "action_is": (1,), "colour_is": (2,), "shape_is": (2,), "at": (2,),
    "adjacent": (2, 3), "overlaps": (2,), "inside": (2,), "distance": (4,), "count_of": (3,),
    "exists": (1,), "gone": (1,), "changed": (1,), "delta": (3,), "flag": (2,),
    "since_last": (3,), "blocked": (1,),
    # `value` is the one predicate not in the plan's list. Without it a scalar threshold cannot
    # be a guard, so the precondition miner's separators ("succeeds iff consumed[Y]>0") can be
    # printed but never become a scored rule -- the harness would keep a mechanic it has already
    # measured out of the store. delta() reads the change, count_of() the live members; neither
    # can say "the counter stands at k".
    "value": (3,),
}
EFFECTS = {
    "move": (2,), "recolour": (2,), "vanish": (1,), "set": (2,), "delta": (2,),
    "nochange": (0, 1), "level_complete": (0, 1),
}
OPS: dict[str, Callable[[Any, Any], bool]] = {
    "<": lambda a, b: a < b, "<=": lambda a, b: a <= b, "==": lambda a, b: a == b,
    "!=": lambda a, b: a != b, ">=": lambda a, b: a >= b, ">": lambda a, b: a > b,
    "lt": lambda a, b: a < b, "le": lambda a, b: a <= b, "eq": lambda a, b: a == b,
    "ne": lambda a, b: a != b, "ge": lambda a, b: a >= b, "gt": lambda a, b: a > b,
}
DIRS = {"up": (-1, 0), "down": (1, 0), "left": (0, -1), "right": (0, 1)}
_ACTION_ALIAS = re.compile(r"^A(\d)$")
_CELL_RE = re.compile(r"^cell:\(?\s*(-?\d+)\s*,\s*(-?\d+)\s*\)?$")


# --- snapshots ------------------------------------------------------------------------------


@dataclass
class SnapTrack:
    """The part of a Track a rule can see: identity, box, colour, form, state, flags."""
    tid: str
    bbox: tuple[int, int, int, int]
    colour: int
    form_hash: str = ""
    state: str = "LIVE"
    flags: dict[str, Any] = field(default_factory=dict)
    cells: Optional[frozenset[tuple[int, int]]] = None

    @property
    def letter(self) -> str:
        return colour_letter(self.colour)

    @property
    def live(self) -> bool:
        return self.state == "LIVE"


@dataclass
class Snapshot:
    """Object and scalar state at one instant, as a rule sees it. Built by the session from
    the tracker (`Snapshot.from_tracker`) or by hand in tests."""
    tracks: dict[str, SnapTrack] = field(default_factory=dict)
    scalars: dict[str, int] = field(default_factory=dict)
    self_tid: Optional[str] = None
    step: int = 0
    level: int = 0

    @classmethod
    def from_tracker(cls, tracker: Any, scalars: Optional[dict[str, int]] = None, *,
                     step: int = 0, level: int = 0) -> "Snapshot":
        """Snapshot a tracker exposing `tracks: dict[str, Track]` and `self_tid`."""
        tracks: dict[str, SnapTrack] = {}
        for tid, t in getattr(tracker, "tracks", {}).items():
            st = t.state.value if isinstance(t.state, TrackState) else str(t.state)
            cells = t.blob.cells if getattr(t, "blob", None) is not None else None
            tracks[tid] = SnapTrack(tid=tid, bbox=tuple(t.last_bbox), colour=int(t.colour),
                                    form_hash=str(t.form_hash), state=st, flags=dict(t.flags), cells=cells)
        return cls(tracks=tracks, scalars=dict(scalars or {}), self_tid=getattr(tracker, "self_tid", None),
                   step=step, level=level)

    def to_json(self) -> dict[str, Any]:
        """JSON-ready dict (cells dropped: bbox/colour/form are what rules evaluate)."""
        return {
            "tracks": {tid: {"tid": t.tid, "bbox": list(t.bbox), "colour": t.colour, "form_hash": t.form_hash,
                             "state": t.state, "flags": dict(t.flags)} for tid, t in self.tracks.items()},
            "scalars": dict(self.scalars), "self_tid": self.self_tid, "step": self.step, "level": self.level,
        }

    @classmethod
    def from_json(cls, d: dict[str, Any]) -> "Snapshot":
        """Inverse of to_json."""
        # `cells` is read back when the row carries it. `to_json` drops it deliberately -- bbox,
        # colour and form are what a rule evaluates -- but `ledger.record_to_json` serialises
        # snapshots with the generic dataclass walker, which writes cells and then had no way to
        # get them back. A reloaded ledger therefore had cells=None on every track, and
        # `_mine_contacts` and `_note_touched` both return early without them: an offline replay
        # over a saved ledger reported zero contacts and disagreed with the live run silently.
        tracks = {}
        for tid, t in d.get("tracks", {}).items():
            raw = t.get("cells")
            cells = frozenset((int(r), int(c)) for r, c in raw) if raw else None
            tracks[tid] = SnapTrack(tid=t["tid"], bbox=tuple(t["bbox"]), colour=int(t["colour"]),
                                    form_hash=t.get("form_hash", ""), state=t.get("state", "LIVE"),
                                    flags=dict(t.get("flags", {})), cells=cells)
        return cls(tracks=tracks, scalars=dict(d.get("scalars", {})), self_tid=d.get("self_tid"),
                   step=int(d.get("step", 0)), level=int(d.get("level", 0)))


@dataclass
class EvalContext:
    """What a rule needs beyond the record itself: the before/after snapshots (default to the
    record's own), steps since the last event of each kind, and which actions were blocked
    on their most recent attempt."""
    before: Optional[Snapshot] = None
    after: Optional[Snapshot] = None
    since_last: dict[str, int] = field(default_factory=dict)
    last_blocked: set[str] = field(default_factory=set)


def contexts_for(records: Iterable[Record]) -> list[EvalContext]:
    """Build one EvalContext per record from the ledger history (event recency, blocked
    actions), in order. Snapshots come from the records."""
    out: list[EvalContext] = []
    last_event_step: dict[str, int] = {}
    blocked: set[str] = set()
    for rec in records:
        since = {k: rec.step - s for k, s in last_event_step.items()}
        out.append(EvalContext(before=rec.before_snap, after=rec.after_snap, since_last=since,
                               last_blocked=set(blocked)))
        for ev in rec.delta.events:
            last_event_step[ev.kind] = rec.step
        if "blocked" in rec.delta.tags:
            blocked.add(rec.action)
        else:
            blocked.discard(rec.action)
    return out


# --- vocabulary and rejection -----------------------------------------------------------------


@dataclass
class Vocabulary:
    """Everything a rule may name. Empty sets mean 'no check' for that kind."""
    tids: set[str] = field(default_factory=set)
    letters: set[str] = field(default_factory=set)
    form_hashes: set[str] = field(default_factory=set)
    scalars: set[str] = field(default_factory=set)
    actions: set[str] = field(default_factory=set)
    check: bool = True

    @classmethod
    def permissive(cls) -> "Vocabulary":
        """A vocabulary that accepts every entity (used when re-scoring stored rules)."""
        return cls(check=False)

    @classmethod
    def from_snapshot(cls, snap: Snapshot, actions: Iterable[str] = ()) -> "Vocabulary":
        """Vocabulary listing the snapshot's tracks, colours, forms and scalar names."""
        return cls(tids=set(snap.tracks), letters={t.letter for t in snap.tracks.values()},
                   form_hashes={t.form_hash for t in snap.tracks.values() if t.form_hash},
                   scalars=set(snap.scalars), actions=set(actions))

    def knows_tid(self, tid: str) -> bool:
        return not self.check or not self.tids or tid in self.tids

    def knows_class(self, key: str) -> bool:
        if not self.check:
            return True
        if len(key) == 1 and key in COLOUR_CHARS:
            return not self.letters or key in self.letters
        return not self.form_hashes or key in self.form_hashes

    def knows_scalar(self, name: str) -> bool:
        if not self.check or not self.scalars or name in self.scalars:
            return True
        m = re.match(r"^pos\[([^\]]+)\]\.(r|c)$", name)
        if m:
            return self.knows_tid(m.group(1))
        return False

    def knows_action(self, a: str) -> bool:
        return not self.check or not self.actions or a in self.actions


class RejectReason(str):
    """A named rejection: compares equal to its reason string; `.detail` says which part."""
    detail: str = ""

    def __new__(cls, reason: str, detail: str = "") -> "RejectReason":
        obj = str.__new__(cls, reason)
        obj.detail = detail
        return obj

    def __repr__(self) -> str:
        return f"RejectReason({str(self)!r}, {self.detail!r})"


class _Reject(Exception):
    def __init__(self, reason: str, detail: str = "") -> None:
        super().__init__(reason)
        self.reason = RejectReason(reason, detail)


# --- term resolution ------------------------------------------------------------------------


def _norm_action(a: Any) -> str:
    s = str(a).strip().upper()
    m = _ACTION_ALIAS.match(s)
    return f"ACTION{m.group(1)}" if m else s


def _colour_value(c: Any) -> Optional[int]:
    if isinstance(c, bool):
        return None
    if isinstance(c, int):
        return c
    s = str(c)
    if len(s) == 1 and s in COLOUR_CHARS:
        return COLOUR_CHARS.index(s)
    if s.isdigit():
        return int(s)
    return None


class _Term:
    """A parsed term. kind in {self, obj, class, cell, var, lit}."""
    __slots__ = ("kind", "key")

    def __init__(self, kind: str, key: Any) -> None:
        self.kind, self.key = kind, key

    def __repr__(self) -> str:
        return {"self": "$self", "obj": f"obj:{self.key}", "class": f"class:{self.key}",
                "cell": f"cell:{self.key}", "var": f"var:{self.key}"}.get(self.kind, repr(self.key))

    def tracks(self, snap: Optional[Snapshot]) -> Optional[list[SnapTrack]]:
        """Resolve to tracks in a snapshot. None = unresolvable (abstain); [] = class empty."""
        if snap is None:
            return None
        if self.kind == "self":
            if not snap.self_tid:
                return None
            t = snap.tracks.get(snap.self_tid)
            return [t] if t else []
        if self.kind == "obj":
            t = snap.tracks.get(self.key)
            return [t] if t else []
        if self.kind == "class":
            # OCCLUDED and AMBIGUOUS members are included, and the predicates decide what to do
            # with them. Filtering on `live` alone here made `_exists`'s occlusion disjunct and
            # its whole AMBIGUOUS abstain branch unreachable for class terms, so `gone(class:Y)`
            # returned True while a Y was merely behind an animation -- and that is exactly the
            # guard `guard_from_feature("gone[Y]")` builds, scored on frames where the class is
            # still on the board.
            k = self.key
            usable = ("LIVE", "OCCLUDED", "AMBIGUOUS")
            if len(k) == 1 and k in COLOUR_CHARS:
                return [t for t in snap.tracks.values() if t.state in usable and t.letter == k]
            return [t for t in snap.tracks.values() if t.state in usable and t.form_hash == k]
        if self.kind == "cell":
            r, c = self.key
            return [SnapTrack(tid=f"cell:{r},{c}", bbox=(r, c, r, c), colour=-1)]
        return None

    def value(self, snap: Optional[Snapshot], rec: Record) -> Any:
        if self.kind == "var":
            if self.key == "step":
                return rec.step
            if self.key == "level":
                return rec.level
            if snap is None or self.key not in snap.scalars:
                return None
            return snap.scalars[self.key]
        return self.key


def _parse_term(x: Any, vocab: Vocabulary) -> _Term:
    if isinstance(x, str):
        if x == "$self":
            return _Term("self", None)
        if x.startswith("obj:"):
            tid = x[4:]
            if not vocab.knows_tid(tid):
                raise _Reject("unknown_entity", x)
            return _Term("obj", tid)
        if x.startswith("class:"):
            key = x[6:]
            if not vocab.knows_class(key):
                raise _Reject("unknown_entity", x)
            return _Term("class", key)
        if x.startswith("cell:"):
            m = _CELL_RE.match(x)
            if not m:
                raise _Reject("arity", f"bad cell term {x}")
            return _Term("cell", (int(m.group(1)), int(m.group(2))))
        if x.startswith("var:"):
            name = x[4:]
            if not vocab.knows_scalar(name) and name not in ("step", "level"):
                raise _Reject("unknown_entity", x)
            return _Term("var", name)
        return _Term("lit", x)
    if isinstance(x, (list, tuple)) and len(x) == 2 and all(isinstance(v, int) for v in x):
        return _Term("cell", (int(x[0]), int(x[1])))
    return _Term("lit", x)


def _parse_var(x: Any, vocab: Vocabulary) -> str:
    name = x[4:] if isinstance(x, str) and x.startswith("var:") else str(x)
    if not vocab.knows_scalar(name) and name not in ("step", "level"):
        raise _Reject("unknown_entity", name)
    return name


def _op(x: Any) -> Callable[[Any, Any], bool]:
    if x not in OPS:
        raise _Reject("arity", f"unknown comparison {x!r}")
    return OPS[x]


# --- geometry -----------------------------------------------------------------------------


def _gap(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> int:
    """Chebyshev gap between two boxes: 0 when they touch or overlap."""
    rg = max(0, b[0] - a[2] - 1, a[0] - b[2] - 1)
    cg = max(0, b[1] - a[3] - 1, a[1] - b[3] - 1)
    return max(rg, cg)


def _overlaps(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> bool:
    return not (a[2] < b[0] or b[2] < a[0] or a[3] < b[1] or b[3] < a[1])


def _adjacent(a: tuple[int, int, int, int], b: tuple[int, int, int, int], d: Optional[str]) -> bool:
    """b touches a on side d (b is `up` of a when b's bottom row is a's top row - 1 and the
    columns overlap). d None/any = any side, edge-sharing only (no diagonal)."""
    rows = not (a[2] < b[0] or b[2] < a[0])
    cols = not (a[3] < b[1] or b[3] < a[1])
    sides = {
        "up": cols and b[2] == a[0] - 1, "down": cols and b[0] == a[2] + 1,
        "left": rows and b[3] == a[1] - 1, "right": rows and b[1] == a[3] + 1,
    }
    if d in sides:
        return sides[d]
    return any(sides.values())


def _inside(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> bool:
    return b[0] <= a[0] and b[1] <= a[1] and a[2] <= b[2] and a[3] <= b[3]


# --- compiled nodes -------------------------------------------------------------------------

Tri = Optional[bool]     # True | False | None (abstain)


def _tri_and(vals: list[Tri]) -> Tri:
    if any(v is False for v in vals):
        return False
    if any(v is None for v in vals):
        return None
    return True


def _tri_or(vals: list[Tri]) -> Tri:
    if any(v is True for v in vals):
        return True
    if any(v is None for v in vals):
        return None
    return False


def _pair_any(ta: Optional[list[SnapTrack]], tb: Optional[list[SnapTrack]],
              f: Callable[[SnapTrack, SnapTrack], bool]) -> Tri:
    if ta is None or tb is None:
        return None
    return any(f(x, y) for x in ta for y in tb if x.tid != y.tid)


def _compile_pred(name: str, args: list[Any], vocab: Vocabulary) -> Callable[[Record, EvalContext], Tri]:
    """Compile one predicate into a function of (record, ctx) returning True/False/None."""
    if name not in PREDICATES:
        raise _Reject("unknown_predicate", name)
    if len(args) not in PREDICATES[name]:
        raise _Reject("arity", f"{name} takes {PREDICATES[name]} args, got {len(args)}")

    if name == "always":
        return lambda rec, ctx: True
    if name == "action_is":
        a = _norm_action(args[0])
        if not vocab.knows_action(a):
            raise _Reject("unknown_entity", f"action {args[0]}")
        return lambda rec, ctx: _norm_action(rec.action) == a
    if name == "blocked":
        a = _norm_action(args[0])
        if not vocab.knows_action(a):
            raise _Reject("unknown_entity", f"action {args[0]}")
        return lambda rec, ctx: a in ctx.last_blocked
    if name == "changed":
        v = _parse_var(args[0], vocab)
        return lambda rec, ctx: v in rec.delta.scalars
    if name == "delta":
        v = _parse_var(args[0], vocab)
        op, k = _op(args[1]), args[2]

        def _delta(rec: Record, ctx: EvalContext, v=v, op=op, k=k) -> Tri:
            pair = rec.delta.scalars.get(v)
            if pair is None:
                if ctx.before is not None and v not in ctx.before.scalars and v not in ("step", "level"):
                    return None
                return op(0, k)
            return op(pair[1] - pair[0], k)
        return _delta
    if name == "value":
        v, op, k = _parse_var(args[0], vocab), _op(args[1]), args[2]

        def _value(rec: Record, ctx: EvalContext, v=v, op=op, k=k) -> Tri:
            snap = ctx.before if ctx.before is not None else rec.before_snap
            if v == "step":
                return op(rec.step, k)
            if v == "level":
                return op(rec.level, k)
            if snap is None or v not in snap.scalars:
                pair = rec.delta.scalars.get(v)
                return None if pair is None else op(pair[0], k)
            return op(snap.scalars[v], k)
        return _value
    if name == "since_last":
        ev, op, k = str(args[0]).upper(), _op(args[1]), args[2]

        def _since(rec: Record, ctx: EvalContext, ev=ev, op=op, k=k) -> Tri:
            if ev not in ctx.since_last:
                return None
            return op(ctx.since_last[ev], k)
        return _since

    # entity predicates
    t0 = _parse_term(args[0], vocab)
    if name in ("exists", "gone"):
        want = name == "exists"

        def _exists(rec: Record, ctx: EvalContext, t=t0, want=want) -> Tri:
            snap = ctx.before if ctx.before is not None else rec.before_snap
            if snap is None:
                return None
            if t.kind == "self" and not snap.self_tid:
                return None
            ts = t.tracks(snap)
            if ts is None:
                return None
            present = any(x.live or x.state == "OCCLUDED" for x in ts)
            if any(x.state == "AMBIGUOUS" for x in ts) and not present:
                return None
            return present if want else not present
        return _exists
    if name == "colour_is":
        col = _colour_value(args[1])
        if col is None:
            raise _Reject("unknown_entity", f"colour {args[1]!r}")
        if not vocab.knows_class(colour_letter(col)) and vocab.check and vocab.letters:
            raise _Reject("unknown_entity", f"colour {args[1]!r}")

        def _colour(rec: Record, ctx: EvalContext, t=t0, col=col) -> Tri:
            ts = t.tracks(ctx.before if ctx.before is not None else rec.before_snap)
            if not ts:
                return None
            return all(x.colour == col for x in ts)
        return _colour
    if name == "shape_is":
        fh = str(args[1])
        if not vocab.knows_class(fh):
            raise _Reject("unknown_entity", f"form {fh}")

        def _shape(rec: Record, ctx: EvalContext, t=t0, fh=fh) -> Tri:
            ts = t.tracks(ctx.before if ctx.before is not None else rec.before_snap)
            if not ts:
                return None
            return all(x.form_hash == fh for x in ts)
        return _shape
    if name == "flag":
        fname = str(args[1])

        def _flag(rec: Record, ctx: EvalContext, t=t0, fname=fname) -> Tri:
            ts = t.tracks(ctx.before if ctx.before is not None else rec.before_snap)
            if not ts:
                return None
            return any(bool(x.flags.get(fname)) for x in ts)
        return _flag
    if name == "count_of":
        op, k = _op(args[1]), args[2]

        def _count(rec: Record, ctx: EvalContext, t=t0, op=op, k=k) -> Tri:
            ts = t.tracks(ctx.before if ctx.before is not None else rec.before_snap)
            if ts is None:
                return None
            return op(len([x for x in ts if x.live]), k)
        return _count

    t1 = _parse_term(args[1], vocab)
    if name == "at":
        def _at(rec: Record, ctx: EvalContext, a=t0, b=t1) -> Tri:
            snap = ctx.before if ctx.before is not None else rec.before_snap
            return _pair_any(a.tracks(snap), b.tracks(snap), lambda x, y: _overlaps(x.bbox, y.bbox))
        return _at
    if name == "overlaps":
        def _ov(rec: Record, ctx: EvalContext, a=t0, b=t1) -> Tri:
            snap = ctx.before if ctx.before is not None else rec.before_snap
            return _pair_any(a.tracks(snap), b.tracks(snap), lambda x, y: _overlaps(x.bbox, y.bbox))
        return _ov
    if name == "inside":
        def _in(rec: Record, ctx: EvalContext, a=t0, b=t1) -> Tri:
            snap = ctx.before if ctx.before is not None else rec.before_snap
            return _pair_any(a.tracks(snap), b.tracks(snap), lambda x, y: _inside(x.bbox, y.bbox))
        return _in
    if name == "adjacent":
        d = str(args[2]).lower() if len(args) == 3 else None
        if d is not None and d not in DIRS and d != "any":
            raise _Reject("arity", f"adjacent direction {d!r}")

        def _adj(rec: Record, ctx: EvalContext, a=t0, b=t1, d=d) -> Tri:
            snap = ctx.before if ctx.before is not None else rec.before_snap
            return _pair_any(a.tracks(snap), b.tracks(snap), lambda x, y: _adjacent(x.bbox, y.bbox, d))
        return _adj
    if name == "distance":
        op, k = _op(args[2]), args[3]

        def _dist(rec: Record, ctx: EvalContext, a=t0, b=t1, op=op, k=k) -> Tri:
            snap = ctx.before if ctx.before is not None else rec.before_snap
            ta, tb = a.tracks(snap), b.tracks(snap)
            if not ta or not tb:
                return None
            best = min(_gap(x.bbox, y.bbox) for x in ta for y in tb if x.tid != y.tid) if \
                any(x.tid != y.tid for x in ta for y in tb) else None
            return None if best is None else op(best, k)
        return _dist
    raise _Reject("unknown_predicate", name)


def _compile_guard(js: Any, vocab: Vocabulary, depth: int = 0) -> Callable[[Record, EvalContext], Tri]:
    """Compile a guard dict (predicate or combinator). Depth counts combinator nesting."""
    if js is None or js == {} or js is True:
        return lambda rec, ctx: True
    if not isinstance(js, dict) or len(js) != 1:
        raise _Reject("arity", f"guard must be a single-key dict, got {js!r}")
    (name, args), = js.items()
    if name in COMBINATORS:
        if depth + 1 > MAX_DEPTH:
            raise _Reject("depth", f"combinator nesting deeper than {MAX_DEPTH}")
        if name == "not":
            inner = _compile_guard(args, vocab, depth + 1)
            return lambda rec, ctx: (None if (v := inner(rec, ctx)) is None else not v)
        if not isinstance(args, list) or not args:
            raise _Reject("arity", f"{name} needs a non-empty list")
        parts = [_compile_guard(a, vocab, depth + 1) for a in args]
        if name == "and":
            return lambda rec, ctx: _tri_and([p(rec, ctx) for p in parts])
        return lambda rec, ctx: _tri_or([p(rec, ctx) for p in parts])
    if name == "always":
        return lambda rec, ctx: True
    arglist = list(args) if isinstance(args, list) else [args]
    return _compile_pred(name, arglist, vocab)


def _compile_effect(js: Any, vocab: Vocabulary) -> Callable[[Record, EvalContext], str]:
    """Compile one effect dict into a function of (record, ctx) -> SUPPORT/CONTRADICT/ABSTAIN."""
    if isinstance(js, str):
        js = {js: []}
    if not isinstance(js, dict) or not js:
        raise _Reject("arity", f"effect must be a dict, got {js!r}")
    if "expect" in js:                       # the plan's example shape {"expect":"pos","of":..,"delta":[..]}
        what = js.get("expect")
        if what == "pos" and "delta" in js:
            js = {"move": [js.get("of", "$self"), js["delta"]]}
        elif what in ("colour", "color") and "equals" in js:
            js = {"recolour": [js.get("of", "$self"), js["equals"]]}
        elif what == "gone":
            js = {"vanish": [js.get("of", "$self")]}
        elif what in ("level", "level_complete"):
            js = {"level_complete": []}
        elif "delta" in js:
            js = {"delta": [what, js["delta"]]}
        elif "equals" in js:
            js = {"set": [what, js["equals"]]}
        else:
            raise _Reject("unknown_effect", str(js))
    if len(js) != 1:
        raise _Reject("arity", f"effect must have one key, got {list(js)}")
    (name, args), = js.items()
    if name not in EFFECTS:
        raise _Reject("unknown_effect", name)
    arglist = list(args) if isinstance(args, list) else ([] if args in (None, True, {}) else [args])
    if name in ("nochange", "level_complete"):
        arglist = []
    if len(arglist) not in EFFECTS[name]:
        raise _Reject("arity", f"{name} takes {EFFECTS[name]} args, got {len(arglist)}")
    args = arglist

    if name == "nochange":
        def _nochange(rec: Record, ctx: EvalContext) -> str:
            if "veiled" in rec.delta.tags:
                return ABSTAIN
            return SUPPORT if (rec.delta.cells.n == 0 or "noop" in rec.delta.tags) else CONTRADICT
        return _nochange
    if name == "level_complete":
        return lambda rec, ctx: SUPPORT if rec.outcome.get("level_completed") else CONTRADICT
    if name == "set":
        v, val = _parse_var(args[0], vocab), args[1]

        def _set(rec: Record, ctx: EvalContext, v=v, val=val) -> str:
            after = ctx.after if ctx.after is not None else rec.after_snap
            if v in rec.delta.scalars:
                return SUPPORT if rec.delta.scalars[v][1] == val else CONTRADICT
            if after is not None and v in after.scalars:
                return SUPPORT if after.scalars[v] == val else CONTRADICT
            return ABSTAIN
        return _set
    if name == "delta":
        v, k = _parse_var(args[0], vocab), args[1]

        def _delta(rec: Record, ctx: EvalContext, v=v, k=k) -> str:
            pair = rec.delta.scalars.get(v)
            if pair is not None:
                return SUPPORT if pair[1] - pair[0] == k else CONTRADICT
            before = ctx.before if ctx.before is not None else rec.before_snap
            after = ctx.after if ctx.after is not None else rec.after_snap
            # The snapshots, when the delta does not carry the name. `Delta.scalars` is built
            # from the percept alone, and `consumed[X]`/`remaining[X]` are fact-layer tallies
            # that no single frame is a function of -- so they are never in it, while both
            # snapshots have them. Without this the whole contact family (`delta(consumed[X], 1)`,
            # which is what induce_contact_rules proposes) read CONTRADICT on every record it was
            # graded against and no such rule could ever be certified. `set` already had the
            # fallback; `delta` held both snapshots and read neither.
            if before is not None and after is not None and v in before.scalars and v in after.scalars:
                return SUPPORT if after.scalars[v] - before.scalars[v] == k else CONTRADICT
            if before is not None and v not in before.scalars:
                return ABSTAIN
            return SUPPORT if k == 0 else CONTRADICT
        return _delta

    t = _parse_term(args[0], vocab)
    if t.kind in ("var", "lit"):
        raise _Reject("unknown_entity", f"{name} needs an object term, got {args[0]!r}")
    if name == "move":
        shift = args[1]
        if not (isinstance(shift, (list, tuple)) and len(shift) == 2):
            raise _Reject("arity", "move needs (dr,dc)")
        dr, dc = int(shift[0]), int(shift[1])

        def _move(rec: Record, ctx: EvalContext, t=t, dr=dr, dc=dc) -> str:
            before = ctx.before if ctx.before is not None else rec.before_snap
            after = ctx.after if ctx.after is not None else rec.after_snap
            ts = t.tracks(before)
            if ts is None:
                # no snapshot: fall back to the object delta
                if t.kind == "self" or before is None:
                    return _move_from_delta(rec, t, dr, dc)
                return ABSTAIN
            if not ts:
                return ABSTAIN
            verdicts = []
            for x in ts:
                if x.tid in rec.delta.objects.occluded or x.tid in rec.delta.objects.ambiguous:
                    verdicts.append(ABSTAIN)
                    continue
                y = after.tracks.get(x.tid) if after is not None else None
                if y is None or not (y.live or y.state == "OCCLUDED"):
                    if after is None:
                        verdicts.append(_move_from_delta(rec, _Term("obj", x.tid), dr, dc))
                        continue
                    verdicts.append(CONTRADICT)
                    continue
                if y.state == "OCCLUDED" or y.state == "AMBIGUOUS":
                    verdicts.append(ABSTAIN)
                    continue
                got = (y.bbox[0] - x.bbox[0], y.bbox[1] - x.bbox[1])
                verdicts.append(SUPPORT if got == (dr, dc) else CONTRADICT)
            return _combine(verdicts)
        return _move
    if name == "recolour":
        col = _colour_value(args[1])
        if col is None:
            raise _Reject("unknown_entity", f"colour {args[1]!r}")

        def _recolour(rec: Record, ctx: EvalContext, t=t, col=col) -> str:
            before = ctx.before if ctx.before is not None else rec.before_snap
            after = ctx.after if ctx.after is not None else rec.after_snap
            ts = t.tracks(before)
            if ts is None:
                if t.kind == "obj":
                    rc = next((x for x in rec.delta.objects.recoloured if x[0] == t.key), None)
                    return ABSTAIN if rc is None else (SUPPORT if rc[2] == col else CONTRADICT)
                return ABSTAIN
            if not ts:
                return ABSTAIN
            verdicts = []
            for x in ts:
                rc = next((z for z in rec.delta.objects.recoloured if z[0] == x.tid), None)
                if rc is not None:
                    verdicts.append(SUPPORT if rc[2] == col else CONTRADICT)
                    continue
                y = after.tracks.get(x.tid) if after is not None else None
                if y is None:
                    verdicts.append(ABSTAIN)
                else:
                    verdicts.append(SUPPORT if y.colour == col else CONTRADICT)
            return _combine(verdicts)
        return _recolour
    if name == "vanish":
        def _vanish(rec: Record, ctx: EvalContext, t=t) -> str:
            before = ctx.before if ctx.before is not None else rec.before_snap
            after = ctx.after if ctx.after is not None else rec.after_snap
            ts = t.tracks(before)
            gone_now = set(rec.delta.objects.vanished) | set(rec.delta.objects.consumed)
            if ts is None:
                if t.kind == "obj":
                    return SUPPORT if t.key in gone_now else (
                        ABSTAIN if t.key in rec.delta.objects.occluded else CONTRADICT)
                return ABSTAIN
            if not ts:
                return ABSTAIN
            verdicts = []
            for x in ts:
                if x.tid in gone_now:
                    verdicts.append(SUPPORT)
                    continue
                if not (x.live or x.state == "OCCLUDED"):
                    verdicts.append(ABSTAIN)          # already gone before the action
                    continue
                if x.tid in rec.delta.objects.occluded:
                    verdicts.append(ABSTAIN)
                    continue
                y = after.tracks.get(x.tid) if after is not None else None
                if after is None:
                    verdicts.append(CONTRADICT)
                elif y is None or y.state in ("GONE", "CONSUMED"):
                    verdicts.append(SUPPORT)
                elif y.state in ("OCCLUDED", "AMBIGUOUS"):
                    verdicts.append(ABSTAIN)
                else:
                    verdicts.append(CONTRADICT)
            return _combine(verdicts)
        return _vanish
    raise _Reject("unknown_effect", name)


def _move_from_delta(rec: Record, t: _Term, dr: int, dc: int) -> str:
    """Grade a move effect from the object delta alone (no snapshots)."""
    objs = rec.delta.objects
    if t.kind == "self":
        tid = rec.before_snap.self_tid if rec.before_snap is not None else None
        if tid is None:
            return ABSTAIN
    else:
        tid = t.key
    if tid in objs.occluded or tid in objs.ambiguous:
        return ABSTAIN
    shift = next((s for x, s in objs.moved if x == tid), None)
    if shift is None:
        if tid in objs.vanished or tid in objs.consumed:
            return CONTRADICT
        shift = (0, 0)
    return SUPPORT if tuple(shift) == (dr, dc) else CONTRADICT


def _combine(verdicts: list[str]) -> str:
    if not verdicts:
        return ABSTAIN
    if CONTRADICT in verdicts:
        return CONTRADICT
    if ABSTAIN in verdicts:
        return ABSTAIN
    return SUPPORT


# --- compiled rule --------------------------------------------------------------------------


def _is_always(js: Any) -> bool:
    return js is None or js == {} or js is True or js == {"always": True} or js == {"always": []}


@dataclass
class CompiledRule:
    """A rule compiled to two closures. `guard` says whether the rule applies to a record
    (None = cannot tell), `effects` grades the consequent. `evaluate` combines them."""
    type: str
    when: dict[str, Any]
    then: list[dict[str, Any]]
    guard: Callable[[Record, EvalContext], Tri]
    effects: list[Callable[[Record, EvalContext], str]]
    always: bool = False

    def applies(self, rec: Record, ctx: Optional[EvalContext] = None) -> Tri:
        """Guard on the record's before state + action. True/False/None."""
        return self.guard(rec, ctx or EvalContext())

    def effects_hold(self, rec: Record, ctx: Optional[EvalContext] = None) -> str:
        """Grade the consequent regardless of the guard."""
        ctx = ctx or EvalContext()
        return _combine([e(rec, ctx) for e in self.effects])

    def evaluate(self, rec: Record, ctx: Optional[EvalContext] = None) -> str:
        """SUPPORT if the guard holds and every effect is observed; CONTRADICT if the guard
        holds and an effect fails; ABSTAIN if the guard is false or anything is unobservable."""
        ctx = ctx or EvalContext()
        g = self.guard(rec, ctx)
        if g is not True:
            return ABSTAIN
        return self.effects_hold(rec, ctx)


def compile_rule(js: dict[str, Any], vocab: Optional[Vocabulary] = None) -> "CompiledRule | RejectReason":
    """Compile a rule proposal. Returns a CompiledRule, or a RejectReason (a str) naming why:
    unknown_predicate, unknown_effect, arity, unknown_entity, depth, confidence_range,
    empty_because, unknown_type, type_rule (invariant without an always-guard + nochange
    effect; goal without level_complete)."""
    vocab = vocab or Vocabulary.permissive()
    try:
        rtype = js.get("type", "conditional")
        if rtype not in RULE_TYPES:
            raise _Reject("unknown_type", str(rtype))
        conf = js.get("confidence", js.get("p"))
        if conf is not None:
            try:
                c = float(conf)
            except (TypeError, ValueError):
                raise _Reject("confidence_range", repr(conf))
            if not (0.0 <= c <= 1.0):
                raise _Reject("confidence_range", repr(conf))
        if js.get("source", "model") != "harness":
            because = js.get("because")
            if not isinstance(because, list) or not because:
                raise _Reject("empty_because", "a rule must cite the ledger rows it rests on")
        when = js.get("when", {})
        then = js.get("then", [])
        if isinstance(then, dict):
            then = [then]
        if not isinstance(then, list) or not then:
            raise _Reject("arity", "then must be a non-empty list of effects")
        guard = _compile_guard(when, vocab)
        effects = [_compile_effect(e, vocab) for e in then]
        always = _is_always(when)
        if rtype == "invariant":
            names = {(list(e)[0] if isinstance(e, dict) else e) for e in then}
            if not always or not names <= {"nochange", "delta", "set"}:
                raise _Reject("type_rule", "invariant needs an always-guard and a nochange/delta-0 effect")
            for e in then:
                if not (isinstance(e, dict) and "delta" in e):
                    continue
                arg = e["delta"]
                # Shape-checked before it is indexed: `{"delta": "x"}` raised TypeError out of
                # compile_rule, past the `except _Reject` that turns a bad proposal into a
                # rejection reason, and out through the caller.
                if not (isinstance(arg, (list, tuple)) and len(arg) == 2):
                    raise _Reject("type_rule", 'a delta effect is ["<var>", <number>]')
                if arg[1] != 0:
                    raise _Reject("type_rule", "invariant delta must be 0")
        if rtype == "goal":
            names = {(list(e)[0] if isinstance(e, dict) else e) for e in then}
            if "level_complete" not in names:
                raise _Reject("type_rule", "goal rules must expect level_complete")
        return CompiledRule(type=rtype, when=when if isinstance(when, dict) else {}, then=list(then),
                            guard=guard, effects=effects, always=always)
    except _Reject as r:
        return r.reason


# --- scoring ---------------------------------------------------------------------------------


def _scope_records(rule: Rule, ledger: Any, level: Optional[int]) -> list[Record]:
    recs = list(ledger.records) if hasattr(ledger, "records") else list(ledger)
    if level is not None:
        return [r for r in recs if r.level == level]
    if rule.scope == "level" and recs:
        cur = recs[-1].level
        return [r for r in recs if r.level == cur]
    return recs


def score_rule(rule: Rule, ledger: Any, *, level: Optional[int] = None,
               compiled: Optional[CompiledRule] = None) -> RuleScore:
    """Replay every record in scope (the given level; else the current level for
    level-scoped rules; else all) and count SUPPORT / CONTRADICT / effect-ABSTAIN. Records the
    guard rejects are not applicable and do not count. conf = (s+1)/(s+c+2); coverage =
    (s+c)/(s+c+abstain); status vacuous (s+c == 0) / thin (s < 2 or coverage < 0.05) /
    partial (coverage < 0.5) / complete; stale if the latest graded record contradicts.
    An `autonomous` rule whose support is not spread over 2+ distinct actions is re-typed
    `conditional` in place. The score is written to rule.score and returned."""
    cr = compiled or compile_rule({"type": rule.type, "when": rule.when, "then": rule.then, "source": "harness"},
                                  Vocabulary.permissive())
    if isinstance(cr, RejectReason):
        rule.score = RuleScore()
        return rule.score
    recs = _scope_records(rule, ledger, level)
    all_recs = list(ledger.records) if hasattr(ledger, "records") else list(ledger)
    ctxs = dict(zip((r.idx for r in all_recs), contexts_for(all_recs)))
    sc = RuleScore()
    last_verdict: Optional[str] = None
    actions_supporting: set[str] = set()
    for rec in recs:
        ctx = ctxs.get(rec.idx, EvalContext())
        if cr.guard(rec, ctx) is not True:
            continue
        v = cr.effects_hold(rec, ctx)
        if v == SUPPORT:
            sc.support += 1
            sc.supporting_idx.append(rec.idx)
            actions_supporting.add(rec.action)
            last_verdict = v
        elif v == CONTRADICT:
            sc.contradict += 1
            sc.contradicting_idx.append(rec.idx)
            last_verdict = v
        else:
            sc.abstain += 1
    s, c = sc.support, sc.contradict
    sc.graded = s + c
    sc.conf = (s + 1) / (s + c + 2)
    sc.coverage = sc.graded / (sc.graded + sc.abstain) if (sc.graded + sc.abstain) else 0.0
    if sc.graded == 0:
        sc.status = "vacuous"
        sc.conf = 0.0
    elif s < 2 or sc.coverage < 0.05:
        sc.status = "thin"
    elif sc.coverage < 0.5:
        sc.status = "partial"
    else:
        sc.status = "complete"
    sc.stale = last_verdict == CONTRADICT
    if rule.type == "autonomous" and s > 0 and len(actions_supporting) < 2:
        rule.type = "conditional"
    if rule.type == "goal" and not any(r.outcome.get("level_completed") for r in recs):
        sc.status = "vacuous"
        sc.conf = 0.0
    rule.score = sc
    return sc


def status_for(score: RuleScore) -> str:
    """The store status a score earns: refuted (contradicted more often than supported, on
    enough evidence to mean it), active (usable-grade), quarantined (anything else). A
    refuted rule stays in the store as a record of a tested-and-false idea, but is never
    rendered as a rule or used for planning."""
    if score.graded >= REFUTE_MIN_GRADED and score.contradict > score.support:
        return "refuted"
    if score.conf >= 0.7 and not score.stale and score.status != "vacuous":
        return "active"
    return "quarantined"


def rule_usable(rule: Rule) -> bool:
    """Usable for planning: status partial/complete, conf >= 0.7, not stale, not a
    correlation (correlations must be promoted by promote_if_intervened first), and not
    retired/quarantined/refuted."""
    return (rule.score.usable and rule.type != "correlation"
            and rule.status in ("active", "proposed"))


def promote_if_intervened(rule: Rule, ledger: Any, *, level: Optional[int] = None) -> bool:
    """Promote a correlation rule to causal when the ledger shows an intervention: 2+ records
    where the antecedent was false before the previous action and true at this one (the
    harness's own action made it true) with the consequent observed, and 1+ record where
    the antecedent was false and the consequent did not occur. Returns True when promoted
    (rule.type becomes 'causal'); a non-correlation rule returns rule.type == 'causal'."""
    if rule.type == "causal":
        return True
    if rule.type != "correlation":
        return False
    cr = compile_rule({"type": "conditional", "when": rule.when, "then": rule.then, "source": "harness"},
                      Vocabulary.permissive())
    if isinstance(cr, RejectReason):
        return False
    all_recs = list(ledger.records) if hasattr(ledger, "records") else list(ledger)
    ctxs = contexts_for(all_recs)
    recs = _scope_records(rule, ledger, level)
    idx_of = {r.idx: i for i, r in enumerate(all_recs)}
    made_true = 0
    absent_when_false = 0
    for rec in recs:
        i = idx_of[rec.idx]
        g = cr.guard(rec, ctxs[i])
        if g is True and i > 0 and all_recs[i - 1].level == rec.level:
            prev = all_recs[i - 1]
            if cr.guard(prev, ctxs[i - 1]) is False and cr.effects_hold(rec, ctxs[i]) == SUPPORT:
                made_true += 1
        elif g is False:
            if cr.effects_hold(rec, ctxs[i]) == CONTRADICT:
                absent_when_false += 1
    if made_true >= 2 and absent_when_false >= 1:
        rule.type = "causal"
        return True
    return False


# --- rendering ------------------------------------------------------------------------------


def _short(a: str) -> str:
    return _norm_action(a).replace("ACTION", "A")


def _term_text(x: Any) -> str:
    if isinstance(x, (list, tuple)):
        return "(" + ",".join(str(v) for v in x) + ")"
    return str(x)


def _guard_text(js: Any) -> str:
    if _is_always(js):
        return "always"
    if not isinstance(js, dict) or len(js) != 1:
        return "?"
    (name, args), = js.items()
    if name == "and":
        return " & ".join(_guard_text(a) for a in args)
    if name == "or":
        return " | ".join(_guard_text(a) for a in args)
    if name == "not":
        return "not " + _guard_text(args)
    a = list(args) if isinstance(args, list) else [args]
    if name == "action_is":
        return _short(a[0])
    if name == "blocked":
        return f"blocked({_short(a[0])})"
    if name == "value":
        return f"{a[0]}{a[1]}{a[2]}"
    if name in ("distance", "count_of", "delta", "since_last"):
        if name == "distance":
            return f"dist({_term_text(a[0])},{_term_text(a[1])}){a[2]}{a[3]}"
        return f"{name}({_term_text(a[0])}){a[1]}{a[2]}"
    return f"{name}(" + ",".join(_term_text(v) for v in a) + ")"


def _effect_text(js: Any) -> str:
    if isinstance(js, str):
        return js
    if "expect" in js:
        return json.dumps(js, separators=(",", ":"))
    (name, args), = js.items()
    a = list(args) if isinstance(args, list) else ([] if args in (None, True, {}) else [args])
    if name == "move":
        return f"moves {_term_text(a[0])} {_term_text(a[1])}"
    if name == "recolour":
        return f"recolours {_term_text(a[0])} to {a[1]}"
    if name == "vanish":
        return f"{_term_text(a[0])} vanishes"
    if name == "set":
        return f"{a[0]}={a[1]}"
    if name == "delta":
        return f"{a[0]}{'+' if a[1] >= 0 else ''}{a[1]}"
    if name == "nochange":
        return "nothing changes"
    if name == "level_complete":
        return "level completes"
    return name


def describe_rule(rule: Rule) -> str:
    """One-phrase reading of a rule from its DSL, e.g. `A3 moves $self (-5,0)`."""
    if rule.text:
        return rule.text
    g = _guard_text(rule.when)
    e = ", ".join(_effect_text(x) for x in rule.then)
    return f"{g} {e}" if g != "always" else f"always: {e}"


def _conf_text(c: float) -> str:
    return f"{c:.2f}"[1:] if c < 1.0 else "1.0"


# --- the store ------------------------------------------------------------------------------


class RuleStore:
    """Rules by id, each scored against the ledger by the harness and never by the model.

    propose() compiles, scores and either stores (active / quarantined) or rejects with a
    reason; rescore_all() replays the ledger for every rule; usable() is what the planner may
    use; render() is what the model reads.
    """

    def __init__(self) -> None:
        self.rules: dict[str, Rule] = {}
        self._next = 1
        self._harness_keys: dict[str, str] = {}      # (guard, effect) -> rid, for sync()

    def _rid(self) -> str:
        rid = f"r{self._next}"
        self._next += 1
        return rid

    def propose(self, js: dict[str, Any], vocab: Optional[Vocabulary], ledger: Any, turn: int = 0,
                *, level: Optional[int] = None) -> "Rule | RejectReason":
        """Compile a proposal, score it against the ledger and store it. Rejects
        `no_evidence` when no record grades it. A model-proposed `causal` rule is stored as
        `correlation` and promoted only if `promote_if_intervened` passes. Status is active
        when the score is usable-grade (conf >= 0.7, not stale, not vacuous), else quarantined."""
        cr = compile_rule(js, vocab)
        if isinstance(cr, RejectReason):
            return cr
        rtype = js.get("type", "conditional")
        source = js.get("source", "model")
        if rtype == "causal" and source != "harness":
            rtype = "correlation"
        rule = Rule(rid=self._rid(), type=rtype, when=cr.when, then=cr.then, scope=js.get("scope", "level"),
                    because=list(js.get("because", [])), source=source, status="proposed",
                    text=str(js.get("text", "")), created_turn=turn)
        sc = score_rule(rule, ledger, level=level, compiled=cr)
        if sc.graded == 0:
            self._next -= 1
            return RejectReason("no_evidence", "no ledger record grades this rule")
        if rule.type == "correlation":
            promote_if_intervened(rule, ledger, level=level)
        rule.status = status_for(sc)
        self.rules[rule.rid] = rule
        return rule

    def adopt(self, rule: Rule) -> Rule:
        """Store a harness-built rule (e.g. from induce_control_rules), assigning an id if
        it has none."""
        if not rule.rid or rule.rid in self.rules:
            rule.rid = self._rid()
        self.rules[rule.rid] = rule
        return rule

    def sync(self, rules: list[Rule]) -> list[Rule]:
        """Fold a freshly induced batch of harness rules into the store.

        Induction runs every turn, so a rule must keep its identity: a rule with the same guard
        and effect updates the one already stored (score, status, because) instead of minting a
        new id, and the model keeps reading the same r-number for the same law. A stored
        harness rule that induction no longer emits is left alone -- `rescore_all` will refute
        it if the ledger has turned against it, which is a fact worth keeping, not a silent
        deletion. Returns the stored rules, in the order given.
        """
        out: list[Rule] = []
        for fresh in rules:
            key = _rule_key(fresh)
            rid = self._harness_keys.get(key)
            if rid is not None and rid in self.rules:
                kept = self.rules[rid]
                kept.score, kept.status, kept.because, kept.text = fresh.score, fresh.status, fresh.because, fresh.text
                out.append(kept)
                continue
            self.adopt(fresh)
            self._harness_keys[key] = fresh.rid
            out.append(fresh)
        return out

    def wall_colours(self) -> set[str]:
        """Colour letters a usable rule says block `$self` (effect: move by (0,0)). The
        planner's `passability.verdict(c) == "WALL"` with the ledger discipline applied: a
        colour only appears once a rule about it has more support than contradiction."""
        out: set[str] = set()
        for rule in self.usable():
            if not any(list(e)[0] == "move" and tuple(e["move"][1]) == (0, 0)
                       for e in rule.then if isinstance(e, dict) and "move" in e):
                continue
            for letter in _guard_classes(rule.when):
                out.add(letter)
        return out

    def shift_for(self, action: str) -> Optional[tuple[int, int]]:
        """The (dr,dc) a usable rule says `action` moves `$self` by, for an unguarded
        translation law only -- a rule guarded on adjacency describes a special case, not what
        the button does. None when no usable rule says."""
        want = _norm_action(action)
        best: Optional[tuple[int, int]] = None
        best_support = -1
        for rule in self.usable():
            # exactly `action_is(A)` and nothing else: `and[action_is(A), adjacent(...)]` is a
            # passability rule about one situation, not a statement about what the button does.
            if list(rule.when) != ["action_is"] or _guard_actions(rule.when) != {want}:
                continue
            for e in rule.then:
                if isinstance(e, dict) and "move" in e and e["move"][0] == "$self":
                    if rule.score.support > best_support:
                        best, best_support = (int(e["move"][1][0]), int(e["move"][1][1])), rule.score.support
        return best

    def rescore_all(self, ledger: Any, *, level: Optional[int] = None) -> None:
        """Re-score every non-retired rule against the ledger and refresh its status."""
        for rule in self.rules.values():
            if rule.status == "retired":
                continue
            sc = score_rule(rule, ledger, level=level)
            if rule.type == "correlation":
                promote_if_intervened(rule, ledger, level=level)
            rule.status = status_for(sc)

    def usable(self) -> list[Rule]:
        """Rules the planner may use (see rule_usable), best first."""
        return sorted((r for r in self.rules.values() if rule_usable(r)), key=self._rank, reverse=True)

    @staticmethod
    def _rank(r: Rule) -> tuple[float, int]:
        factor = {"complete": 1.0, "partial": 0.6, "thin": 0.3, "vacuous": 0.0}[r.score.status]
        return (r.score.conf * factor, r.score.support)

    def top(self, k: int = 6) -> list[Rule]:
        """The k best rules that are still standing (not retired, not refuted), best first."""
        live = [r for r in self.rules.values() if r.status not in ("retired", "refuted")]
        return sorted(live, key=self._rank, reverse=True)[:k]

    def refuted(self) -> list[Rule]:
        """Rules the ledger has voted down: kept so the model is not told them as facts and
        does not propose them again."""
        return [r for r in self.rules.values() if r.status == "refuted"]

    def render(self, k: int = 6) -> str:
        """One line per standing rule, e.g.
        `r4 conditional  A3 moves $self (-5,0)   12/0 conf .93 complete`, then a final line
        naming the refuted ones so a tested-and-false idea is not proposed twice."""
        lines = []
        for r in self.top(k):
            sc = r.score
            flags = ""
            if sc.stale:
                flags += " STALE"
            if r.type == "correlation":
                flags += " (not for planning)"
            if r.status == "quarantined":
                flags += " quarantined"
            lines.append(f"{r.rid} {r.type:<11} {describe_rule(r):<32} {sc.support}/{sc.contradict} "
                         f"conf {_conf_text(sc.conf)} {sc.status}{flags}")
        dead = self.refuted()
        if dead:
            lines.append("refuted (tested against the ledger and false, do not re-propose): "
                         + "; ".join(f"{r.rid} {describe_rule(r)} {r.score.support}/{r.score.contradict}"
                                     for r in dead[:k]))
        return "\n".join(lines)

    def retire(self, rid: str) -> bool:
        """Mark a rule retired (kept for the record, never rendered or used)."""
        r = self.rules.get(rid)
        if r is None:
            return False
        r.status = "retired"
        return True

    def get(self, rid: str) -> Optional[Rule]:
        return self.rules.get(rid)

    def to_json(self) -> dict[str, Any]:
        """Serialise every rule with its score."""
        out = []
        for r in self.rules.values():
            d = {"rid": r.rid, "type": r.type, "when": r.when, "then": r.then, "scope": r.scope,
                 "because": list(r.because), "source": r.source, "status": r.status, "text": r.text,
                 "created_turn": r.created_turn,
                 "score": {"support": r.score.support, "contradict": r.score.contradict,
                           "abstain": r.score.abstain, "graded": r.score.graded, "conf": r.score.conf,
                           "coverage": r.score.coverage, "status": r.score.status, "stale": r.score.stale,
                           "supporting_idx": list(r.score.supporting_idx),
                           "contradicting_idx": list(r.score.contradicting_idx)}}
            out.append(d)
        return {"next": self._next, "rules": out}

    @classmethod
    def from_json(cls, d: dict[str, Any]) -> "RuleStore":
        """Inverse of to_json."""
        st = cls()
        st._next = int(d.get("next", 1))
        for r in d.get("rules", []):
            s = r.get("score", {})
            rule = Rule(rid=r["rid"], type=r["type"], when=r["when"], then=r["then"], scope=r.get("scope", "level"),
                        because=list(r.get("because", [])), source=r.get("source", "model"),
                        status=r.get("status", "proposed"), text=r.get("text", ""),
                        created_turn=int(r.get("created_turn", 0)),
                        score=RuleScore(support=s.get("support", 0), contradict=s.get("contradict", 0),
                                        abstain=s.get("abstain", 0), graded=s.get("graded", 0),
                                        conf=s.get("conf", 0.0), coverage=s.get("coverage", 0.0),
                                        status=s.get("status", "vacuous"), stale=s.get("stale", False),
                                        supporting_idx=list(s.get("supporting_idx", [])),
                                        contradicting_idx=list(s.get("contradicting_idx", []))))
            st.rules[rule.rid] = rule
            if rule.source == "harness":
                st._harness_keys[_rule_key(rule)] = rule.rid
        return st


def induce_control_rules(ledger: Any, control_map: Any, vocab: Optional[Vocabulary] = None, *,
                         level: Optional[int] = None, min_count: int = 2,
                         max_candidates: int = 3) -> list[Rule]:
    """Harness-authored translation rules, one per action, source "harness":
    `action_is(A) -> move($self, (dr,dc))`, or `action_is(A) -> nochange` for a dead action.

    The control map is treated as a source of *candidates*, not verdicts. Its dominant
    signature is easily "other" -- one stray recolour or a tracker hiccup in the same step is
    enough -- so every self-shift the action has ever produced is tried (`move_signatures`),
    most-seen first, and the ledger decides. A candidate is emitted only when it earns
    `min_count` supports AND more supports than contradictions: a rule the record contradicts
    more often than it confirms is worse than no rule, because the model reads the RULES block
    as fact. The first candidate that passes wins; the rest are dropped, since two rules for
    one action would just disagree. `because` cites the rows that support it.
    """
    vocab = vocab or Vocabulary.permissive()
    out: list[Rule] = []
    for action in sorted(control_map.actions()):
        sig = control_map.signature(action)
        if sig.get("total", 0) < min_count:
            continue
        candidates: list[tuple[dict[str, Any], str]] = []
        if hasattr(control_map, "move_signatures"):
            moves = [(sh, n) for sh, n in control_map.move_signatures(action) if n >= min_count]
        else:                                     # older map: dominant only
            sh = control_map.expected_shift(action)
            moves = [(sh, sig["total"])] if sh else []
        for shift, _n in moves[:max_candidates]:
            candidates.append(({"move": ["$self", [shift[0], shift[1]]]},
                               f"{_short(action)} moves $self {_term_text(shift)}"))
        if sig.get("dominant") == "no-op":
            candidates.append(({"nochange": []}, f"{_short(action)} changes nothing"))
        for effect, text in candidates:
            js = {"type": "conditional", "when": {"action_is": action}, "then": [effect],
                  "scope": "level", "source": "harness", "text": text}
            cr = compile_rule(js, vocab)
            if isinstance(cr, RejectReason):
                continue
            rule = Rule(rid="", type="conditional", when=js["when"], then=js["then"], scope="level",
                        source="harness", status="proposed", text=text)
            sc = score_rule(rule, ledger, level=level, compiled=cr)
            if sc.support < min_count or sc.support <= sc.contradict:
                continue                          # the ledger does not back it: say nothing
            rule.because = list(sc.supporting_idx)
            rule.status = status_for(sc)
            out.append(rule)
            break
    return out


# --- harness-authored rule families -----------------------------------------------------------
#
# The model has never proposed a rule in a live run (rule_proposals=0 across every 27B run, the
# fifth time this project has measured "asking the model to write for the harness gets zero
# adoption"). So the store holds what the harness induces, and the harness must induce every
# fact it already knows -- not just the translation laws. Each family below states a fact the
# harness computes anyway (passability, consumption, dead controls) in the same DSL, scored the
# same way, so a wrong one dies on the ledger instead of being believed.


def _dir_of(shift: tuple[int, int]) -> Optional[str]:
    """Compass name of an axis-aligned shift, else None (a diagonal or a stand-still has no
    single adjacency direction, so no passability rule can be written for it)."""
    dr, dc = shift
    if dr and not dc:
        return "up" if dr < 0 else "down"
    if dc and not dr:
        return "left" if dc < 0 else "right"
    return None


def ledger_action_shifts(ledger: Any, *, level: Optional[int] = None) -> dict[str, list[tuple[tuple[int, int], int]]]:
    """Per action, the self shifts the *ledger* records, most seen first.

    The control map is a running tally keyed on whatever tid was believed to be the self at the
    time; the ledger keeps the self tid of each record, so this survives a tracker that re-ids
    the self mid-run. Used to pick the adjacency direction for passability rules.
    """
    recs = list(ledger.records) if hasattr(ledger, "records") else list(ledger)
    if level is not None:
        recs = [r for r in recs if r.level == level]
    tally: dict[str, dict[tuple[int, int], int]] = {}
    for rec in recs:
        snap = rec.before_snap
        tid = snap.self_tid if snap is not None else None
        if not tid:
            continue
        shift = next((tuple(sh) for t, sh in rec.delta.objects.moved if t == tid), None)
        if shift is None and rec.after_snap is not None and snap is not None:
            a, b = snap.tracks.get(tid), rec.after_snap.tracks.get(tid)
            if a is not None and b is not None and b.live:
                shift = (b.bbox[0] - a.bbox[0], b.bbox[1] - a.bbox[1])
        if not shift or shift == (0, 0):
            continue
        tally.setdefault(rec.action, {})
        tally[rec.action][shift] = tally[rec.action].get(shift, 0) + 1
    return {a: sorted(d.items(), key=lambda kv: (-kv[1], kv[0])) for a, d in tally.items()}


def _try_candidates(candidates: list[tuple[dict[str, Any], list[dict[str, Any]], str]], ledger: Any,
                    vocab: Vocabulary, *, level: Optional[int], min_count: int,
                    rtype: str = "conditional", scope: str = "level") -> Optional[Rule]:
    """Compile, score and return the first candidate the ledger backs: at least `min_count`
    supports and strictly more supports than contradictions. A rule the record contradicts more
    often than it confirms is worse than no rule, because the model reads RULES as fact."""
    for when, then, text in candidates:
        js = {"type": rtype, "when": when, "then": then, "scope": scope, "source": "harness", "text": text}
        cr = compile_rule(js, vocab)
        if isinstance(cr, RejectReason):
            continue
        rule = Rule(rid="", type=rtype, when=when, then=then, scope=scope, source="harness",
                    status="proposed", text=text)
        sc = score_rule(rule, ledger, level=level, compiled=cr)
        if sc.support < min_count or sc.support <= sc.contradict:
            continue
        rule.because = list(sc.supporting_idx)
        rule.status = status_for(sc)
        return rule
    return None


def letters_in(ledger: Any, *, level: Optional[int] = None) -> list[str]:
    """Colour letters that appear on the board in the ledger's snapshots."""
    recs = list(ledger.records) if hasattr(ledger, "records") else list(ledger)
    if level is not None:
        recs = [r for r in recs if r.level == level]
    out: set[str] = set()
    for rec in recs:
        for snap in (rec.before_snap, rec.after_snap):
            if snap is not None:
                out |= {t.letter for t in snap.tracks.values()}
    return sorted(out)


def induce_passability_rules(ledger: Any, passability: Any = None, vocab: Optional[Vocabulary] = None, *,
                             level: Optional[int] = None, min_count: int = 2,
                             max_rules: int = 12) -> list[Rule]:
    """Turn passability into scored rules: for each (action, colour) the ledger exercises,
    either "moving into that colour leaves `$self` put" (a wall) or "it moves `$self` by that
    action's shift" (a floor). At most one per pair, and only if the ledger backs it.

    `passability` is optional and only orders the candidates -- its verdict is *not* a gate.
    Passability is directional and its per-colour verdict is not: on the 129-record re86 ledger
    class:Y blocks upward 11 times out of 11 while class:c is open under A5 6 times out of 6,
    and both colours read MIXED in the aggregate, so gating on the verdict emitted nothing
    while the record decided seven pairs outright. Letting the ledger judge each pair recovers
    what the tally cannot say and still cannot produce a rule the record contradicts.
    """
    vocab = vocab or Vocabulary.permissive()
    shifts = ledger_action_shifts(ledger, level=level)
    letters = letters_in(ledger, level=level)
    if not letters and passability is not None:
        letters = [colour_letter(c) for c in passability.colours()]
    verdicts: dict[str, str] = {}
    if passability is not None:
        for colour in passability.colours():
            verdicts[colour_letter(colour)] = passability.verdict(colour)
    out: list[Rule] = []
    for action in sorted(shifts):
        best = shifts[action][0][0]
        direction = _dir_of(best)
        if direction is None:
            continue
        for letter in letters:
            contact = {"and": [{"action_is": action}, {"adjacent": ["$self", f"class:{letter}", direction]}]}
            wall = (contact, [{"move": ["$self", [0, 0]]}],
                    f"{_short(action)} into class:{letter} does not move $self (wall)")
            floor = (contact, [{"move": ["$self", [best[0], best[1]]]}],
                     f"{_short(action)} into class:{letter} moves $self {_term_text(best)}")
            cands = [floor, wall] if verdicts.get(letter) == "OPEN" else [wall, floor]
            rule = _try_candidates(cands, ledger, vocab, level=level, min_count=min_count)
            if rule is not None:
                out.append(rule)
            if len(out) >= max_rules:
                return out
    return out


_FEATURE_RE = re.compile(r"^(?P<var>[A-Za-z_][A-Za-z0-9_]*\[[^\]]+\]|[A-Za-z_][A-Za-z0-9_]*)"
                         r"\s*(?P<op><=|>=|==|!=|<|>)\s*(?P<k>-?\d+)$")
_GONE_RE = re.compile(r"^gone\[(?P<klass>[^\]]+)\]$")


def guard_from_feature(name: str) -> Optional[dict[str, Any]]:
    """Compile one precondition-miner feature name into a DSL guard, or None if it is not
    expressible.

    The grammar the miner's feature names must follow to become rules:
      `consumed[Y]>=2`, `remaining[b]>0`, `hud[top].filled<3`   -> value(var, op, k)
      `gone[Y]`                                                 -> gone(class:Y)
      `!<any of the above>`                                     -> not(...)
    Anything else (`target_is_W`, `adjacent=up`) stays a printed fact line: it names no
    scalar the ledger records, so no rule can be scored against it.
    """
    if not isinstance(name, str) or not name:
        return None
    if name.startswith("!"):
        inner = guard_from_feature(name[1:])
        return {"not": inner} if inner else None
    m = _FEATURE_RE.match(name.strip())
    if m:
        return {"value": [m.group("var"), m.group("op"), int(m.group("k"))]}
    m = _GONE_RE.match(name.strip())
    if m:
        return {"gone": f"class:{m.group('klass')}"}
    return None


def induce_contact_rules(ledger: Any, consumption: Any, miner: Any = None,
                         vocab: Optional[Vocabulary] = None, *, level: Optional[int] = None,
                         min_count: int = 2, min_separator_coverage: float = 0.5) -> list[Rule]:
    """The mechanic of an elimination game, which nothing in the store expressed: touching a
    member of a consumed class raises `consumed[X]`.

    Plain forms first (`adjacent`, then `overlaps`); if the ledger contradicts them -- which is
    what a gated collectable looks like -- the miner's separators are tried as guards, so
    "succeeds iff consumed[Y]>0" becomes a rule rather than a sentence. `consumed[X]` is the
    effect rather than `vanish(class:X)` because the DSL has no way to bind *which* member was
    touched, and the counter is the thing the goal actually depends on.
    """
    vocab = vocab or Vocabulary.permissive()
    out: list[Rule] = []
    guards: list[dict[str, Any]] = []
    if miner is not None and hasattr(miner, "separators"):
        for feature, _score, n in miner.separators(top=3):
            rows = len(getattr(miner, "rows", ()) or ())
            if rows and n / rows < min_separator_coverage:
                continue
            g = guard_from_feature(feature)
            if g is not None:
                guards.append(g)
    for klass in consumption.classes():
        if not consumption.consumed_tids.get(klass):
            continue
        var = f"consumed[{klass}]"
        effect = [{"delta": [var, 1]}]
        plain = [
            ({"adjacent": ["$self", f"class:{klass}"]}, effect, f"touching class:{klass} raises {var}"),
            ({"overlaps": ["$self", f"class:{klass}"]}, effect, f"entering class:{klass} raises {var}"),
        ]
        guarded = []
        for g in guards:
            for contact, _e, _t in plain:
                guarded.append(({"and": [contact, g]}, effect,
                                f"touching class:{klass} raises {var} when {_guard_text(g)}"))
        rule = _try_candidates(plain + guarded, ledger, vocab, level=level, min_count=min_count)
        if rule is not None:
            out.append(rule)
    return out


def induce_harness_rules(ledger: Any, *, control_map: Any = None, passability: Any = None,
                         consumption: Any = None, miner: Any = None, vocab: Optional[Vocabulary] = None,
                         level: Optional[int] = None, min_count: int = 2) -> list[Rule]:
    """Every harness-authored family in one call: translation laws and dead controls
    (`induce_control_rules`), passability (`induce_passability_rules`), contact and consumption
    (`induce_contact_rules`). Duplicates -- the same guard and effect from two families -- are
    kept once. Feed the result to `RuleStore.sync`, which keeps rule ids stable across turns.
    """
    out: list[Rule] = []
    if control_map is not None:
        out += induce_control_rules(ledger, control_map, vocab, level=level, min_count=min_count)
    if passability is not None:
        out += induce_passability_rules(ledger, passability, vocab, level=level, min_count=min_count)
    if consumption is not None:
        out += induce_contact_rules(ledger, consumption, miner, vocab, level=level, min_count=min_count)
    seen: set[str] = set()
    unique: list[Rule] = []
    for rule in out:
        key = _rule_key(rule)
        if key in seen:
            continue
        seen.add(key)
        unique.append(rule)
    return unique


def _rule_key(rule: Rule) -> str:
    """Identity of a harness rule: its guard and effect, so re-inducing it every turn finds the
    same rule instead of minting r1..r500."""
    return json.dumps([rule.type, rule.when, rule.then], sort_keys=True, separators=(",", ":"))


def _guard_actions(when: Any) -> set[str]:
    """Every action named by an action_is anywhere in a guard."""
    if not isinstance(when, dict):
        return set()
    out: set[str] = set()
    for name, args in when.items():
        if name == "action_is":
            out.add(_norm_action(args[0] if isinstance(args, list) else args))
        elif name in ("and", "or"):
            for a in (args if isinstance(args, list) else [args]):
                out |= _guard_actions(a)
        elif name == "not":
            out |= _guard_actions(args)
    return out


def _guard_classes(when: Any) -> set[str]:
    """Every `class:<X>` key named anywhere in a guard."""
    out: set[str] = set()
    if not isinstance(when, dict):
        return out
    for name, args in when.items():
        if name in ("and", "or"):
            for a in (args if isinstance(args, list) else [args]):
                out |= _guard_classes(a)
        elif name == "not":
            out |= _guard_classes(args)
        else:
            for a in (args if isinstance(args, list) else [args]):
                if isinstance(a, str) and a.startswith("class:"):
                    out.add(a[6:])
    return out


def world_model_confidence(ledger: Any, store: Any, actions: Iterable[str] = (), *, window: int = 8,
                           control: Any = None) -> float:
    # `last_parts` carries the three terms out for telemetry. This number gates the commit
    # decision and fell towards zero in every run on every game all day, through fifteen fixes
    # upstream of it; a number that indifferent to its inputs has to be able to say which of its
    # own terms is doing it.
    """"Is the world model good enough to act on?", stated from the ledger's own grades rather
    than from a rule count.

    0.4 * clean   -- of the last `window` graded records, the share whose prediction was not
                     violated (the model said what would happen and it happened),
    0.3 * covered -- how much of each frame's change the predictions actually accounted for,
                     averaged. This used to be the share of records graded `complete`, meaning
                     nothing at all changed that nobody had claimed. Measured over a 67-turn
                     re86 run it was 0.000 on every single turn: on a real board an action always
                     moves something incidental -- a counter, an animation, a second object -- so
                     "complete" is a bar nothing clears. Three tenths of this number were
                     therefore unavailable at all times, and the commit gate wants 0.70, so the
                     world-model channel could not open it however good the model got. Partial
                     credit for partial explanation is what a confidence is supposed to be.
    0.3 * lawful  -- the share of available actions whose effect the ledger backs, either as a
                     usable rule or as a settled reading in the control map.

                     Both count, because both are the ledger's own verdict and the rule store is
                     only one way of writing it down. A rule says `move($self, (dr,dc))` and
                     nothing else; an action that travels a different distance each time -- a body
                     that slides until it hits something -- can never earn one, however many times
                     it is pressed and however consistent it is. Measured live on ls20: the
                     control map had settled all four directions and read 1.0, while this term sat
                     at 0.25 on one rule, capping the whole channel at 0.688 against a gate of
                     0.70. The knowledge was there; the representation could not hold it.

    A rule count saturates: once four rules exist the term is pinned at 1.0 whether or not the
    rules describe what is happening. All three terms here can be driven back down by the very
    next surprising record, which is what a confidence channel is for.
    """
    recs = list(ledger.records) if hasattr(ledger, "records") else list(ledger)
    # The last `window` GRADED records, not the graded ones among the last `window` records.
    # The harness's own measurement batches commit up to twelve actions with no prediction at
    # all (there is nothing to predict about a button nobody has read), so one of them pushed
    # every graded record out of the window; `graded` came back empty, and empty evidence was
    # scored as zero confidence rather than as no evidence. The channel then sat at 0.3 or less
    # against a gate of 0.70 -- the harness's own exploration closing the harness's commit gate.
    gradable = [r.comparison for r in recs
                if r.comparison is not None and r.comparison.coverage_status != "vacuous"]
    graded = gradable[-window:]
    # A record counts as clean only if something was actually graded on it. With every claim
    # abstained (veiled vars, an occluded or ambiguous tid) the comparison has no violations
    # simply because it has no verdicts -- so "everything I predicted came true" and "nothing I
    # predicted could be checked" scored the same, and the term was inflated on exactly the
    # steps the harness could see least.
    judged = [c for c in graded if (len(c.matched) + len(c.violated)) > 0]
    clean = sum(1 for c in judged if not c.violated) / len(judged) if judged else 0.0
    covered = (sum(float(getattr(c, "coverage", 0.0) or 0.0) for c in graded) / len(graded)
               if graded else 0.0)
    acts = [a for a in actions if a != "RESET"]
    usable = store.usable() if hasattr(store, "usable") else list(store)
    lawful_actions = set()
    for rule in usable:
        lawful_actions |= _guard_actions(rule.when)
    def _backed(a: str) -> bool:
        if _norm_action(a) in lawful_actions:
            return True
        try:
            return bool(control is not None and control.known(a))
        except Exception:  # noqa: BLE001
            return False

    lawful = (sum(1.0 for a in acts if _backed(a)) / len(acts)) if acts else 0.0
    world_model_confidence.last_parts = {"clean": round(clean, 3), "covered": round(covered, 3),
                                         "lawful": round(lawful, 3), "graded": len(graded),
                                         "judged": len(judged)}
    return round(0.4 * clean + 0.3 * covered + 0.3 * lawful, 4)
