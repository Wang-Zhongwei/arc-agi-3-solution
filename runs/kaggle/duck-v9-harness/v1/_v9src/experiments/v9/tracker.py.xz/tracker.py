"""Object identity across frames: which blob is which object, and what happened to it.

Nothing else in this repo tracks identity beyond two frames. `frame_diff` matches a pair
of frames and forgets; `transition_log` describes a transition. A world model needs the
third thing: a name that survives a recolour, a step behind a curtain, and a level.

The contract:

* `update(percept, step=, acted=)` folds one frame in and returns the events it caused.
* `tracks` is append-only. A dead object is tombstoned (state GONE/CONSUMED), never
  deleted, so a ledger row from step 4 that names `t7` is still resolvable at step 300.
* every list is sorted by an explicit key, and every tie in the assignment is broken by
  `(cost, bbox, shape_hash, tid)`. Re-running the same frames yields the same ids.

Design notes that are not obvious from the signatures:

* **Identity is form, not colour.** The cost function charges 3 for a different
  `form_hash` and only 2 for a different colour, so a recolour keeps the tid and a
  reshape is the more suspicious event. This is what makes a recolour-on-contact a
  RECOLOUR rather than a death plus a birth.
* **Absence is not death.** A missing track whose last footprint meets the veil, or is now
  under another track's cells, is OCCLUDED with its position frozen and a TTL of 8 steps.
  Only an unexplained absence is a VANISH.
* **Indistinguishable objects are not guessed at.** N identical blobs that all moved by
  one common displacement are assigned by that displacement (cheap, certain, and the
  camera-scroll case). N identical blobs whose pairing has two equal-cost readings go into
  an `ambiguity_group`, state AMBIGUOUS, and emit no MOVE -- an honest "I do not know
  which is which" beats a coin flip that then poisons every rule scored against it.
"""

from __future__ import annotations

from typing import Any, Iterable, Optional

from .types import Blob, Cell, Event, Percept, Track, TrackState

MAX_SHIFT = 8
"""Chebyshev gate for a match, in cells, before the track's own velocity widens it."""

OCCLUSION_TTL = 8
"""Steps an OCCLUDED track is believed to still exist before it becomes GONE."""

BLINK_WINDOW = 8
BLINK_MAX_RUN = 3
BLINK_MIN_TRANSITIONS = 3
REVIVE_WITHIN = 3
"""A GONE track this recent, at the same spot and shape, is a blink and not a new object."""

COVER_FRAC = 0.5
"""Fraction of a vanished track's footprint another object must hold to explain it."""

GROUP_MIN_SHARED_MOVES = 2
"""Acted steps on which two tracks must have made the same non-zero move to be one body."""

GROUP_WINDOW = 24
"""How many *steps* back the rigid-grouping test looks. Older history ages out, so a body is
not condemned forever by one bad frame twenty moves ago -- nor by what one of its parts was
doing before it became part of it."""

MOTION_WINDOW = 64
"""Acted steps of per-track displacement kept for the rigid-grouping test."""

SELF_STICKY = 1.25
# How many recent frames a part must have belonged to the body for a plan to be built around it.
BODY_HISTORY = 4
"""How much bigger a rival body must be before `self_tid` moves to it.

Everything the harness knows about its controls is keyed on the self, so changing its mind
about what it is controlling throws that away and starts again. Raising this to 1.5 was
tried against the audit on re86, sk48 and dc22 and changed nothing on any of them, so it
stays where the measurement supports it."""

AMBIGUITY_MAX_GROUP = 32
"""Above this many identical objects the pairwise tie test is skipped (documented limit)."""


def _cheb(a: tuple[float, float], b: tuple[float, float]) -> float:
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]))


def _topleft(bbox: tuple[int, int, int, int]) -> tuple[int, int]:
    return (bbox[0], bbox[1])


class ObjectTracker:
    """Stable object ids over a sequence of `Percept`s.

    One tracker per game. `archive_level(level)` moves the current tracks aside at a level
    boundary and keeps the id counter, so ids never collide across levels and the previous
    level's objects remain readable for "what is new here".
    """

    def __init__(self, *, max_shift: int = MAX_SHIFT, occlusion_ttl: int = OCCLUSION_TTL) -> None:
        self.tracks: dict[str, Track] = {}
        self.archived: dict[int, dict[str, Track]] = {}
        self.self_tid: Optional[str] = None
        self._body_history: list[list[str]] = []   # recent membership, for reference
        self._body_sizes: list[int] = []           # recent cell counts, which is the measurement
        # Rigid co-moving bodies: group id -> member tids, in id order. A group is an
        # overlay on the tracks, never a merge: every member keeps its own tid, blob,
        # events and history, and a group that stops holding together simply dissolves.
        self.groups: dict[int, list[str]] = {}
        self.max_shift = int(max_shift)
        self._max_shift0 = int(max_shift)     # what a level starts from; widen() only raises it
        self.occlusion_ttl = int(occlusion_ttl)
        self._n = 0
        self._ambig = 0
        self._presence: dict[str, list[bool]] = {}
        self._prev_positions: dict[str, int] = {}
        # tid -> {acted step: displacement}. The evidence rigid grouping is computed from.
        self._motion: dict[str, dict[int, tuple[int, int]]] = {}
        # survivor tid -> the parts it swallowed, so a later split can give the ids back.
        self._absorbed: dict[str, list[dict[str, Any]]] = {}
        # absorbed tid -> the survivor that holds it, so `self_tid` can follow a merge.
        self._merged_into: dict[str, str] = {}
        # (step, tids) for each set of tracks that was one connected component at that step.
        self._family: list[tuple[int, frozenset[str]]] = []
        # The frame's palette permutation, if any; set per update and read by _cost.
        self._pmap: Optional[dict[int, int]] = None
        # Whether the current frame is explained by a camera scroll; see _apply_match.
        self._scrolled = False
        self._scroll: tuple[int, int] = (0, 0)
        # Whether any HUD band has been located yet; see _is_hud.
        self._bands_known = False
        # Displacements the caller says this action has produced before; widens the gate.
        self._expected: tuple[tuple[int, int], ...] = ()

    # --- public views -------------------------------------------------------------------

    def live(self) -> list[Track]:
        """Tracks believed to exist right now: LIVE, AMBIGUOUS or OCCLUDED, in id order.

        OCCLUDED is included because the whole point of the occlusion state is that the
        object is believed to still be there; its position is frozen, not forgotten.
        """
        alive = (TrackState.LIVE, TrackState.AMBIGUOUS, TrackState.OCCLUDED)
        return [self.tracks[t] for t in sorted(self.tracks, key=_tid_key)
                if self.tracks[t].state in alive]

    def positions(self) -> dict[str, int]:
        """`pos[<tid>].r` / `pos[<tid>].c` for every live track, as the bbox top-left.

        Top-left rather than centroid because the scalar registry is integer-valued and a
        centroid of an even-sized object is a half-cell -- a prediction of "delta pos.r by
        1" must not be unfalsifiable because of a rounding choice.

        When a self is known, `pos[self].r` / `pos[self].c` are also emitted, as the
        top-left of the union bounding box of the whole self group. `self` is a reserved
        pseudo-tid. On re86 the controlled body is five separate components; without this
        name every claim about "where I am" has to pick one arbitrary fragment and every
        step reports five position changes where the player made one move.
        """
        out: dict[str, int] = {}
        for track in self.live():
            r0, c0 = _topleft(track.last_bbox)
            out["pos[%s].r" % track.tid] = int(r0)
            out["pos[%s].c" % track.tid] = int(c0)
        bbox = self.self_bbox()
        if bbox is not None:
            out["pos[self].r"] = int(bbox[0])
            out["pos[self].c"] = int(bbox[1])
        return out

    def self_group(self) -> list[str]:
        """The tids that move as one body with `self_tid`, in id order.

        `[self_tid]` when the self is a single component, `[]` when no self is known yet.
        """
        if not self.self_tid:
            return []
        gid = getattr(self.tracks[self.self_tid], "group", None)
        if gid is None or gid not in self.groups:
            return [self.self_tid]
        return list(self.groups[gid])

    def stable_body_cells(self) -> frozenset:
        """The body the planner should build a route around: all of it, as it is now.

        This used to intersect the group's membership across frames, on the theory that a part
        which comes and goes should not be planned around. The body audit on re86 showed why that
        is wrong: a sprite that merges and splits is described by one tid when welded and five
        when apart, every five steps, while its cell count never moves off 53. Intersecting
        membership there throws away four fifths of a body that never changed.

        Membership is bookkeeping. The cell count is the measurement, and `body_is_settled` is
        where it is judged: when the body really is losing cells, the answer is to commit fewer
        steps and look again, not to plan around a body that does not exist.
        """
        return self.body_cells()

    def body_is_settled(self, *, tolerance: Optional[int] = None) -> bool:
        """Has the body been the same size for the last few frames?

        On ls20 the body measured 60 cells when an eight-step plan was made and 44 when it
        arrived, then 44 and 28: sixteen cells per batch, twice running, about two per action. No
        amount of intersecting past membership describes a body that is still changing while the
        batch runs. What the harness can do is stop committing eight steps to it and re-plan
        against a fresh frame instead.
        """
        sizes = [n for n in getattr(self, "_body_sizes", []) if n]
        if len(sizes) < 2:
            return True
        if tolerance is None:
            # Proportional, not absolute. Two cells is an enormous change to a four-cell body and
            # noise on a sixty-cell one, and a fixed two meant ls20's body was never once settled:
            # every plan capped at three steps for the life of the run, so the explore planner
            # returned "3 squares the body has never occupied" turn after turn and the harness
            # walked up the board three cells at a time. A cap that is always on is not a
            # safeguard, it is a limit.
            typical = sorted(sizes)[len(sizes) // 2]
            tolerance = max(2, int(0.15 * typical))
        return (max(sizes) - min(sizes)) <= tolerance

    def _cells_of(self, tids: list[str]) -> frozenset:
        out: set = set()
        for tid in tids:
            track = self.tracks.get(tid)
            if track is not None and track.blob is not None:
                out |= set(track.blob.cells)
        return frozenset(out)

    def note_body(self) -> None:
        """Remember this frame's membership, so later frames can tell what stayed.

        A few frames, not one. On ls20 the body measured 50 cells when a plan was made and 34 when
        it arrived even with a single frame of history: membership churns over several frames, and
        the intersection has to be taken over all of them to describe a body that will still be
        there at the end of a batch.
        """
        hist = list(getattr(self, "_body_history", []))
        hist.append(list(self.self_group()))
        self._body_history = hist[-BODY_HISTORY:]
        # The count as it was measured at the time. Re-measuring a past membership against
        # today's blobs reads stale cells off tracks that have since gone.
        sizes = list(getattr(self, "_body_sizes", []))
        sizes.append(len(self.body_cells()))
        self._body_sizes = sizes[-BODY_HISTORY:]

    def body_cells(self) -> frozenset:
        """Every cell of the body, across all the tracks that move as one with it.

        The self track is a name for the body, not always the whole of it: a sprite that welds
        and unwelds leaves `self_tid` pointing at one part, and on ls20 level 2 the body measured
        28 cells on one turn and 15 on the next. A planner given one arm plans a route that stops
        two cells short of everything, and the miss is invisible because the body did arrive
        exactly where the plan said it would.
        """
        out: set = set()
        for tid in self.self_group():
            track = self.tracks.get(tid)
            if track is None or track.blob is None:
                continue
            if track.state in (TrackState.GONE, TrackState.CONSUMED):
                continue
            out |= set(track.blob.cells)
        return frozenset(out)

    def self_bbox(self) -> Optional[tuple[int, int, int, int]]:
        """The union bounding box of the live members of the self group, or None."""
        boxes = [self.tracks[t].last_bbox for t in self.self_group()
                 if t in self.tracks and self.tracks[t].state in
                 (TrackState.LIVE, TrackState.AMBIGUOUS, TrackState.OCCLUDED)]
        if not boxes:
            return None
        return (min(b[0] for b in boxes), min(b[1] for b in boxes),
                max(b[2] for b in boxes), max(b[3] for b in boxes))

    def group_of(self, tid: str) -> Optional[int]:
        track = self.tracks.get(tid)
        return getattr(track, "group", None) if track is not None else None

    def previous_positions(self) -> dict[str, int]:
        """`positions()` as it stood immediately before the last `update`."""
        return dict(self._prev_positions)

    def controllable_candidates(self) -> list[str]:
        """Tracks that have moved, and have only ever moved on a step where we acted.

        This is the harness's answer to "which of these things is me?" before any model has
        said a word. A single move is enough to be a candidate; two are needed to be picked
        as `self_tid`.

        HUD components are excluded outright. A step counter on the bottom border advances
        on every action and therefore looks exactly like a controllable object to a
        move-counting test -- re86's row-63 bar was picked up as `controllable` before this.
        A thing that is part of the readout is not a thing you are moving.
        """
        out = []
        for tid in sorted(self.tracks, key=_tid_key):
            track = self.tracks[tid]
            if track.state is TrackState.GONE or _is_hud(track):
                continue
            if _moves(track, True) >= 1 and _moves(track, False) == 0:
                out.append(tid)
        return out

    # --- the fold -----------------------------------------------------------------------

    def update(self, percept: Percept, *, step: int, acted: bool,
               expected_shifts: Optional[Iterable[tuple[int, int]]] = None) -> list[Event]:
        """Fold one frame in and return the events it caused, in a stable order.

        `acted` says whether an action was executed to produce this frame. It is the only
        thing separating "it moved because I pressed a key" from "it moved on its own", so
        it decides `controllable` vs `autonomous` and gates `self_tid`.

        `expected_shifts` is optional: the (dr, dc) displacements the caller's control map
        has already seen for the action just executed. They widen the chebyshev gate and
        seed the rigid-group and consensus passes, so an action known to teleport the player
        thirteen cells does not have to re-earn its identity every time. The tracker works
        without it -- `_consensus` recovers a large jump from two agreeing tracks on its own
        -- but the first such jump of a game is cheaper to follow when it is passed in.

        Resolution order, cheapest and most certain first: containment (merge/split), then
        rigid groups of identical objects, then cost-based greedy assignment, then a
        consensus pass over what is left, then the pairwise tie test that demotes an
        unresolvable pairing to AMBIGUOUS.
        """
        self._prev_positions = self.positions()
        events: list[Event] = []
        step = int(step)
        self._expected = tuple(sorted({(int(a), int(b)) for a, b in (expected_shifts or ())}))

        # Sprites (`parts`) are the union view of blobs already tracked individually, and
        # background/veiled components are not objects. Both would double-count.
        pool_blobs = [b for b in percept.blobs
                      if b.region in ("board", "hud") and not b.parts]
        shift = (0, 0)
        self._pmap = None
        self._scrolled = False
        self._scroll = (0, 0)
        if percept.transform and percept.transform.get("kind") == "scroll":
            shift = (int(percept.transform["dr"]), int(percept.transform["dc"]))
            self._scrolled = True
            self._scroll = shift
        elif percept.transform and percept.transform.get("kind") == "palette":
            # A theme change repaints every object at once. Without applying the map to the
            # tracks' expected colours, a two-object palette swap makes each object look
            # more like the *other* object's new colour than like itself, and the ids cross.
            self._pmap = {int(k): int(v) for k, v in percept.transform["map"].items()}

        # Only once bands are known can "outside the HUD" mean anything; before that every
        # blob is outside one, including the HUD's own.
        self._bands_known = bool(percept.hud_bands)
        pool_tracks = [t for t in self.live() if t.blob is not None]

        # A known rigid body claims its own parts first. Containment (merge/split) matches
        # against a *previous* frame's footprint, so when two bodies overlap it can hand a
        # bar that plainly belongs to the body that just moved three cells left to whatever
        # component used to cover that spot. A live body's own displacement is the better
        # evidence, and a body that has genuinely welded fails the coverage test here and
        # falls through to the containment passes unharmed.
        rigid = self._group_shifts(pool_tracks, pool_blobs, shift)
        merged = self._merges(pool_tracks, pool_blobs, step, events)
        split = self._splits(pool_tracks, pool_blobs, step, events)
        rigid += self._rigid_groups(pool_tracks, pool_blobs, shift)

        # Each pass removes the blobs it claimed from the pool, but nothing removed the tracks,
        # so a track matched by one pass was offered to the next as though it were still free.
        # On a board of identical pieces that is not a near miss: greedy claimed a stationary
        # dot's blob, consensus then re-matched the same tid onto a dot thirteen rows away, and
        # the stationary object was left with no track at all -- invisible to everything
        # downstream, plus a false VANISH and a doubled move count for the tid that walked off.
        claimed = {t.tid for t, _b in rigid + merged + split}
        revivable = [t for t in self.tracks.values()
                     if t.state in (TrackState.GONE, TrackState.CONSUMED)
                     and 0 < step - t.last_seen <= REVIVE_WITHIN and t.blob is not None
                     and t.tid not in claimed]
        greedy = self._greedy([t for t in pool_tracks if t.tid not in claimed] + revivable,
                              pool_blobs, shift)
        claimed |= {t.tid for t, _b in greedy}
        greedy += self._consensus([t for t in pool_tracks if t.tid not in claimed], pool_blobs)

        ambiguous = self._mark_ambiguity(greedy, shift)
        matched = merged + split + rigid + greedy
        structural = {id(pair) for pair in merged} | {id(pair) for pair in split}

        # Belt and braces over the filtering above: one track, one blob, and the earlier pass
        # wins (merge and split before rigid, rigid before greedy). Applying a tid twice emits
        # two MOVEs for one step and counts the move twice in the control evidence.
        once: list[tuple[Track, Blob]] = []
        taken: set[str] = set()
        for pair in matched:
            if pair[0].tid in taken:
                continue
            taken.add(pair[0].tid)
            once.append(pair)
        matched = once
        seen: set[str] = set()
        for pair in sorted(matched, key=lambda p: _tid_key(p[0].tid)):
            track, blob = pair
            seen.add(track.tid)
            self._apply_match(track, blob, step=step, acted=acted,
                              ambiguous=track.tid in ambiguous, events=events,
                              structural=id(pair) in structural)

        for blob in list(pool_blobs):
            track = self._spawn(blob, percept.level, step)
            seen.add(track.tid)
            events.append(Event(kind="SPAWN", tid=track.tid, step=step,
                                detail={"colour": blob.colour, "pixels": blob.pixels}))

        live_cells = {t.tid: (t.blob.cells if t.blob else frozenset())
                      for t in self.tracks.values()
                      if t.tid in seen and t.state in (TrackState.LIVE, TrackState.AMBIGUOUS)}
        movers = {e.tid for e in events if e.kind == "MOVE"}
        for tid in sorted(self.tracks, key=_tid_key):
            track = self.tracks[tid]
            if tid in seen or track.state in (TrackState.GONE, TrackState.CONSUMED):
                continue
            self._miss(track, step=step, veil=percept.veil, live_cells=live_cells,
                       movers=movers, events=events)

        self._record_presence(seen)
        events = [e for e in events if not self._blink_noise(e)]
        # Give each track its own recent history. Nothing ever appended here, so `Track.events`
        # was empty for the life of every track -- and diffing's object table ranks "anything that
        # has moved lately" off `track.events[-3:]`, so that whole tier was dead and an object
        # actively moving but not yet classified ranked with static scenery and could fall below
        # the row clip. Bounded at 12: this is a tail, not a second ledger.
        for event in events:
            track = self.tracks.get(event.tid)
            if track is not None:
                track.events.append(event)
                if len(track.events) > 12:
                    del track.events[:-12]
        self._contacts(step)
        for tid in sorted(self.tracks, key=_tid_key):
            self._classify(self.tracks[tid], step)
        self._regroup(step)
        self._pick_self()

        events.sort(key=lambda e: (_EVENT_ORDER.get(e.kind, 99), _tid_key(e.tid)))
        return events

    def archive_level(self, level: int) -> None:
        """Move the live board aside at a level boundary.

        Ids restart their visibility but not their numbering: `t14` on level 2 is a
        different object from `t14` on level 1, and giving them the same name would make a
        ledger row ambiguous. `self_tid` is dropped because it named an object that no
        longer exists; it re-establishes itself within two acted moves.
        """
        if self.tracks:
            self.archived.setdefault(int(level), {}).update(self.tracks)
        self.tracks = {}
        self._presence = {}
        self._prev_positions = {}
        self._motion = {}
        self._absorbed = {}
        self._merged_into = {}
        self.groups = {}
        # The body measurements belong to the board that is gone. Left behind, the first note on
        # the new level lands beside four readings of the old body, `body_is_settled` reads
        # False, and every plan on the new level is capped at UNSETTLED_BODY_BATCH steps for as
        # long as it takes the window to turn over.
        self._body_sizes = []
        self._body_history = []
        # A new board does not inherit the old board's matching problems, and a gate widened by
        # six retrack verdicts is a gate that will confuse two objects on a board it has not
        # seen yet.
        self.max_shift = self._max_shift0
        self.self_tid = None

    # --- matching -----------------------------------------------------------------------

    def _cost(self, track: Track, blob: Blob, shift: tuple[int, int]) -> tuple[float, float]:
        """(cost, chebyshev). Lower is a better match; the caller applies the gates.

        cost = 3*[different form] + 2*[different colour] + |dpixels|/max(pixels)
               + chebyshev(centre)/8

        The weights encode what identity is made of: shape is the strongest evidence, then
        colour, then size, then proximity. Proximity is divided by the gate so it can never
        outweigh a shape mismatch on its own.
        """
        prev_pixels = track.blob.pixels if track.blob else blob.pixels
        expected_colour = track.colour
        if self._pmap is not None:
            expected_colour = self._pmap.get(track.colour, track.colour)
        cost = 0.0
        if track.form_hash != blob.form_hash:
            cost += 3.0
        if expected_colour != blob.colour:
            cost += 2.0
        cost += abs(prev_pixels - blob.pixels) / float(max(prev_pixels, blob.pixels, 1))
        pr, pc = track.centre
        cheb = _cheb((pr + shift[0], pc + shift[1]), blob.centre)
        # Divided by the gate the tracker is actually using, not the module default. The
        # docstring's claim -- "proximity can never outweigh a shape mismatch" -- holds only
        # while the divisor is at least as large as the reach the gate allows, and `widen()`
        # (the critic's retrack follow-up) and a learned teleport both push that past 8.
        cost += cheb / float(max(1, self.max_shift))
        return cost, cheb

    def widen(self, by: int = 4, ceiling: int = 16) -> int:
        """Loosen the match gate for the rest of the level, and say what it became.

        The critic's `retrack` verdict: a prediction failed because an id went to the wrong
        matter, or a thing the harness believed had vanished is plainly still there. The gate is
        what decides both, so the deterministic follow-up is to let it reach further. Bounded,
        because a gate wide enough to match anything is not a gate -- and it is deliberately not
        narrowed again, since the evidence that widening was wrong is the same evidence that
        asked for it -- within a level. Run `n` fired the critic's retrack verdict six times in
        fifteen turns, which at the old ceiling of 24 would let a track match a blob a third of
        the board away; 16 is twice the default and still inside one screen.
        """
        self.max_shift = min(int(ceiling), int(self.max_shift) + int(by))
        return self.max_shift

    def _gate(self, track: Track, blob: Blob, cheb: float) -> bool:
        """Chebyshev within max(8, 1 + the track's own last displacement), pixels within 2x.

        The velocity term is what lets a fast object stay matched: a thing that moved 12
        cells last step is allowed to move about that far again, while a thing that has
        never moved is held to the flat gate.
        """
        reach = max(abs(track.velocity[0]), abs(track.velocity[1]))
        for dr, dc in self._expected:
            reach = max(reach, abs(dr), abs(dc))
        if cheb > max(self.max_shift, 1 + reach):
            return False
        prev_pixels = track.blob.pixels if track.blob else blob.pixels
        if prev_pixels <= 0:
            return False
        ratio = blob.pixels / float(prev_pixels)
        return 0.5 <= ratio <= 2.0

    def _greedy(self, tracks: list[Track], blobs: list[Blob],
                shift: tuple[int, int]) -> list[tuple[Track, Blob]]:
        """Mutual-best greedy over cost-sorted candidate pairs.

        Sorting every gated pair once and accepting the cheapest still-free pair is the
        same thing as repeatedly taking the global minimum, and it is O(n log n) in the
        number of pairs with no iteration-order dependence anywhere. Matched blobs are
        removed from `blobs` in place, so what remains is exactly the set that spawns.

        Tombstoned tracks recent enough to be blinking are admitted with a flat cost
        penalty of 1 and a much tighter gate (same form, within 2 cells), so a blinking
        indicator revives its own id instead of minting a new one every other step.
        """
        pairs: list[tuple[float, tuple, int, int]] = []
        for i, track in enumerate(tracks):
            penalty = 1.0 if track.state in (TrackState.GONE, TrackState.CONSUMED) else 0.0
            for j, blob in enumerate(blobs):
                if penalty and (track.form_hash != blob.form_hash
                                or _cheb(track.centre, blob.centre) > 2):
                    continue
                cost, cheb = self._cost(track, blob, shift)
                if not self._gate(track, blob, cheb):
                    continue
                pairs.append((cost + penalty, (blob.bbox, blob.shape_hash, _tid_key(track.tid)),
                              i, j))
        pairs.sort(key=lambda p: (p[0], p[1]))
        used_t: set[int] = set()
        used_b: set[int] = set()
        out: list[tuple[Track, Blob]] = []
        for _c, _k, i, j in pairs:
            if i in used_t or j in used_b:
                continue
            used_t.add(i)
            used_b.add(j)
            out.append((tracks[i], blobs[j]))
        for j in sorted(used_b, reverse=True):
            _drop(blobs[j], blobs)
        return out

    def _group_shifts(self, tracks: list[Track], blobs: list[Blob],
                      shift: tuple[int, int]) -> list[tuple[Track, Blob]]:
        """Move each known rigid body as a unit, before any part is matched on its own.

        This is the fix for the one thing that still lost re86's player. The board carries
        two plus signs built from interchangeable 13-cell bars: same colour, same shape,
        same size. When the two bodies move by different displacements on the same step,
        nothing about a single bar says which plus it belongs to, and the global greedy
        matcher -- which is only trying to minimise total cost -- happily gave one body's
        arm to the other. The arm left over was then a VANISH, and if it was the arm the
        harness had named `self`, the player's identity died on a frame where the player
        had simply walked three cells left.

        A body already known to be rigid is not ambiguous, though. It has one displacement,
        so the displacement that covers the most of its members is claimed for all of them
        before the free-for-all starts. A body must still be covered by a majority of its
        members for the shift to be believed, so a group that has genuinely come apart
        falls through to the ordinary matcher.
        """
        out: list[tuple[Track, Blob]] = []
        for gid in sorted(self.groups):
            members = [t for t in tracks if getattr(t, "group", None) == gid]
            if len(members) < 2:
                continue
            cands: dict[tuple[int, int], list[tuple[Track, Blob]]] = {}
            for track in members:
                for blob in blobs:
                    if track.form_hash != blob.form_hash or track.colour != blob.colour:
                        continue
                    d = (blob.bbox[0] - track.last_bbox[0], blob.bbox[1] - track.last_bbox[1])
                    _cost, cheb = self._cost(track, blob, shift)
                    if not self._gate(track, blob, cheb):
                        continue
                    cands.setdefault(d, []).append((track, blob))
            best: Optional[tuple[tuple, tuple[int, int]]] = None
            for d, pairs in cands.items():
                covered = len({t.tid for t, _ in pairs})
                key = (-covered, 0 if d in self._expected else 1,
                       abs(d[0]) + abs(d[1]), d[0], d[1])
                if best is None or key < best[0]:
                    best = (key, d)
            if best is None:
                continue
            d = best[1]
            pairs = cands[d]
            if len({t.tid for t, _ in pairs}) * 2 < len(members):
                continue        # not a majority of the body: let the ordinary matcher decide
            used_t: set[str] = set()
            used_b: set[int] = set()
            claimed: list[tuple[Track, Blob]] = []
            for track, blob in sorted(pairs, key=lambda p: (_tid_key(p[0].tid), p[1].bbox)):
                if track.tid in used_t or id(blob) in used_b:
                    continue
                used_t.add(track.tid)
                used_b.add(id(blob))
                claimed.append((track, blob))
            if len(claimed) < 2:
                continue
            out.extend(claimed)
            for track, blob in claimed:
                _drop(track, tracks)
                _drop(blob, blobs)
        return out

    def _consensus(self, tracks: list[Track], blobs: list[Blob]) -> list[tuple[Track, Blob]]:
        """Second pass over the leftovers: accept one large jump that several tracks agree on.

        The gated matcher deliberately refuses a match further away than about eight cells,
        because at that distance "the same object moved" and "one object died and another
        was born" are not distinguishable from a single pair. They are perfectly
        distinguishable from *several* pairs: if two or more unmatched tracks each have an
        exact shape-and-colour twin at the very same offset, one displacement explains all
        of them and no other reading does. That is the evidence this pass requires -- exact
        form, exact colour, two distinct tracks, one shared displacement -- and it is what
        lets an action that teleports the body thirteen cells be followed the first time it
        is used, with no control map and no help from the caller.

        Displacements the caller supplied in `expected_shifts` are preferred when they tie.
        """
        if len(tracks) < 2 or len(blobs) < 2:
            return []
        votes: dict[tuple[int, int], list[tuple[Track, Blob]]] = {}
        for track in tracks:
            for blob in blobs:
                if track.form_hash != blob.form_hash or track.colour != blob.colour:
                    continue
                d = (blob.bbox[0] - track.last_bbox[0], blob.bbox[1] - track.last_bbox[1])
                if d == (0, 0):
                    continue
                votes.setdefault(d, []).append((track, blob))
        best: Optional[tuple[int, int]] = None
        best_key: Optional[tuple] = None
        for d, pairs in votes.items():
            if len({t.tid for t, _ in pairs}) < 2 or len({id(b) for _, b in pairs}) < 2:
                continue
            key = (-len({t.tid for t, _ in pairs}), 0 if d in self._expected else 1,
                   abs(d[0]) + abs(d[1]), d[0], d[1])
            if best_key is None or key < best_key:
                best, best_key = d, key
        if best is None:
            return []

        out: list[tuple[Track, Blob]] = []
        used_t: set[str] = set()
        used_b: set[int] = set()
        for track, blob in sorted(votes[best], key=lambda p: (p[1].bbox, _tid_key(p[0].tid))):
            if track.tid in used_t or id(blob) in used_b:
                continue
            used_t.add(track.tid)
            used_b.add(id(blob))
            out.append((track, blob))
        for track, blob in out:
            _drop(track, tracks)
            _drop(blob, blobs)
        return out

    def _rigid_groups(self, tracks: list[Track], blobs: list[Blob],
                      shift: tuple[int, int]) -> list[tuple[Track, Blob]]:
        """Assign groups of identical objects that all moved by one displacement.

        The honest reading of five identical dots two cells to the right is "the row
        shifted", not "five coin flips". A group qualifies only when a single (dr, dc)
        maps every one of its tracks onto a distinct blob of the group. Any such (dr, dc)
        must map the group's first track onto some blob of the group, so only that many
        candidates are tried (plus (0, 0) and the frame's own scroll), keeping this linear
        in the group size per candidate rather than cubic overall. Candidates are tried
        smallest-displacement-first, so a stationary group resolves to (0, 0).
        """
        out: list[tuple[Track, Blob]] = []
        groups: dict[tuple[int, str], tuple[list[Track], list[Blob]]] = {}
        for track in tracks:
            colour = track.colour
            if self._pmap is not None:
                colour = self._pmap.get(colour, colour)
            groups.setdefault((colour, track.form_hash), ([], []))[0].append(track)
        for blob in blobs:
            key = (blob.colour, blob.form_hash)
            if key in groups:
                groups[key][1].append(blob)
        for key in sorted(groups):
            gtracks, gblobs = groups[key]
            if len(gtracks) < 2 or len(gblobs) < 2 or len(gtracks) > len(gblobs):
                continue
            gtracks = sorted(gtracks, key=lambda t: (t.last_bbox, _tid_key(t.tid)))
            spots = {_topleft(b.bbox): b for b in gblobs}
            anchor = _topleft(gtracks[0].last_bbox)
            cands = {(spot[0] - anchor[0], spot[1] - anchor[1]) for spot in spots}
            cands.add((0, 0))
            cands.add(shift)
            cands.update(self._expected)
            chosen: Optional[list[tuple[Track, Blob]]] = None
            for d in sorted(cands, key=lambda v: (abs(v[0]) + abs(v[1]), v[0], v[1])):
                taken: set[tuple[int, int]] = set()
                pairing: list[tuple[Track, Blob]] = []
                ok = True
                for track in gtracks:
                    tt = _topleft(track.last_bbox)
                    spot = (tt[0] + d[0], tt[1] + d[1])
                    if spot not in spots or spot in taken:
                        ok = False
                        break
                    taken.add(spot)
                    pairing.append((track, spots[spot]))
                if ok:
                    chosen = pairing
                    break
            if chosen is None:
                continue
            out.extend(chosen)
            for track, blob in chosen:
                _drop(track, tracks)
                _drop(blob, blobs)
        return out

    def _mark_ambiguity(self, matched: list[tuple[Track, Blob]],
                        shift: tuple[int, int]) -> set[str]:
        """Tids whose assignment has an equally good alternative among identical objects.

        Two assigned pairs (t1,b1), (t2,b2) of the same colour and form are ambiguous when
        swapping them costs exactly the same and both swapped pairs pass the gate. That is
        precisely "several equal-cost pairings". One tie condemns the whole identical group:
        if two of eight indistinguishable dots could be exchanged for free, no individual
        dot's id in that group is worth anything, and pretending otherwise would let a rule
        be scored against a coin flip.

        Rigid-group assignments never reach here -- they were resolved by a single global
        displacement, which is certain evidence, not a guess.
        """
        out: set[str] = set()
        buckets: dict[tuple[int, str], list[tuple[Track, Blob]]] = {}
        for track, blob in matched:
            buckets.setdefault((blob.colour, blob.form_hash), []).append((track, blob))
        for key in sorted(buckets):
            group = sorted(buckets[key], key=lambda p: _tid_key(p[0].tid))
            if len(group) < 2 or len(group) > AMBIGUITY_MAX_GROUP:
                continue
            tied = False
            for i in range(len(group)):
                for j in range(i + 1, len(group)):
                    t1, b1 = group[i]
                    t2, b2 = group[j]
                    c11, _ = self._cost(t1, b1, shift)
                    c22, _ = self._cost(t2, b2, shift)
                    c12, k12 = self._cost(t1, b2, shift)
                    c21, k21 = self._cost(t2, b1, shift)
                    if not (self._gate(t1, b2, k12) and self._gate(t2, b1, k21)):
                        continue
                    if abs((c11 + c22) - (c12 + c21)) < 1e-9:
                        tied = True
                        break
                if tied:
                    break
            if tied:
                out.update(t.tid for t, _ in group)
        if out:
            self._ambig += 1
            for tid in sorted(out, key=_tid_key):
                self.tracks[tid].ambiguity_group = self._ambig
        return out

    def _merges(self, tracks: list[Track], blobs: list[Blob], step: int,
                events: list[Event]) -> list[tuple[Track, Blob]]:
        """Two or more previous footprints now inside one component -> MERGE.

        Containment, not proximity: the surviving component must literally cover the cells
        the old objects occupied. A blob that merely touches another is a contact, and the
        contact flags already record that. The lowest id survives (it is the oldest claim
        on the identity); the others are tombstoned with a MERGE event naming the survivor,
        so the ledger can still follow them.

        Every part -- including the survivor's own -- is filed in `_absorbed` with its shape
        and its offset inside the merged component, so that when the component comes apart
        again the same ids come back. This is not a nicety. re86's controlled body is a plus
        sign: four 13-cell arms of one colour around a single centre pixel of another. When
        that centre pixel takes the arms' colour the five components become one, and when it
        changes back they become five again. Without restoration each of those flickers
        burned four ids and the body was re-invented from scratch about once per step.
        """
        out: list[tuple[Track, Blob]] = []
        for blob in sorted(blobs, key=lambda b: b.bbox):
            inside = [t for t in tracks
                      if t.blob is not None and t.blob.cells <= blob.cells
                      and len(t.blob.cells) < len(blob.cells)]
            if len(inside) < 2:
                continue
            inside.sort(key=lambda t: _tid_key(t.tid))
            # The oldest claim survives -- unless the controlled body is one of the parts,
            # in which case the name the harness has been planning against survives. re86's
            # plus welds and unwelds every few actions, and letting the lowest id take the
            # component handed `self` back and forth between two arms for the whole game.
            survivor = inside[0]
            if self.self_tid is not None:
                survivor = next((t for t in inside if t.tid == self.self_tid), survivor)
            others = [t for t in inside if t is not survivor]
            events.append(Event(kind="MERGE", tid=survivor.tid, step=step,
                                detail={"parts": [t.tid for t in inside]}))
            # These were literally one connected component this frame. That is the strongest
            # evidence of a rigid body there is -- stronger than co-movement, which on real
            # frames is noisy enough to dissolve a body that is plainly one thing.
            self._family.append((step, frozenset(t.tid for t in inside)))
            filed = self._absorbed.setdefault(survivor.tid, [])
            known = {d["tid"] for d in filed}
            for part in inside:
                # Offsets are taken inside the merged blob's bounding box, which is exact:
                # containment is what qualified the merge, so every part's cells are in it.
                if part.tid not in known:
                    filed.append({
                        "tid": part.tid, "form": part.form_hash, "colour": part.colour,
                        "pixels": part.blob.pixels,
                        "rel": (part.last_bbox[0] - blob.bbox[0],
                                part.last_bbox[1] - blob.bbox[1]),
                    })
            for other in others:
                events.append(Event(kind="MERGE", tid=other.tid, step=step,
                                    detail={"into": survivor.tid}))
                other.state = TrackState.GONE
                other.last_seen = step
                self._merged_into[other.tid] = survivor.tid
                # A part that had swallowed parts of its own keeps no claim on them.
                self._absorbed.pop(other.tid, None)
                _drop(other, tracks)
            out.append((survivor, blob))
            _drop(survivor, tracks)
            _drop(blob, blobs)
        return out

    def _splits(self, tracks: list[Track], blobs: list[Blob], step: int,
                events: list[Event]) -> list[tuple[Track, Blob]]:
        """One previous footprint now containing two or more components -> SPLIT.

        When the parent is a component that had previously merged, the pieces are matched
        back against the filed parts by shape, colour and offset within the parent, and each
        part reclaims its own id -- so a body that keeps welding and unwelding keeps its
        names, its move history and therefore its rigid group.

        Otherwise (a genuinely new split) the largest fragment inherits the tid, since it
        has the best claim to being "the same thing", and the rest become new tracks whose
        SPLIT event names their origin so the ledger can still reach the parent. Either way
        the fragments are returned as matched pairs, so they are not also reported as spawns.
        """
        out: list[tuple[Track, Blob]] = []
        for track in sorted(tracks, key=lambda t: _tid_key(t.tid)):
            if track.blob is None:
                continue
            pieces = [b for b in blobs
                      if b.cells <= track.blob.cells and len(b.cells) < len(track.blob.cells)]
            if len(pieces) < 2:
                continue
            pieces.sort(key=lambda b: (-b.pixels, b.bbox))
            _drop(track, tracks)
            filed = self._absorbed.pop(track.tid, [])
            claimed = self._reclaim(track, pieces, filed)

            keeper = claimed.get(track.tid)
            if keeper is None:
                # The parent's own filed part lost every fragment to a better match. This
                # happens when a component comes apart into fewer pieces than it swallowed
                # (seen on sk48 around step 100, where it used to raise StopIteration and
                # end the game with a partial record).
                free = [p for p in pieces if all(p is not got for got in claimed.values())]
                if free:
                    keeper = free[0]                    # pieces are sorted largest first
                else:
                    # Nothing is free. The component still exists, so the identity of the
                    # component still exists: the parent takes the largest fragment back and
                    # whichever swallowed part had claimed it stays tombstoned. Letting the
                    # incumbent evaporate instead would drop `self` on a frame where the
                    # body merely lost a limb.
                    keeper = pieces[0]
                    for tid, got in sorted(claimed.items(), key=lambda kv: _tid_key(kv[0])):
                        if got is keeper and tid != track.tid:
                            del claimed[tid]
                            break
            out.append((track, keeper))
            _drop(keeper, blobs)

            born: list[str] = []
            for piece in pieces:
                if piece is keeper:
                    continue
                owner = next((tid for tid, got in claimed.items() if got is piece), None)
                if owner is not None and owner != track.tid:
                    revived = self.tracks[owner]
                    self._merged_into.pop(owner, None)
                    born.append(owner)
                    events.append(Event(kind="SPLIT", tid=owner, step=step,
                                        detail={"from": track.tid, "restored": True}))
                    out.append((revived, piece))
                else:
                    new = self._spawn(piece, track.level, step)
                    born.append(new.tid)
                    events.append(Event(kind="SPLIT", tid=new.tid, step=step,
                                        detail={"from": track.tid}))
                    out.append((new, piece))
                _drop(piece, blobs)
            events.append(Event(kind="SPLIT", tid=track.tid, step=step, detail={"into": born}))
        return out

    def _reclaim(self, parent: Track, pieces: list[Blob],
                 filed: list[dict[str, Any]]) -> dict[str, Blob]:
        """Match the fragments of a splitting component back to the parts it swallowed.

        Cost is the same currency the main matcher uses -- 3 for a different shape, 2 for a
        different colour, and the offset error inside the parent divided by the gate -- so a
        part that has itself been recoloured or slightly reshaped still finds its way home,
        and a fragment that matches nothing filed is left to spawn a fresh id.
        """
        if not filed:
            return {}
        pr0, pc0 = parent.last_bbox[0], parent.last_bbox[1]
        pairs: list[tuple[float, tuple, int, int]] = []
        for i, part in enumerate(filed):
            if part["tid"] != parent.tid:
                track = self.tracks.get(part["tid"])
                if track is None or track.state is not TrackState.GONE:
                    continue
            for j, piece in enumerate(pieces):
                cost = 0.0
                if part["form"] != piece.form_hash:
                    cost += 3.0
                if part["colour"] != piece.colour:
                    cost += 2.0
                rel = (piece.bbox[0] - pr0, piece.bbox[1] - pc0)
                cost += max(abs(rel[0] - part["rel"][0]),
                            abs(rel[1] - part["rel"][1])) / float(MAX_SHIFT)
                if cost >= 4.0:          # different shape *and* different colour: not it
                    continue
                pairs.append((cost, (piece.bbox, piece.shape_hash, _tid_key(part["tid"])), i, j))
        pairs.sort(key=lambda p: (p[0], p[1]))
        used_i: set[int] = set()
        used_j: set[int] = set()
        out: dict[str, Blob] = {}
        for _cost, _key, i, j in pairs:
            if i in used_i or j in used_j:
                continue
            used_i.add(i)
            used_j.add(j)
            out[filed[i]["tid"]] = pieces[j]
        return out

    # --- per-track updates ---------------------------------------------------------------

    def _spawn(self, blob: Blob, level: int, step: int) -> Track:
        self._n += 1
        tid = "t%d" % self._n
        track = Track(
            tid=tid, level=int(level), first_seen=step, last_seen=step, blob=blob,
            last_bbox=blob.bbox, colour=blob.colour, form_hash=blob.form_hash,
            flags={"contacts": [], "no_ops": 0, "moves_acted": 0, "moves_unacted": 0},
        )
        # `Track.group` is set here rather than declared in types.py, which another agent
        # owns and is actively editing; every Track this tracker mints therefore has the
        # attribute. Fold it into the dataclass next time types.py is open.
        track.group = None
        if self._bands_known and blob.region != "hud":
            track.flags["ever_outside_hud"] = True
        track.appearances.append((step, blob.colour, _topleft(blob.bbox)))
        self.tracks[tid] = track
        self._presence[tid] = []
        self._motion[tid] = {}
        return track

    def _apply_match(self, track: Track, blob: Blob, *, step: int, acted: bool,
                     ambiguous: bool, events: list[Event], structural: bool = False) -> None:
        """Fold one accepted (track, blob) pairing in.

        `structural` marks a pairing that came from a merge or a split rather than from
        motion. There, the blob on the other side is a different *extent* of the same
        matter -- the union of a body, or one arm of it -- so the change in its bounding box
        says nothing about where anything went. Emitting a MOVE for it is not merely noisy,
        it is false: re86's plus sign welding shut moved its survivor's top-left thirteen
        cells sideways without a single pixel of the body moving, and the control map duly
        recorded `moved self (0,-13)` fifteen times as ACTION5's dominant effect. MERGE,
        SPLIT and RESHAPE already say what happened; MOVE is withheld, and the step is kept
        out of the motion history that rigid grouping and `self_tid` are computed from.
        """
        was = track.state
        newborn = track.first_seen == step
        d = (blob.bbox[0] - track.last_bbox[0], blob.bbox[1] - track.last_bbox[1])

        if not structural and not newborn \
                and was in (TrackState.OCCLUDED, TrackState.GONE, TrackState.CONSUMED):
            events.append(Event(kind="REAPPEAR", tid=track.tid, step=step,
                                detail={"after": track.missing_for or (step - track.last_seen)}))
        # "never been seen outside a band WHILE BANDS WERE KNOWN" is what `_is_hud` documents,
        # but the flag was only ever set at `_spawn` -- so a track born before any band was
        # established, or born on a border row, could never clear it, and a real player that
        # spawns on the edge is demoted to readout for the rest of the game. It is a fact about
        # the track's history, so it is recorded whenever the history says it.
        if self._bands_known and blob.region != "hud":
            track.flags["ever_outside_hud"] = True
        if blob.colour != track.colour:
            events.append(Event(kind="RECOLOUR", tid=track.tid, step=step,
                                detail={"from": track.colour, "to": blob.colour}))
            track.flags["changed_at"] = step
        if blob.form_hash != track.form_hash:
            events.append(Event(kind="RESHAPE", tid=track.tid, step=step,
                                detail={"pixels": blob.pixels}))
            track.flags["changed_at"] = step
        if d != (0, 0) and not structural:
            if ambiguous:
                # An unresolved pairing must not become movement evidence.
                track.velocity = (0, 0)
            else:
                events.append(Event(kind="MOVE", tid=track.tid, step=step, detail={"d": list(d)}))
                track.velocity = d
                # The event is still emitted -- the pan is what happened, and the diff folds the
                # shared displacement into one line -- but it is not evidence that this object
                # responds to the controls. Under a pan EVERYTHING shares a displacement, so
                # counting it made every object on the board a controllable candidate after one
                # scrolled step, and after two the biggest piece of scenery was eligible to be
                # picked as the body. Same reasoning as the `_motion` guard below.
                if not self._scrolled:
                    key = "moves_acted" if acted else "moves_unacted"
                    track.flags[key] = int(track.flags.get(key, 0)) + 1
        else:
            track.velocity = (0, 0)
            if acted and not newborn and not structural:
                track.flags["no_ops"] = int(track.flags.get("no_ops", 0)) + 1

        if acted and not newborn and not ambiguous and not structural and not self._scrolled:
            # Every acted step this track was actually observed on, including the ones it
            # did not move: rigid grouping needs the zeros as much as the moves, because
            # "one moved and the other did not" is what separates two bodies.
            # A camera pan is excluded: under a scroll *everything* shares a displacement,
            # so the step is evidence about the camera and none at all about which objects
            # are welded together.
            motion = self._motion.setdefault(track.tid, {})
            motion[step] = d
            if len(motion) > MOTION_WINDOW:
                for old in sorted(motion)[:len(motion) - MOTION_WINDOW]:
                    del motion[old]

        if self._bands_known and blob.region != "hud":
            track.flags["ever_outside_hud"] = True
        track.blob = blob
        track.last_bbox = blob.bbox
        track.colour = blob.colour
        track.form_hash = blob.form_hash
        track.last_seen = step
        track.missing_for = 0
        track.state = TrackState.AMBIGUOUS if ambiguous else TrackState.LIVE
        if not ambiguous:
            track.ambiguity_group = None
        if not newborn:
            track.appearances.append((step, blob.colour, _topleft(blob.bbox)))

    def _miss(self, track: Track, *, step: int, veil: frozenset[Cell],
              live_cells: dict[str, frozenset[Cell]], movers: set[str],
              events: list[Event]) -> None:
        """A track with no blob this step: occluded, consumed, or gone.

        Order matters. A mover standing on the footprint is a consumption (that is how a
        collectable disappears in every game that has one); a curtain or a stationary body
        over it is an occlusion; anything else is a vanish. Getting this order wrong turns
        every pickup into a mystery and every mystery into a pickup.
        """
        cells = track.blob.cells if track.blob else frozenset()
        need = max(1, int(COVER_FRAC * len(cells))) if cells else 1

        if track.state is TrackState.OCCLUDED:
            track.missing_for += 1
            if track.missing_for >= self.occlusion_ttl:
                track.state = TrackState.GONE
                track.last_seen = step
                events.append(Event(kind="VANISH", tid=track.tid, step=step,
                                    detail={"after_occlusion": True}))
            return

        eater = None
        cover = None
        for tid in sorted(live_cells, key=_tid_key):
            if tid == track.tid:
                continue
            if len(cells & live_cells[tid]) < need:
                continue
            if tid in movers and eater is None:
                eater = tid
            elif cover is None:
                cover = tid

        if eater is not None:
            track.state = TrackState.CONSUMED
            track.flags["consumed_at"] = step
            track.last_seen = step
            events.append(Event(kind="CONSUME", tid=track.tid, step=step, detail={"by": eater}))
            return
        if (cells and veil and len(cells & veil) >= need) or cover is not None:
            track.state = TrackState.OCCLUDED
            track.missing_for = 1
            events.append(Event(kind="OCCLUDE", tid=track.tid, step=step,
                                detail={"by": cover or "veil"}))
            return
        track.state = TrackState.GONE
        track.last_seen = step
        events.append(Event(kind="VANISH", tid=track.tid, step=step, detail={}))

    # --- derived per-track facts ---------------------------------------------------------

    def _record_presence(self, seen: set[str]) -> None:
        """Keep an 8-step presence history per track and flag periodic blinkers.

        A blinking indicator otherwise emits a SPAWN and a VANISH on alternate steps
        forever, which is both noise in the rendered diff and false evidence for any rule
        about objects appearing. A track counts as blinking when its last 8 presence
        readings hold at least 3 alternations and no run of the same reading longer than 3,
        i.e. a LIVE/GONE cycle of period at most 3.

        An OCCLUDED track reads as present. Its absence is already explained by a curtain or
        a body on top of it, and counting it as absent would make an object under a
        flickering overlay indistinguishable from a blinking indicator -- which then
        suppresses the REAPPEAR that tells the harness its object is back.
        """
        for tid in list(self.tracks):
            hist = self._presence.setdefault(tid, [])
            hist.append(tid in seen or self.tracks[tid].state is TrackState.OCCLUDED)
            if len(hist) > BLINK_WINDOW:
                del hist[:-BLINK_WINDOW]
            if len(hist) < 4:
                continue
            transitions = sum(1 for i in range(1, len(hist)) if hist[i] != hist[i - 1])
            run = best = 1
            for i in range(1, len(hist)):
                run = run + 1 if hist[i] == hist[i - 1] else 1
                best = max(best, run)
            # Assigned, not latched. Set once and never cleared, an object that blinked for a
            # few steps was treated as chatter for the rest of the game: when it genuinely
            # disappeared the VANISH was filtered out and the step reported no events at all.
            # The presence history is already a rolling window, so the flag belongs to it.
            self.tracks[tid].flags["blinking"] = bool(
                transitions >= BLINK_MIN_TRANSITIONS and best <= BLINK_MAX_RUN)

    def _blink_noise(self, event: Event) -> bool:
        """True for the SPAWN/VANISH/REAPPEAR chatter of a track already known to blink."""
        if event.kind not in ("SPAWN", "VANISH", "REAPPEAR"):
            return False
        track = self.tracks.get(event.tid)
        return bool(track and track.flags.get("blinking"))

    def _contacts(self, step: int) -> None:
        """Record every pair of live tracks that now overlap or are 4-adjacent.

        Contact is the antecedent of most interesting rules ("walking into a dot collects
        it", "touching the wall stops you"), so it is recorded unconditionally rather than
        on demand. Bounding boxes are compared first and the dilated cell set is built at
        most once per track, so a board with a hundred objects stays cheap.
        """
        live = [t for t in self.live()
                if t.blob is not None and t.state is not TrackState.OCCLUDED]
        grown_cache: dict[str, frozenset[Cell]] = {}

        def grown(track: Track) -> frozenset[Cell]:
            got = grown_cache.get(track.tid)
            if got is None:
                acc: set[Cell] = set()
                for r, c in track.blob.cells:
                    acc.add((r, c))
                    acc.add((r + 1, c))
                    acc.add((r - 1, c))
                    acc.add((r, c + 1))
                    acc.add((r, c - 1))
                got = frozenset(acc)
                grown_cache[track.tid] = got
            return got

        for i in range(len(live)):
            a = live[i]
            for j in range(i + 1, len(live)):
                b = live[j]
                if (a.last_bbox[0] > b.last_bbox[2] + 1 or b.last_bbox[0] > a.last_bbox[2] + 1
                        or a.last_bbox[1] > b.last_bbox[3] + 1
                        or b.last_bbox[1] > a.last_bbox[3] + 1):
                    continue
                if not (grown(a) & b.blob.cells):
                    continue
                for one, other in ((a, b), (b, a)):
                    one.flags["touched_at"] = step
                    contacts = one.flags.setdefault("contacts", [])
                    if not contacts or contacts[-1] != [step, other.tid]:
                        contacts.append([step, other.tid])
                    if len(contacts) > 32:
                        del contacts[:-32]

    def _classify(self, track: Track, step: int) -> None:
        """hud | background | controllable | autonomous | static | unknown.

        The order is load-bearing: an object that ever moved when we did nothing is
        autonomous no matter how often it also moved when we acted, because that is the
        reading that stops the harness from believing it controls the weather.
        """
        if _is_hud(track):
            track.klass = "hud"
            return
        if track.blob is not None and track.blob.region == "background":
            track.klass = "background"
            return
        acted_moves = _moves(track, True)
        idle_moves = _moves(track, False)
        if acted_moves >= 2 and idle_moves == 0:
            track.klass = "controllable"
        elif idle_moves > 0:
            track.klass = "autonomous"
        elif acted_moves == 0 and step - track.first_seen >= 6:
            track.klass = "static"
        else:
            track.klass = "unknown"

    def _agreement(self, a: str, b: str, now: int) -> tuple[int, int]:
        """(shared non-zero moves, disagreements) over the last `GROUP_WINDOW` *steps*.

        The window is in steps, not in observations. Taking "the last 24 shared entries"
        instead looked identical and was not: two tracks whose histories barely overlap --
        one that has been on the board since the start, one that appeared at step 50 --
        have their 24 most recent shared entries stretching all the way back to step 1.
        On re86 that let an arm's behaviour before it joined the body outvote everything it
        has done since, so the body it demonstrably belongs to could never re-form.
        """
        ma, mb = self._motion.get(a, {}), self._motion.get(b, {})
        shared = disagree = 0
        for step in ma.keys() & mb.keys():
            if now - step > GROUP_WINDOW:
                continue
            if ma[step] != mb[step]:
                disagree += 1
            elif ma[step] != (0, 0):
                shared += 1
        return shared, disagree

    def _regroup(self, step: int) -> None:
        """Find the rigid bodies, from two kinds of evidence.

        **Co-movement.** Two tracks belong to the same body when, over the recent acted
        steps where both were observed, their displacements agreed -- with at least two
        shared non-zero moves (any two stationary objects trivially agree on (0, 0) forever)
        and essentially no disagreements.

        **Shared substance.** Two tracks that were recently one connected component are one
        body, full stop. This second kind was added after measuring the first on a 126-step
        re86 game, and the measurement is the argument: over 24 shared steps, two arms of
        the same plus sign disagreed on 9 of them. Bounding-box displacement is simply not a
        clean signal on real frames -- an arm that overlaps another object for a frame gets
        re-segmented and its apparent displacement is wrong for that step. Requiring clean
        co-movement dissolved a body that had, minutes earlier, literally been one blob.
        Merge history says what co-movement only guesses at.

        A structural family expires after `GROUP_WINDOW` steps, so two objects that touched
        once and then went their separate ways do not stay welded; and it is refused if the
        pair has since disagreed on more than half their shared steps, which is what genuine
        separation looks like.

        This exists because a controlled object is very often not one component. On re86 it
        is five: four 13-cell arms around a one-pixel centre, which segmentation correctly
        reports as five blobs and which the game drags around as one body. Without grouping
        the harness picks one arm as "self", calls the rest `unknown`, and every step reports
        four unexplained position changes -- noise a prediction can only ever be wrong about.

        A group is an overlay. Members keep their tids, blobs, events and klass; the group
        id is the numeric part of its lowest member's tid, so the id is stable for as long
        as that member is, and re-deriving it every step costs nothing.
        """
        for track in self.tracks.values():
            track.group = None
        self.groups = {}
        self._family = [(s, m) for s, m in self._family if step - s <= GROUP_WINDOW]

        live = [t for t in self.live() if t.state is TrackState.LIVE and not _is_hud(t)]
        if len(live) < 2:
            return
        present = {t.tid for t in live}
        movers = [t.tid for t in live
                  if sum(1 for d in self._motion.get(t.tid, {}).values() if d != (0, 0))
                  >= GROUP_MIN_SHARED_MOVES]

        parent = {t.tid: t.tid for t in live}

        def find(x: str) -> str:
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a: str, b: str) -> None:
            ra, rb = find(a), find(b)
            if ra == rb:
                return
            lo, hi = (ra, rb) if _tid_key(ra) < _tid_key(rb) else (rb, ra)
            parent[hi] = lo

        order = sorted(movers, key=_tid_key)
        for i, a in enumerate(order):
            for b in order[i + 1:]:
                shared, disagree = self._agreement(a, b, step)
                # A simple majority, not unanimity. Measured on re86: two arms of the same
                # plus sign, which are beyond doubt one body, agreed on 15 of 24 shared
                # steps and disagreed on 9 -- every disagreement a frame where one arm
                # overlapped something and was re-segmented, so its bounding box moved
                # differently from its matter. Demanding unanimity does not find rigid
                # bodies on real frames; it finds frames with no occlusion in them.
                if shared >= GROUP_MIN_SHARED_MOVES and shared > disagree:
                    union(a, b)

        for _fstep, members in self._family:
            here = sorted(members & present, key=_tid_key)
            for i, a in enumerate(here):
                for b in here[i + 1:]:
                    shared, disagree = self._agreement(a, b, step)
                    if disagree and disagree > shared:
                        continue        # they have since demonstrably come apart
                    union(a, b)

        buckets: dict[str, list[str]] = {}
        for tid in sorted(present, key=_tid_key):
            buckets.setdefault(find(tid), []).append(tid)
        found: dict[int, list[str]] = {}
        for members in buckets.values():
            if len(members) < 2:
                continue
            members.sort(key=_tid_key)
            found[_tid_key(members[0])[0]] = members
        for gid in sorted(found):           # insertion order is the id order, deterministic
            self.groups[gid] = found[gid]
            for tid in found[gid]:
                self.tracks[tid].group = gid

    def _pick_self(self) -> None:
        """The harness's own pick of the controlled body, or None.

        A candidate track has at least two MOVEs on acted steps, none on unacted steps, and
        is not part of the HUD. Candidates are then considered as *bodies*: a rigid group
        of candidates competes as one unit, and the biggest unit by total pixels wins, ties
        going to the lower id. `self_tid` is that unit's largest member, so the name points
        at something substantial rather than at whichever one-pixel fragment happened to be
        segmented first; `self_group()` is the whole body.

        The pick is **sticky**: a rival body has to be `SELF_STICKY` times bigger before the
        name moves to it. re86 carries two co-moving bodies of 53 and 49 pixels, and taking
        the larger one afresh every step made `self` oscillate between them as each welded
        and unwelded. That is worse than picking the wrong one: the control map then
        attributes one body's displacement to the other, and no action ever earns a
        consistent signature. If the current self stops qualifying it is dropped, and if it
        was swallowed by a merge the pick follows it to the survivor -- the same matter
        under a different name.

        This is a harness fact, never a model claim: the model may label the object, but it
        cannot tell the harness what it controls.
        """
        eligible = []
        for tid in sorted(self.tracks, key=_tid_key):
            track = self.tracks[tid]
            if track.state in (TrackState.GONE, TrackState.CONSUMED) or _is_hud(track):
                continue
            # "Moved once without an action" used to disqualify a body permanently. That is too
            # sharp a rule for a board with animations, a settling frame or a reset: on ls20
            # level 2 the self went t42 -> t28 -> t41 in thirteen turns and the critic filed
            # `identity` three times, and a self that keeps being renamed cannot be predicted
            # against or planned for. What the test is really for is telling a body we drive from
            # one that moves on its own, so it asks which happens more.
            if _moves(track, True) < 2 or _moves(track, False) > _moves(track, True):
                continue
            eligible.append(tid)
        if not eligible:
            self.self_tid = None
            return

        allowed = set(eligible)
        units: list[list[str]] = []
        grouped: set[str] = set()
        for gid in sorted(self.groups):
            core = [m for m in self.groups[gid] if m in allowed]
            if len(core) < 2:
                continue
            # A body's size is all of it, including a part restored this step that has not
            # yet re-earned two moves of its own; excluding those made the body's pixel
            # count swing by a factor of four as it welded and unwelded.
            members = [m for m in self.groups[gid]
                       if self.tracks[m].state is not TrackState.GONE
                       and not _is_hud(self.tracks[m]) and _moves(self.tracks[m], False) == 0]
            units.append(sorted(set(members) | set(core), key=_tid_key))
            grouped.update(units[-1])
        units.extend([tid] for tid in eligible if tid not in grouped)

        def pixels(tid: str) -> int:
            blob = self.tracks[tid].blob
            return blob.pixels if blob else 0

        units.sort(key=lambda u: (-sum(pixels(m) for m in u),
                                  _tid_key(min(u, key=_tid_key))))
        winner = units[0]

        # Stickiness: follow the incumbent (through a merge, if it was swallowed) and keep
        # it unless the leader is decisively bigger.
        incumbent = self.self_tid
        seen_redirect: set[str] = set()
        while incumbent is not None and incumbent not in allowed and incumbent not in seen_redirect:
            seen_redirect.add(incumbent)
            incumbent = self._merged_into.get(incumbent)
        if incumbent in allowed:
            held = next((u for u in units if incumbent in u), None)
            if held is not None and sum(pixels(m) for m in held) * SELF_STICKY \
                    >= sum(pixels(m) for m in winner):
                winner = held
            # The representative of a body is sticky too. Two 13-cell arms of the same plus
            # sign tie on pixels, so re-deriving the name each step made `self` alternate
            # between them -- the body was right the whole time, but the name a prediction
            # had to be written against changed under it.
            if incumbent in winner:
                self.self_tid = incumbent
                return

        self.self_tid = sorted(winner, key=lambda m: (-pixels(m), _tid_key(m)))[0]


# --- helpers -------------------------------------------------------------------------------


_EVENT_ORDER = {
    "SPAWN": 0, "MOVE": 1, "RECOLOUR": 2, "RESHAPE": 3, "MERGE": 4, "SPLIT": 5,
    "OCCLUDE": 6, "REAPPEAR": 7, "CONSUME": 8, "VANISH": 9,
}


def _tid_key(tid: str) -> tuple[int, str]:
    """Sort ids numerically: t2 before t10. Lexicographic order would not."""
    try:
        return (int(tid[1:]), tid)
    except (ValueError, IndexError):
        return (1 << 30, tid)


def _moves(track: Track, acted: bool) -> int:
    return int(track.flags.get("moves_acted" if acted else "moves_unacted", 0))


def _is_hud(track: Track) -> bool:
    """True for a track that is part of the readout rather than part of the board.

    Two conditions, and the second one matters as much as the first: the blob must be inside
    a HUD band *now*, and the track must never have been seen outside one while bands were
    known. The readout does not walk onto the board and back. Without the second condition,
    a player whose arm steps onto the bottom row is demoted to `hud` for that frame, drops
    out of the self candidates, and the control map loses the move -- which is exactly what
    happened on re86 at step 98.

    The blob's region is read rather than `klass`, so this answers correctly even when
    called before the classification pass of the current step.
    """
    if track.flags.get("ever_outside_hud"):
        return False
    return track.klass == "hud" or (track.blob is not None and track.blob.region == "hud")


def _drop(item: Any, pool: list) -> None:
    """Remove `item` from `pool` by identity (two blobs can compare equal but be distinct)."""
    for i, other in enumerate(pool):
        if other is item:
            del pool[i]
            return
